package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Flow;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface FlowMapper extends BaseMapper<Flow> {
    Flow selectGrouping(@Param("groupingId") String groupingId, @Param("topologyId") String topologyId);


}
