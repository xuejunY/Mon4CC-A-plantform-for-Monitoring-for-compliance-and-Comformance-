package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Kafkaspout;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface KafkaspoutMapper extends BaseMapper<Kafkaspout> {
    Kafkaspout selectKafkaSpout(@Param("id") String id, @Param("topologyId") String topologyId);

    boolean updateCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("kafkaSpoutCode") String kafkaSpoutCode,@Param("kafkaSpoutCodeSimple") String kafkaSpoutCodeSimple);
    boolean insertCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("kafkaSpoutCode") String kafkaSpoutCode,@Param("kafkaSpoutCodeSimple") String kafkaSpoutCodeSimple);
    List<Kafkaspout> selectCompleteCode(@Param("topologyId")String topologyId);

}
