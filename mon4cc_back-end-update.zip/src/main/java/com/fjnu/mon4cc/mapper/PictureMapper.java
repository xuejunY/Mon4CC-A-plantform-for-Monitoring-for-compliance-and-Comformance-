package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Picture;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PictureMapper extends BaseMapper<Picture> {

    boolean insertPicture(Picture picture);

    List<Picture> selectPicturesBytaskId(@Param("taskId") int taskId);

    boolean deleteBypictureId(@Param("taskId")int taskId);
}
