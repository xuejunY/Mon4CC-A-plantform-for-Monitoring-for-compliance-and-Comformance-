package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.entity.Modelconfiguration;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */

public interface ModelconfigurationMapper extends BaseMapper<Modelconfiguration> {

    List<Modelconfiguration> selectTopologyConfig(Page page, @Param("topologyName") String topologyName,@Param("creater") String creater);

    Modelconfiguration selectBytopologyId(@Param("topologyId") String topologyId);

    boolean insertTopology(Modelconfiguration modelconfiguration);

    boolean deleteTopology(@Param("topologyId") String topologyId);

    boolean updateTopology(Modelconfiguration modelconfiguration);

    List<Modelconfiguration> selectCompleteCode(String topologyId);

    boolean updateState(@Param("topologyId") String topologyId, @Param("state") String state);

    List<Modelconfiguration> selectModelIds(@Param("typeName") String typeName,@Param("creater") String creater);
}
