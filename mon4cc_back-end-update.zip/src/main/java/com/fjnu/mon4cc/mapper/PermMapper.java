package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Perm;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 权限 Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface PermMapper extends BaseMapper<Perm> {
    List<Perm> getPermsByUserId(@Param("userId") String userId);

    List<Perm> getPermsByRoleId(@Param("roleId") String roleId);

    void saveOrUpdate(@Param("perms") List<Perm> perms);

}
