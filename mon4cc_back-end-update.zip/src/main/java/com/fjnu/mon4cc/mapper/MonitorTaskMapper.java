package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.entity.MonitorTask;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface MonitorTaskMapper extends BaseMapper<MonitorTask> {

    boolean insertTask(MonitorTask monitorTask);

    List selectMonitorTask(Page page, @Param("taskName") String taskName,@Param("creater") String creater);

    boolean deleteTask(@Param("taskId") int taskId);

    boolean updateState(@Param("taskId") int taskId,@Param("state") String state);

    MonitorTask selectTask(@Param("taskId") int taskId);

    boolean updateTask(MonitorTask monitorTask);

    boolean updateTask_result(MonitorTask monitorTask);

    List<MonitorTask> findRunningTasks();
}
