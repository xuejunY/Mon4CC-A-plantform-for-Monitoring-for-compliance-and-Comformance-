package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.entity.*;
import com.fjnu.mon4cc.service.*;
import com.fjnu.mon4cc.utils.PageUtils;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/topologyconfiguration")
public class ModelconfigurationController {
    private static final Logger log = LoggerFactory.getLogger(ModelconfigurationController.class);
    @Autowired
    private IModelconfigurationService iModelconfigurationService;
    @Autowired
    private IFlowService iFlowService;
    @Autowired
    private IBoltService iBoltService;
    @Autowired
    private ISpoutService iSpoutService;
    @Autowired
    private IKafkaspoutService iKafkaspoutService;



    @PostMapping("/query")
    public Json query(@RequestBody String body) {
        String oper = "query models";
        log.info("{}, body: {}", oper, body);
        JSONObject json = JSON.parseObject(body);
        String topologyName = json.getString("modelName");
        String creater = json.getString("creater");
        Page<Modelconfiguration> page = iModelconfigurationService.queryTopologyConfig(PageUtils.getPageParam(json), topologyName,creater);
        return Json.succ(oper).data("page", page);
    }


    @PostMapping("/insert")
    public Json add(@RequestBody String body) throws ParseException {

        String oper = "add a models";
        log.info("{}, body: {}",oper,body);

        Modelconfiguration modelconfiguration = JSON.parseObject(body, Modelconfiguration.class);

        Modelconfiguration modelconfiguration1 = iModelconfigurationService.select_bance(modelconfiguration.getModelId());
        if (modelconfiguration1 != null) {
            return Json.fail(oper, "The model already exists !");
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        //保存数据
        modelconfiguration.setState("unparsed");
        modelconfiguration.setCreateTime(dateFormat.format(new Date()));

        boolean success = iModelconfigurationService.insert_bance(modelconfiguration);
        return Json.result(oper, success)
                .data("state", modelconfiguration.getState())
                .data("createTime", modelconfiguration.getCreateTime());
    }

    @PostMapping("/delete")
    public Json delete(@RequestBody String body) {

        String oper = "delete a models";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String topologyId = jsonObj.getString("topologyId");
        iBoltService.delete(new EntityWrapper<Bolt>().eq("topologyId",topologyId));
        iFlowService.delete(new EntityWrapper<Flow>().eq("topologyId",topologyId));
        iSpoutService.delete(new EntityWrapper<Spout>().eq("topologyId",topologyId));
        iKafkaspoutService.delete(new EntityWrapper<Kafkaspout>().eq("topologyId",topologyId));
        boolean success = iModelconfigurationService.deleteByTid(topologyId);

        return Json.result(oper, success);
    }


    @PostMapping("/update")
    public Json update(@RequestBody String body) {

        String oper = "update model config";
        log.info("{}, body: {}",oper,body);

        Modelconfiguration modelconfiguration = JSON.parseObject(body, Modelconfiguration.class);
        boolean success = iModelconfigurationService.update_bance(modelconfiguration);
        return Json.succ(oper,success);
    }

    @PostMapping("/updateState")
    public Json updateState(@RequestBody String body) {

        String oper = "update model state";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        String topologyId = jsonObj.getString("tid");
        String state = jsonObj.getString("state");

        boolean success = iModelconfigurationService.update_state(topologyId,state);
        return Json.succ(oper,success);
    }


    @PostMapping("/getXml")
    public Json getXml(@RequestBody String body){

        String oper = "get a xml";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String topologyId = jsonObj.getString("tid");


        Modelconfiguration modelconfiguration = iModelconfigurationService.select_bance(topologyId);

        return Json.succ(oper,"topologyXml", modelconfiguration.getModelXml().toString());
    }

    @PostMapping("/getModelEcl")
    public Json getModelEcl(@RequestBody String body){

        String oper = "get a ecl";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String modelId = jsonObj.getString("modelId");

        Modelconfiguration modelconfiguration = iModelconfigurationService.select_bance(modelId);


        return Json.succ(oper,"modelEcl", modelconfiguration.getModelEcl().toString())
                .data("modelName",modelconfiguration.getModelName());
    }

    @PostMapping("/selectModelId")
    public Json selectModelId(@RequestBody String body){
        String oper = "get modelIds";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String typeName = jsonObj.getString("typeName");
        String creater = jsonObj.getString("creater");

        List<Modelconfiguration> list = iModelconfigurationService.select_modelIds(typeName,creater);
        List list1 = new ArrayList();
        for (Modelconfiguration modelconfiguration:list){
            list1.add(modelconfiguration.getModelId());
        }
        return Json.succ(oper,"modelId", list1);

    }



}
