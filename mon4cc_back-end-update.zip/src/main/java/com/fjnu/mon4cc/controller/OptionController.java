package com.fjnu.mon4cc.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.fjnu.mon4cc.entity.Role;
import com.fjnu.mon4cc.service.IRoleService;
import com.fjnu.mon4cc.vo.Json;
import com.fjnu.mon4cc.vo.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/option")
public class OptionController {

    private static final Logger log = LoggerFactory.getLogger(OptionController.class);

    @Autowired
    private IRoleService iRoleService;

    @GetMapping("/role")
    public Json listRoleOptions() {
        String oper = "list role options";
        log.info(oper);

        EntityWrapper<Role> params = new EntityWrapper<>();
        params.setSqlSelect("rid,rname,rval");

        List<Role> list = iRoleService.selectList(params);
        List<Option> options = list.stream().map(obj -> new Option(obj.getRid(), obj.getRname(),obj.getRval())).collect(Collectors.toList());
        return Json.succ(oper, "options", options);
    }


}
