package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.fjnu.mon4cc.constant.PermType;
import com.fjnu.mon4cc.entity.Perm;
import com.fjnu.mon4cc.service.IPermService;
import com.fjnu.mon4cc.vo.Json;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 权限 前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/perm")
public class PermController {

    private static final Logger log = LoggerFactory.getLogger(PermController.class);

    @Autowired
    private IPermService iPermService;

    @GetMapping("/list/all")
    public Json listAllPermission() {
        String oper = "list menu,button,api permissions";
        EntityWrapper<Perm> params = new EntityWrapper<>();
        params.in("ptype", new Integer[]{PermType.MENU, PermType.BUTTON, PermType.API});
        List<Perm> list = iPermService.selectList(params);
        if (list.isEmpty()){
            return Json.succ(oper);
        }else{
            Map<Integer, List<Perm>> permMap = list.stream().collect(Collectors.groupingBy(Perm::getPtype));
            List<Perm> buttonPermList = permMap.get(PermType.BUTTON);
            Map<String, List<Perm>> buttonsGroupedByParent = new HashMap<>();
            if (buttonPermList!=null&&!buttonPermList.isEmpty()){
                buttonsGroupedByParent = buttonPermList.stream().collect(Collectors.groupingBy(Perm::getParent));
            }
            return Json.succ(oper, "permMap", permMap).data("btnPermMap", buttonsGroupedByParent);
        }
    }


    @PostMapping("/sync/menu")
    public Json syncMenuPermission(@RequestBody String body) {
        String oper = "sync menu permission";
        log.info("{}, body: {}", oper, body);
        List<Perm> notSyncedPerms = JSON.parseArray(body, Perm.class);
        if (!notSyncedPerms.isEmpty()){
            iPermService.delete(new EntityWrapper<Perm>().eq("ptype",PermType.MENU));
            iPermService.saveOrUpdate(notSyncedPerms);
        }
        return Json.succ(oper);
    }


    @PostMapping
    public Json add(@RequestBody String body) {

        String oper = "add permission";
        Perm perm = JSON.parseObject(body, Perm.class);

        if (StringUtils.isBlank(perm.getPval())) {
            return Json.fail(oper, "Permission value cannot be empty!");
        }

        EntityWrapper<Perm> params = new EntityWrapper<>();
        params.eq("pval", perm.getPval());
        params.setSqlSelect("pname,pval");
        Perm permDB = iPermService.selectOne(params);

        if (permDB != null) {
            return Json.fail(oper, "Permission value already exists：" + permDB.getPname() + "（" + perm.getPval() + "）");
        }

        //保存
        perm.setCreated(new Date().toString());
        boolean success = iPermService.insert(perm);
        return Json.result(oper, success)
                .data("created", perm.getCreated());
    }

    @DeleteMapping
    public Json delete(@RequestBody String body) {
        String oper = "delete permission";
        log.info("{}, body: {}", oper, body);
        JSONObject jsonObj = JSON.parseObject(body);
        String pval = jsonObj.getString("pval");
        if (StringUtils.isBlank(pval)) {
            return Json.fail(oper, "Cannot delete permission: parameter is empty (permission value)!");
        }
        boolean success = iPermService.deleteById(pval);
        return Json.result(oper, success);
    }

    @PatchMapping("/info")
    public Json update(@RequestBody String body) {

        String oper = "update permission";
        log.info("{}, body: {}", oper, body);

        Perm perm = JSON.parseObject(body, Perm.class);
        if (StringUtils.isBlank(perm.getPval())) {
            return Json.fail(oper, "Unable to update permission: parameter is empty (permission value)!");
        }

        Perm updateData = new Perm();
        updateData.setPval(perm.getPval());
        updateData.setPname(perm.getPname());
        updateData.setUpdated(new Date().toString());
        boolean success = iPermService.updateById(updateData);
        return Json.result(oper, success).data("updated", perm.getUpdated());
    }


}
