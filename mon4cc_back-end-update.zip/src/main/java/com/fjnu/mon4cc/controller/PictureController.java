package com.fjnu.mon4cc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Picture;
import com.fjnu.mon4cc.service.IPictureService;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/picture")
public class PictureController {
    private static final Logger log = LoggerFactory.getLogger(PictureController.class);

    @Autowired
    private IPictureService iPictureService;

    @PostMapping("/getMessage")
    public Json getMessage(@RequestBody String body) {
        String oper = "getMessage";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getIntValue("taskId");
        List<Picture> pictures = iPictureService.selectPictures(taskId);
        return Json.succ(oper).data("pictures", pictures);
    }

}
