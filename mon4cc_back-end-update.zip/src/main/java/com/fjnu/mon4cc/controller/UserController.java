package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.constant.Root;
import com.fjnu.mon4cc.entity.User;
import com.fjnu.mon4cc.entity.User_role;
import com.fjnu.mon4cc.service.IRoleService;
import com.fjnu.mon4cc.service.IUserService;
import com.fjnu.mon4cc.service.IUser_roleService;
import com.fjnu.mon4cc.utils.PageUtils;
import com.fjnu.mon4cc.vo.Json;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */

@RestController
@RequestMapping("/user")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private IUserService iUserService;
    @Autowired
    private IRoleService iRoleService;
    @Autowired
    private IUser_roleService iUser_roleService;

    @PostMapping
    public Json add(@RequestBody String body) {

        String oper = "add sys user";
        log.info("{}, body: {}",oper,body);

        User user = JSON.parseObject(body, User.class);

        if (StringUtils.isEmpty(user.getUname())) {
            return Json.fail(oper, "User account name cannot be empty!");
        }
        if (StringUtils.isEmpty(user.getPwd())) {
            return Json.fail(oper, "Password cannot be empty!");
        }

        User userDB = iUserService.selectOne(new EntityWrapper<User>().eq("uname", user.getUname()));
        if (userDB != null) {
            return Json.fail(oper, "User registered!");
        }

        //密码加密
        RandomNumberGenerator saltGen = new SecureRandomNumberGenerator();
        String salt = saltGen.nextBytes().toBase64();
        String hashedPwd = new Sha256Hash(user.getPwd(), salt, 1024).toBase64();  // 使用SHA256算法生成相应的散列数据
        //保存新用户数据
        user.setPwd(hashedPwd);
        user.setSalt(salt);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        user.setCreated(dateFormat.format(new Date()));

        boolean success = iUserService.insert(user);
        return Json.result(oper, success)
                .data("uid",user.getUid())
                .data("created",user.getCreated());
    }

    @DeleteMapping
    public Json delete(@RequestBody String body) {

        String oper = "delete user";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String uid = jsonObj.getString("uid");
        if (StringUtils.isEmpty(uid)) {
            return Json.fail(oper, "Cannot delete user: parameter is empty (user ID)!");
        }

        //限制：不能删当前登录用户
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        if (StringUtils.equals(uid,user.getUid())){
            return Json.fail(oper, "System restriction: the current login account cannot be deleted!");
        }

        //检查：不能删除管理员
        boolean containRoot = iRoleService.checkUidContainRval(uid, Root.ROLE_VAL);
        if (containRoot){
            return Json.fail(oper,"The administrator user cannot be deleted!");
        }

        boolean success = iUserService.deleteById(uid);
        iUser_roleService.delete(new EntityWrapper<User_role>().eq("userId",uid));
        return Json.result(oper, success);
    }

    @PatchMapping("/role")
    public Json updateUserRole(@RequestBody String body) {

        String oper = "update user's roles";
        log.info("{}, body: {}",oper,body);

        JSONObject json = JSON.parseObject(body);
        final String uid = json.getString("uid");

        List<String> rids = json.getJSONArray("rids").toJavaList(String.class);

        //检查：不能含有管理员角色
        boolean containRoot = iRoleService.checkRidsContainRval(rids, Root.ROLE_VAL);
        if (containRoot){
            return Json.fail(oper,"No administrator users cannot be assigned the administrator role!");
        }

        //删除：原来绑定的角色
        boolean deleteSucc = iUser_roleService.delete(new EntityWrapper<User_role>().eq("userId", uid));
        if (!deleteSucc) return Json.fail(oper, "Unable to release the original user role relationship!");

        //更新：绑定新的角色
        List<User_role> list = rids.stream().map(roleId -> new User_role(uid, roleId)).collect(Collectors.toList());

        if (!rids.isEmpty()){
            boolean addSucc = iUser_roleService.insert_batch(list);
            return Json.result(oper, addSucc);
        }
        return Json.succ(oper);
    }

    @PostMapping("/query")
    public Json query(@RequestBody String body) {
        String oper = "query user";
        log.info("{}, body: {}", oper, body);
        JSONObject json = JSON.parseObject(body);
        String nick = json.getString("nick");
        Page<User> page = iUserService.queryUserIncludeRoles(PageUtils.getPageParam(json), nick);
        return Json.succ(oper).data("page", page);
    }

    @GetMapping("/info")
    public Json userInfo() {
        String oper = "query user info";
        log.info("{}", oper);
        Object userInfo = SecurityUtils.getSubject().getPrincipal();
        return Json.succ(oper, "userInfo", userInfo);
    }

    @PatchMapping("/info")
    public Json update(@RequestBody String body) {

        String oper = "update user";
        log.info("{}, body: {}", oper, body);

        User user = JSON.parseObject(body, User.class);

        if (StringUtils.isNotBlank(user.getPwd())){
            //密码加密
            RandomNumberGenerator saltGen = new SecureRandomNumberGenerator();
            String salt = saltGen.nextBytes().toBase64();
            String hashedPwd = new Sha256Hash(user.getPwd(), salt, 1024).toBase64();
            user.setPwd(hashedPwd);
            user.setSalt(salt);
        }else{
            user.setPwd(null);
            user.setSalt(null);
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        user.setUname(null);
        user.setCreated(null);
        user.setUpdated(dateFormat.format(new Date()));

        //boolean success = sysUserService.update(user,new EntityWrapper<User>().eq("uid",user.getUid()));
        boolean success = iUserService.updateById(user);

        return Json.result(oper, success).data("updated",user.getUpdated());
    }

    @PatchMapping("/pwd")
    public Json updatePwd(@RequestBody String body) {

        String oper = "update pwd";
        log.info("{}, body: {}", oper, body);

        JSONObject json = JSON.parseObject(body);
        String pwd = json.getString("pwd");

        if (StringUtils.isBlank(pwd)) {
            return Json.fail(oper,"Password cannot be updated empty!");
        }
        //密码加密
        RandomNumberGenerator saltGen = new SecureRandomNumberGenerator();
        String salt = saltGen.nextBytes().toBase64();
        String hashedPwd = new Sha256Hash(pwd, salt, 1024).toBase64();
        User currentUser = (User) SecurityUtils.getSubject().getPrincipal();

        User updateData = new User();
        updateData.setUid(currentUser.getUid());
        updateData.setPwd(hashedPwd);
        updateData.setSalt(salt);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        updateData.setUpdated(dateFormat.format(new Date()));
        boolean success = iUserService.updateById(updateData);
        return Json.result(oper, success).data("updated",updateData.getUpdated());
    }

    @GetMapping("/{uid}/roles")
    public Json findUserRoles(@PathVariable String uid){
        String oper = "find user roles";
        log.info("{}, uid: {}", oper, uid);
        if (StringUtils.isBlank(uid)){
            return Json.fail(oper, "Unable to query the role value of the current user: the parameter is empty (user ID)!");
        }
        List<String> rids = iRoleService.getRoleIdsByUserId(uid);
        return Json.succ(oper,"rids",rids);
    }


}
