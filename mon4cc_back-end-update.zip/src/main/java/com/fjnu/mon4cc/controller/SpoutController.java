package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Spout;
import com.fjnu.mon4cc.service.ISpoutService;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/spout")
public class SpoutController {
    private static final Logger log = LoggerFactory.getLogger(SpoutController.class);
    @Autowired
    private ISpoutService iSpoutService;
    @PostMapping("/getSpout")
    public Json getSpout(@RequestBody String body){
        String oper = "get a spout";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");

        Spout spout = iSpoutService.select_batch(id,topologyId);
        System.out.println(Json.succ(oper,"id",spout.getId())
                .data("spoutComponentName",spout.getSpoutComponentName())
                .data("spoutParallelism",spout.getSpoutParallelism())
                .data("spoutStream",spout.getSpoutStream()));

        return Json.succ(oper,"id",spout.getId())
                .data("spoutComponentName",spout.getSpoutComponentName())
                .data("spoutParallelism",spout.getSpoutParallelism())
                .data("spoutStream",spout.getSpoutStream());
    }

    @PostMapping("/getSpoutCode")
    public Json getSpoutCode(@RequestBody String body){
        String oper = "get a spoutCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Spout spout = iSpoutService.select_batch(id,topologyId);
        if (spout==null){
            return Json.succ(oper,"spoutCode",null);
        } else return Json.succ(oper,"spoutCode",spout.getSpoutCode());
    }

    @PostMapping("/saveSpoutCode")
    public Json saveSpoutCode(@RequestBody String body){
        String oper = "save a spoutCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        String spoutCode = jsonObj.getString("spoutCode");
        String spoutCodeSimple = jsonObj.getString("spoutCodeSimple");
        boolean success;
        if (iSpoutService.select_batch(id,topologyId)!=null){
            success = iSpoutService.updateCode(id,topologyId,spoutCode,spoutCodeSimple);
        }else {
            success = iSpoutService.insertCode(id,topologyId,spoutCode,spoutCodeSimple);
        }
        return Json.result(oper,success);
    }



}
