package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.constant.PermType;
import com.fjnu.mon4cc.entity.Perm;
import com.fjnu.mon4cc.entity.Role;
import com.fjnu.mon4cc.entity.Role_perm;
import com.fjnu.mon4cc.service.IPermService;
import com.fjnu.mon4cc.service.IRoleService;
import com.fjnu.mon4cc.service.IRole_permService;
import com.fjnu.mon4cc.service.IUser_roleService;
import com.fjnu.mon4cc.vo.Json;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.fjnu.mon4cc.vo.UpdateRolePermVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
//
@RestController
@RequestMapping("/role")
public class RoleController {

    private static final Logger log = LoggerFactory.getLogger(RoleController.class);

    @Autowired
    private IRoleService roleService;
    @Autowired
    private IPermService permService;
    @Autowired
    private IRole_permService iRole_permService;


    @PostMapping
    public Json add(@RequestBody String body) {

        String oper = "add role";
        Role role = JSON.parseObject(body, Role.class);

        if (StringUtils.isBlank(role.getRval())) {
            return Json.fail(oper, "Permission value cannot be empty!");
        }

        Role roleDB = roleService.selectOne(new EntityWrapper<Role>().eq("rval", role.getRval()));
        if (roleDB != null) {
            return Json.fail(oper, "Role value already exists：" + role.getRval());
        }

        //保存新用户数据
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        role.setCreated(dateFormat.format(new Date()));
        boolean success = roleService.insert(role);
        return Json.result(oper, success)
                .data("rid",role.getRid())
                .data("created",role.getCreated());
    }

    @DeleteMapping
    public Json delete(@RequestBody String body) {

        String oper = "delete role";
        log.info("{}, body: {}", oper, body);

        JSONObject jsonObj = JSON.parseObject(body);
        String rid = jsonObj.getString("rid");

        if (StringUtils.isBlank(rid)) {
            return Json.fail(oper, "Cannot delete role: parameter is empty (role ID)!");
        }

        boolean success = roleService.deleteById(rid);
        return Json.result(oper, success);
    }

    @PostMapping("/query")
    public Json query(@RequestBody String body) {

        String oper = "query role";
        log.info("{}, body: {}", oper, body);

        JSONObject json = JSON.parseObject(body);
        String rname = json.getString("rname");
        int current = json.getIntValue("current");
        int size = json.getIntValue("size");
        if (current == 0) current = 1;
        if (size == 0) size = 10;

        Wrapper<Role> queryParams = new EntityWrapper<>();
        queryParams.orderBy("created", false);
        queryParams.orderBy("updated", false);
        if (StringUtils.isNotBlank(rname)) {
            queryParams.like("rname", rname);
        }
        Page<Role> page = roleService.selectPage(new Page<>(current, size), queryParams);
        return Json.succ(oper).data("page", page);
    }

    @PatchMapping("/info")
    public Json update(@RequestBody String body) {

        String oper = "update role";
        log.info("{}, body: {}", oper, body);

        Role role = JSON.parseObject(body, Role.class);
        if (StringUtils.isBlank(role.getRid())) {
            return Json.fail(oper, "Cannot update role: parameter is empty (role ID)!");
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        role.setUpdated(dateFormat.format(new Date()));
        boolean success = roleService.updateById(role);
        return Json.result(oper, success).data("updated", role.getUpdated());
    }


    @PatchMapping("/perm")
    public Json updateRolePerm(@RequestBody UpdateRolePermVo vo) {

        String oper = "update role's permissions";

        if (StringUtils.isBlank(vo.getRid())) {
            return Json.fail(oper, "Cannot update permissions for role: parameter is empty (role ID)!");
        }
        if (vo.getPtype()==null){
            return Json.fail(oper, "Unable to update permissions for role: parameter is empty (permission type)!");
        }
        final String rid = vo.getRid();
        final Integer ptype = vo.getPtype();
        final List<String> pvals = vo.getPvals();

        Wrapper<Role_perm> deleteRelationParam = new EntityWrapper<Role_perm>().eq("roleId", rid).eq("permType", ptype);
        boolean deleteRelationSucc = iRole_permService.delete(deleteRelationParam);
        if (!deleteRelationSucc) return Json.fail(oper, "Unable to release the original role permission relationship!");

        if (!pvals.isEmpty()){
            List<Role_perm> list = vo.getPvals().stream().map(pval -> new Role_perm(rid, pval,ptype)).collect(Collectors.toList());
            boolean addSucc = iRole_permService.insert_batch(list);
            return Json.result(oper, addSucc);
        }
        return Json.succ(oper);
    }


    @PostMapping("/perm")
    public Json addPerm(@RequestBody String body){
        String oper = "add role's permissions";

        JSONObject json = JSON.parseObject(body);
        String rid = json.getString("rid");
        Integer ptype = json.getInteger("ptype");
        String pval = json.getString("pval");

        boolean success = iRole_permService.insert(new Role_perm(rid, pval, ptype));
        return Json.result(oper,success);
    }


    @DeleteMapping("/perm")
    public Json deletePerm(@RequestBody String body){
        String oper = "delete role's permissions";

        JSONObject json = JSON.parseObject(body);
        String rid = json.getString("rid");
        Integer ptype = json.getInteger("ptype");
        String pval = json.getString("pval");

        Wrapper<Role_perm> deleteParam = new EntityWrapper<Role_perm>()
                .eq("roleId", rid)
                .eq("permVal", pval)
                .eq("permType", ptype);
        boolean success = iRole_permService.delete(deleteParam);
        return Json.succ(oper,success);
    }


    @GetMapping("/{rid}/perms")
    public Json findRolePerms(@PathVariable String rid){
        String oper = "find role perms";
        log.info("{}, rid: {}", oper, rid);
        if (StringUtils.isBlank(rid)){
            return Json.fail(oper, "Cannot query permission value of current role: parameter is empty (role ID)!");
        }
        Role role = roleService.selectById(rid);
        List<Perm> perms = permService.getPermsByRoleId(rid);
        Map<Integer, List<Perm>> permMap = perms.stream().collect(Collectors.groupingBy(Perm::getPtype));

        List<String> menuPvals = permMap.getOrDefault(PermType.MENU, new ArrayList<>()).stream()
                .filter(perm->perm.getLeaf()==true).map(Perm::getPval).collect(Collectors.toList());  //抽取对象中所有的pval的集合

        List<String> btnPvals = permMap.getOrDefault(PermType.BUTTON, new ArrayList<>()).stream()
                .map(Perm::getPval).collect(Collectors.toList());

        List<String> apiPvals = permMap.getOrDefault(PermType.API, new ArrayList<>()).stream()
                .filter(perm->perm.getLeaf()==true).map(Perm::getPval).collect(Collectors.toList());

        return Json.succ(oper)
                .data("role",role)
                .data("menuPvals",menuPvals)
                .data("btnPvals",btnPvals)
                .data("apiPvals",apiPvals);
    }



}
