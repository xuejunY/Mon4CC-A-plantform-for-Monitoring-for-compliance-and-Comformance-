package com.fjnu.mon4cc.entity;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Flow implements Serializable {

    private static final long serialVersionUID = 1L;

    private String groupingId;

    private String sourceComponent;

    private String targetComponent;

    private String groupingType;

    private String stream;

    private String topologyId;

    public String getGroupingId() {
        return groupingId;
    }

    public void setGroupingId(String groupingId) {
        this.groupingId = groupingId;
    }
    public String getSourceComponent() {
        return sourceComponent;
    }

    public void setSourceComponent(String sourceComponent) {
        this.sourceComponent = sourceComponent;
    }
    public String getTargetComponent() {
        return targetComponent;
    }

    public void setTargetComponent(String targetComponent) {
        this.targetComponent = targetComponent;
    }
    public String getGroupingType() {
        return groupingType;
    }

    public void setGroupingType(String groupingType) {
        this.groupingType = groupingType;
    }
    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }
    public String getTopologyId() {
        return topologyId;
    }

    public void setTopologyId(String topologyId) {
        this.topologyId = topologyId;
    }

    @Override
    public String toString() {
        return "Grouping{" +
            "groupingId=" + groupingId +
            ", sourceComponent=" + sourceComponent +
            ", targetComponent=" + targetComponent +
            ", grouping=" + groupingType +
            ", stream=" + stream +
            ", topologyId=" + topologyId +
        "}";
    }
}
