package com.fjnu.mon4cc.entity;

import java.io.Serializable;

public class MonitorTask implements Serializable {
    private static final long serialVersionUID = 1L;

    private int taskId;

    private String sId;

    private String taskName;

    private String modelId;

    private String state;

    private String description;

    private String createTime;

    private String modelEcl;

    private String modelXml;

    private String creater;
    /**
     * 处理事件数
     */
    private int readAmount;
    /**
     * 用时
     */
    private int timeUsed;
    /**
     * 违规信息数量
     */
    private int failSummary;
    /**
     * 合规信息数量
     */
    private int succSummary;

    /**
     * 运行时间
     */
    private String startDate;


    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }


    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModelEcl() {
        return modelEcl;
    }

    public void setModelEcl(String modelEcl) {
        this.modelEcl = modelEcl;
    }

    public int getReadAmount() {
        return readAmount;
    }

    public void setReadAmount(int readAmount) {
        this.readAmount = readAmount;
    }

    public int getTimeUsed() {
        return timeUsed;
    }

    public void setTimeUsed(int timeUsed) {
        this.timeUsed = timeUsed;
    }

    public int getFailSummary() {
        return failSummary;
    }

    public void setFailSummary(int failSummary) {
        this.failSummary = failSummary;
    }

    public int getSuccSummary() {
        return succSummary;
    }

    public void setSuccSummary(int succSummary) {
        this.succSummary = succSummary;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getModelXml() {
        return modelXml;
    }

    public void setModelXml(String modelXml) {
        this.modelXml = modelXml;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }
}
