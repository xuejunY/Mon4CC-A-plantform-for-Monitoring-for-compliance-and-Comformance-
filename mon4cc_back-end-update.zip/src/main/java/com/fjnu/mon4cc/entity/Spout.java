package com.fjnu.mon4cc.entity;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Spout implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    private String spoutComponentName;

    private Integer spoutParallelism;

    private String spoutStream;

    private String topologyId;

    private String spoutCode;

    private String spoutCodeSimple;

    private String completeSpoutCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getSpoutComponentName() {
        return spoutComponentName;
    }

    public void setSpoutComponentName(String spoutComponentName) {
        this.spoutComponentName = spoutComponentName;
    }
    public Integer getSpoutParallelism() {
        return spoutParallelism;
    }

    public void setSpoutParallelism(Integer spoutParallelism) {
        this.spoutParallelism = spoutParallelism;
    }
    public String getSpoutStream() {
        return spoutStream;
    }

    public void setSpoutStream(String spoutStream) {
        this.spoutStream = spoutStream;
    }
    public String getTopologyId() {
        return topologyId;
    }

    public void setTopologyId(String topologyId) {
        this.topologyId = topologyId;
    }
    public String getSpoutCode() {
        return spoutCode;
    }

    public void setSpoutCode(String spoutCode) {
        this.spoutCode = spoutCode;
    }
    public String getSpoutCodeSimple() {
        return spoutCodeSimple;
    }

    public void setSpoutCodeSimple(String spoutCodeSimple) {
        this.spoutCodeSimple = spoutCodeSimple;
    }

    public String getCompleteSpoutCode() {
        return completeSpoutCode;
    }

    public void setCompleteSpoutCode(String completeSpoutCode) {
        this.completeSpoutCode = completeSpoutCode;
    }
}
