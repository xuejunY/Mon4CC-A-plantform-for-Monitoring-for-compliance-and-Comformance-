package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Deployment;

/**
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IDeploymentService extends IService<Deployment> {
    Page<Deployment> queryDeploymentConfig(Page pageParam, String deployName,String creater);

    boolean insert_bance(Deployment deployment);

    boolean deleteByDId(int deploymentId);

    boolean update_bance(Deployment deployment);

    boolean update_state(int deploymentId, String state);

    boolean submit_bance(Deployment deployment);
}
