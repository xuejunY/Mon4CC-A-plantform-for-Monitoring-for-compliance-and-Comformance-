package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.connector.entity.MonitorState;
import com.fjnu.mon4cc.connector.entity.Response;
import com.fjnu.mon4cc.connector.entity.SimpleState;
import com.fjnu.mon4cc.connector.entity.TextFeignFileResource;
import com.fjnu.mon4cc.connector.url.RestURL;
import com.fjnu.mon4cc.entity.Modelconfiguration;
import com.fjnu.mon4cc.entity.MonitorTask;
import com.fjnu.mon4cc.mapper.MonitorTaskMapper;
import com.fjnu.mon4cc.service.IModelconfigurationService;
import com.fjnu.mon4cc.service.IMonitorTaskService;
import com.fjnu.mon4cc.vo.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class MonitorTaskServiceImpl extends ServiceImpl<MonitorTaskMapper, MonitorTask> implements IMonitorTaskService {
    @Autowired
    private IMonitorTaskService iMonitorTaskService;
    @Autowired
    private IModelconfigurationService iModelconfigurationService;
    @Override
    public boolean insert_bance(MonitorTask monitorTask) {
        return baseMapper.insertTask(monitorTask);
    }

    @Override
    public Page<MonitorTask> queryMonitorTask(Page page, String taskName,String creater) {
        return page.setRecords(baseMapper.selectMonitorTask(page,taskName,creater));
    }

    @Override
    public boolean deleteByTId(int taskId) {
        return baseMapper.deleteTask(taskId);
    }

    @Override
    public boolean update_state(int taskId, String state) {
        return baseMapper.updateState(taskId,state);
    }

    @Override
    public MonitorTask selectMonitorTask(int taskId) {
        return baseMapper.selectTask(taskId);
    }

    @Override
    public boolean update_bance(MonitorTask monitorTask) {
        return baseMapper.updateTask(monitorTask);
    }

    @Override
    public boolean update_bance_result(MonitorTask monitorTask) {
        return baseMapper.updateTask_result(monitorTask);
    }

    @Override
    public boolean commit(int taskId, String modelId) {
        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        Modelconfiguration modelconfiguration = iModelconfigurationService.select_bance(modelId);

        MultiValueMap<String, Object> param = new LinkedMultiValueMap<>();
        TextFeignFileResource eclFile = new TextFeignFileResource(modelconfiguration.getModelName() + ".ecl", monitorTask.getModelEcl());
        param.add("eclFile", eclFile);
        HttpEntity<MultiValueMap<String,Object>> httpEntity = new HttpEntity<>(param);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.postForEntity(RestURL.SUBMIT, httpEntity, Response.class);

        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            String sId = response.getData().getsId();
            monitorTask.setsId(sId);
            boolean success = iMonitorTaskService.update_bance(monitorTask);
            return success;
        } else {
            return false;
        }
    }

    @Override
    public boolean commit_ST(MultipartFile file, int taskId) throws IOException {
        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        MultiValueMap<String, Object> param = new LinkedMultiValueMap<>();
        File tmp = File.createTempFile("temp", null);
        file.transferTo(tmp);
        tmp.deleteOnExit();
        param.add("eclFile", new FileSystemResource(tmp));
        HttpEntity<MultiValueMap<String,Object>> httpEntity = new HttpEntity<>(param);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.postForEntity(RestURL.SUBMIT, httpEntity, Response.class);

        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            String sId = response.getData().getsId();
            monitorTask.setsId(sId);
            boolean success = iMonitorTaskService.update_bance(monitorTask);
            return success;
        } else {
            return false;
        }
    }

    @Override
    public boolean fileConfigTask(MultipartFile file, String sId, int taskId) throws IOException {
        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        MultiValueMap<String, Object> param = new LinkedMultiValueMap<>();
        File tmp = File.createTempFile("temp", null);
        file.transferTo(tmp);
        tmp.deleteOnExit();
        param.add("dataFile", new FileSystemResource(tmp));
        param.add("sId", sId);
        param.add("sourceType", "JSON_FILE");
        HttpEntity<MultiValueMap> httpEntity = new HttpEntity<>(param);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.postForEntity(RestURL.CONFIG, httpEntity, Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            monitorTask.setState("configured");
            boolean success = iMonitorTaskService.update_state(monitorTask.getTaskId(),monitorTask.getState());
            return success;

        } else {
            return false;
        }
    }

    @Override
    public boolean startTask(String sId) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.TASK_RUN + sId, Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public SimpleState taskSimpleState(String sId) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.TASK_SIMPLE_STATE + sId, Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")){
            return response.getData().getSimpleState();
        }
        return null;

    }

    @Override
    public MonitorState taskState(String sId) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.TASK_STATE + sId, Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")){
            return response.getData().getMonitorState();
        }
        return null;
    }

    @Override
    public List<MonitorTask> findRunningTasks() {
        return baseMapper.findRunningTasks();
    }

    @Override
    public boolean stopTask(String sId) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.TASK_STOP + sId, Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            return true;
        } else {
            return false;
        }
    }



}
