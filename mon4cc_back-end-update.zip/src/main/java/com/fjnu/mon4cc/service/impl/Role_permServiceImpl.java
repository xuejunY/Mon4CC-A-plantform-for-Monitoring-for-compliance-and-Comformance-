package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Role_perm;
import com.fjnu.mon4cc.mapper.Role_permMapper;
import com.fjnu.mon4cc.service.IRole_permService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class Role_permServiceImpl extends ServiceImpl<Role_permMapper, Role_perm> implements IRole_permService {

    @Override
    public boolean insert_batch(List<Role_perm> list) {
        for (Role_perm role_perm : list) {
            baseMapper.addRolePerm(role_perm);
        }
        return true;
    }
}
