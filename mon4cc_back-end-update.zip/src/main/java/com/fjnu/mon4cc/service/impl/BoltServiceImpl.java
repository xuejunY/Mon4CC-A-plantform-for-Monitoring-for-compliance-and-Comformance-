package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Bolt;
import com.fjnu.mon4cc.mapper.BoltMapper;
import com.fjnu.mon4cc.service.IBoltService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class BoltServiceImpl extends ServiceImpl<BoltMapper, Bolt> implements IBoltService {


    @Override
    public Bolt select_batch(String id, String topologyId) {
        return baseMapper.selectBolt(id,topologyId);
    }

    @Override
    public boolean updateCode(String id, String topologyId, String boltCode, String boltCodeSimple) {
        return baseMapper.updateCode(id,topologyId,boltCode,boltCodeSimple);
    }

    @Override
    public boolean insertCode(String id, String topologyId, String boltCode, String boltCodeSimple) {
        return baseMapper.insertCode(id,topologyId,boltCode,boltCodeSimple);
    }

    @Override
    public List<Bolt> selectCompleteCode(String topologyId) {
        return baseMapper.selectCompleteCode(topologyId);
    }
}
