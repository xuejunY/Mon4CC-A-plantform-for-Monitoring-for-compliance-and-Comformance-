package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.User;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IUserService extends IService<User> {

    Page<User> queryUserIncludeRoles(Page pageParam, String nick);
}
