package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Spout;
import com.fjnu.mon4cc.mapper.SpoutMapper;
import com.fjnu.mon4cc.service.ISpoutService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class SpoutServiceImpl extends ServiceImpl<SpoutMapper, Spout> implements ISpoutService {

    @Override
    public Spout select_batch(String id, String topologyId) {
        return baseMapper.selectSpout(id,topologyId);
    }

    @Override
    public boolean updateCode(String id, String topologyId, String spoutCode, String spoutCodeSimple) {
        return baseMapper.updateCode(id,topologyId,spoutCode,spoutCodeSimple);
    }

    @Override
    public boolean insertCode(String id, String topologyId, String spoutCode, String spoutCodeSimple) {
        return baseMapper.insertCode(id,topologyId,spoutCode,spoutCodeSimple);
    }

    @Override
    public List<Spout> selectCompleteCode(String topologyId) {
        return baseMapper.selectCompleteCode(topologyId);
    }
}
