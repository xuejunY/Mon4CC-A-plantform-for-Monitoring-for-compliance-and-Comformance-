package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.ResultDetails;
import com.fjnu.mon4cc.mapper.ResultDetailsMapper;
import com.fjnu.mon4cc.service.IResultDetailsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ResultDetailsServiceImpl extends ServiceImpl<ResultDetailsMapper, ResultDetails> implements IResultDetailsService {
    @Override
    public boolean insertResult(ResultDetails resultDetails) {
        return baseMapper.insertResultDetails(resultDetails);
    }

    @Override
    public List<ResultDetails> selecResults(int taskId) {
        return baseMapper.selectResultsBytaskId(taskId);
    }

    @Override
    public void deleteBytaskId(int taskId) {
        baseMapper.deleteBytaskId(taskId);
    }

    @Override
    public Page<ResultDetails> queryResultsByTaskId(Page page, int taskId,String sId) {
        return page.setRecords(baseMapper.selectResultsByTaskId(page,taskId,sId));
    }
}
