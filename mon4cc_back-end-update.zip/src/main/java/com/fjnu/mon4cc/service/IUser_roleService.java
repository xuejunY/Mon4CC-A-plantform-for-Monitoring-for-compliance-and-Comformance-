package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Role_perm;
import com.fjnu.mon4cc.entity.User_role;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IUser_roleService extends IService<User_role> {
    boolean insert_batch(List<User_role> list);

}
