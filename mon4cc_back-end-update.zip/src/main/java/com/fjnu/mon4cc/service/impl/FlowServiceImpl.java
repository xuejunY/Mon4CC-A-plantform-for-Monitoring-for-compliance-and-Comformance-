package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Flow;
import com.fjnu.mon4cc.mapper.FlowMapper;
import com.fjnu.mon4cc.service.IFlowService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class FlowServiceImpl extends ServiceImpl<FlowMapper, Flow> implements IFlowService {

    @Override
    public Flow select_batch(String groupingId, String topologyId) {
        return baseMapper.selectGrouping(groupingId,topologyId);
    }
}
