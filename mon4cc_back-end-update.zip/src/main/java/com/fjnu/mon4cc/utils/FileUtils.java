package com.fjnu.mon4cc.utils;

import org.springframework.beans.factory.annotation.Value;

import java.io.*;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipOutputStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;

public class FileUtils {

    private static String fileUploadPath = "D:\\finalwork\\upload";

    private static String fileUploadPath1 = "D:\\com\\mon4cc";

//    private static String fileUploadPath = "C:\\Users\\Administrator\\finalwork\\upload";
//
//    private static String fileUploadPath1 = "C:\\Users\\Administrator\\com\\mon4cc";

    public static File generateJavaFile(String componentName, String code){
        File file = null;
        FileWriter writer = null;
        BufferedWriter bf = null;
        try {
            file = new File(fileUploadPath + "\\" + componentName + ".java");
            writer = new FileWriter(file);
            bf = new BufferedWriter(writer);
            bf.write(code);
            bf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public static File generateJavaFile1(String componentName, String code){
        File file = null;
        FileWriter writer = null;
        BufferedWriter bf = null;
        try {
            file = new File(fileUploadPath1 + "\\" + componentName + ".java");
            writer = new FileWriter(file);
            bf = new BufferedWriter(writer);
            bf.write(code);
            bf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public static File compressionFile(List<File> srcFile, String zipFilePath) {
        File zipFile = new File(zipFilePath);
        byte[] buffer = new byte[1024];
        try {
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFile));
            for (File value : srcFile) {
                FileInputStream fileInputStream = new FileInputStream(value);
                out.putNextEntry(new ZipEntry(value.getName()));
                int length;
                while ((length = fileInputStream.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
                out.closeEntry();
                fileInputStream.close();
            }
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return zipFile;
    }

    /**
     * zip解压
     *
     * @throws IOException
     */
    public static void unZipFiles(String fileAddress, String unZipAddress) throws IOException {

        //去目录下寻找文件
        File file = new File(fileAddress);
        ZipFile zipFile = null;
        try {
            zipFile = new ZipFile(file,"GBK");//设置编码格式
        } catch (IOException exception) {
            exception.printStackTrace();
            System.out.println("The unzipped file does not exist !");
        }
        Enumeration e = zipFile.getEntries();
        while(e.hasMoreElements()) {
            ZipEntry zipEntry = (ZipEntry)e.nextElement();
            if(zipEntry.isDirectory()) {
                String name = zipEntry.getName();
                name = name.substring(0,name.length()-1);
                File f = new File(unZipAddress + name);
                f.mkdirs();
            } else {
                File f = new File(unZipAddress + zipEntry.getName());
                f.getParentFile().mkdirs();
                f.createNewFile();
                InputStream is = zipFile.getInputStream(zipEntry);
                FileOutputStream fos = new FileOutputStream(f);
                int length = 0;
                byte[] b = new byte[1024];
                while((length=is.read(b, 0, 1024))!=-1) {
                    fos.write(b, 0, length);
                }
                is.close();
                fos.close();
            }
        }
        if (zipFile != null) {
            zipFile.close();
        }
        file.deleteOnExit();//解压完以后将压缩包删除
    }

}
