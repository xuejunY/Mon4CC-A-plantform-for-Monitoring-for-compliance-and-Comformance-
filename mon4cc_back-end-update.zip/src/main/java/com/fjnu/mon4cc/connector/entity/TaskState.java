package com.fjnu.mon4cc.connector.entity;

/**
 * 任务状态
 */
public enum  TaskState {
    NOSUBMITTED,
    SUBMITTED,
    CONFIGED,
    NEW,
    RUNNING,
    FINISHED,
    STOPPED
}
