package com.fjnu.mon4cc.connector.entity;

/**
 * 引擎状态
 */

public class EngineStatus {
    private String corePoolSize;
    private String maxPoolSize;
    private String poolSize;
    private String activeCount;
    /**
     * 已完成任务数
     */
    private String completedTaskCount;

    public String getCorePoolSize() {
        return corePoolSize;
    }

    public void setCorePoolSize(String corePoolSize) {
        this.corePoolSize = corePoolSize;
    }

    public String getMaxPoolSize() {
        return maxPoolSize;
    }

    public void setMaxPoolSize(String maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

    public String getPoolSize() {
        return poolSize;
    }

    public void setPoolSize(String poolSize) {
        this.poolSize = poolSize;
    }

    public String getActiveCount() {
        return activeCount;
    }

    public void setActiveCount(String activeCount) {
        this.activeCount = activeCount;
    }

    public String getCompletedTaskCount() {
        return completedTaskCount;
    }

    public void setCompletedTaskCount(String completedTaskCount) {
        this.completedTaskCount = completedTaskCount;
    }
}
