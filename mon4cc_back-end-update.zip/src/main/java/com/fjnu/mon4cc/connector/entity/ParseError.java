package com.fjnu.mon4cc.connector.entity;



/**
 * 语法解析错误
 */
@Deprecated
public class ParseError {
    /**
     * 错误所在行号
     */
    private String line;
    /**
     * 错误所在列
     */
    private String charPositionInLine;
    /**
     * 错误信息
     */
    private String msg;

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getCharPositionInLine() {
        return charPositionInLine;
    }

    public void setCharPositionInLine(String charPositionInLine) {
        this.charPositionInLine = charPositionInLine;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
