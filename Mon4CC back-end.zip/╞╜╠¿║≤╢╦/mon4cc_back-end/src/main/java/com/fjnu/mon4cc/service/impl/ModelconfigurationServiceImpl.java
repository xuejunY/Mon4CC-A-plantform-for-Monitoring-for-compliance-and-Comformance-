package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Modelconfiguration;
import com.fjnu.mon4cc.mapper.ModelconfigurationMapper;
import com.fjnu.mon4cc.service.IModelconfigurationService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class ModelconfigurationServiceImpl extends ServiceImpl<ModelconfigurationMapper, Modelconfiguration> implements IModelconfigurationService {


    @Override
    public Page<Modelconfiguration> queryTopologyConfig(Page page, String topologyName,String creater) {
        return page.setRecords(baseMapper.selectTopologyConfig(page,topologyName,creater));
    }

    @Override
    public Modelconfiguration select_bance(String topologyId) {
        return  baseMapper.selectBytopologyId(topologyId);
    }

    @Override
    public boolean insert_bance(Modelconfiguration modelconfiguration) {
        return baseMapper.insertTopology(modelconfiguration);

    }

    @Override
    public boolean deleteByTid(String topologyId) {
        return baseMapper.deleteTopology(topologyId);
    }

    @Override
    public boolean update_bance(Modelconfiguration modelconfiguration) {
        return baseMapper.updateTopology(modelconfiguration);
    }

    @Override
    public List<Modelconfiguration> selectCompleteCode(String topologyId) {
        return baseMapper.selectCompleteCode(topologyId);
    }

    @Override
    public boolean update_state(String topologyId, String state) {
        return baseMapper.updateState(topologyId,state);
    }

    @Override
    public List<Modelconfiguration> select_modelIds(String typeName,String creater) {
        return baseMapper.selectModelIds(typeName,creater);
    }
}
