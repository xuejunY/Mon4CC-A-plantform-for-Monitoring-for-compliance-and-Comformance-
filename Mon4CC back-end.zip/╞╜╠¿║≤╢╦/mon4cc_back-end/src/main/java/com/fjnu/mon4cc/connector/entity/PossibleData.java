package com.fjnu.mon4cc.connector.entity;

import java.util.List;

/**
 * 方便解析，不需要为每种Reponse的data都创建一个实体类，在实际情况中，只会有以下之一的参数
 */
//@Data 这里不能用@Data，会导致sId解析不出来。所以直接码setter、getter
public class PossibleData {
    private String sId;
    private List<String> parseErrors;
    private TaskState currentState;
    private String isRunning;
    private MonitorState monitorState;
    private EngineStatus engine_status;
    private SimpleState simpleState;

    public SimpleState getSimpleState() {
        return simpleState;
    }

    public void setSimpleState(SimpleState simpleState) {
        this.simpleState = simpleState;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public List<String> getParseErrors() {
        return parseErrors;
    }

    public void setParseErrors(List<String> parseErrors) {
        this.parseErrors = parseErrors;
    }

    public TaskState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(TaskState currentState) {
        this.currentState = currentState;
    }

    public String getIsRunning() {
        return isRunning;
    }

    public void setIsRunning(String isRunning) {
        this.isRunning = isRunning;
    }

    public MonitorState getMonitorState() {
        return monitorState;
    }

    public void setMonitorState(MonitorState monitorState) {
        this.monitorState = monitorState;
    }

    public EngineStatus getEngine_status() {
        return engine_status;
    }

    public void setEngine_status(EngineStatus engine_status) {
        this.engine_status = engine_status;
    }
}
