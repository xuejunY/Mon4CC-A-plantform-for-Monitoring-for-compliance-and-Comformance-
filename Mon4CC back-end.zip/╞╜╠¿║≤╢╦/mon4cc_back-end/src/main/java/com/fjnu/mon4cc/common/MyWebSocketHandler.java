package com.fjnu.mon4cc.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

@Slf4j
@Service
public class MyWebSocketHandler extends TextWebSocketHandler {
    /**
     * key:topic 用户监听的任务id
     * value:session 用户浏览器与服务端的会话（连接）
     */
    private ConcurrentHashMap<String, Set<WebSocketSession>> sessions = new ConcurrentHashMap<>();
    /**
     * Session和topic的映射，可通过session找到其订阅的topic
     */
    private ConcurrentHashMap<WebSocketSession, String> sessionTopicMap = new ConcurrentHashMap<>();


    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        log.info("建立连接:[{}]", session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        log.info("断开连接:[{}]", session);
        //1.从映射表中移除
        String topic = sessionTopicMap.get(session);
        sessionTopicMap.remove(session);
        //2.从订阅者中移除
        Set<WebSocketSession> topicSubscribers = sessions.get(topic);
        topicSubscribers.remove(session);
        //3.如果移除此会话后，相应的topic没有其他订阅者，则连集合一块移除。
        if(topicSubscribers.size() == 0) {
            sessions.remove(topic);
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        log.info("收到订阅消息:[{}]", message);
        //1.添加到映射表
        String topic = message.getPayload();
        sessionTopicMap.put(session, topic);
        //2.添加到同一个topic的订阅者集合中
        Set<WebSocketSession> topicSubscribers = sessions.get(topic);
        if(topicSubscribers == null) {
            topicSubscribers = new CopyOnWriteArraySet<>();
        }
        topicSubscribers.add(session);
        sessions.put(topic, topicSubscribers);
    }

    /**
     *
     * @param topic 主题
     * @param message 消息内容
     * @throws IOException
     */
    public void sendMessage(String topic, String message) throws IOException {
        Set<WebSocketSession> topicSubscribers = sessions.get(topic);
        if(topicSubscribers == null || topicSubscribers.size() == 0)
            return;
        for(WebSocketSession subscriber: topicSubscribers) {
            log.info("向{}发送消息:{}", subscriber, message);
            subscriber.sendMessage(new TextMessage(message));
        }
    }

}
