package com.fjnu.mon4cc.connector.entity;


import java.util.Map;

public class SimpleState {
    /**
     * 状态(RUNNING, STOPED, FINISHED)
     */
    private String state;
    /**
     * 处理事件数
     */
    private String readAmount;
    /**
     * 用时
     */
    private long timeUsed;
    /**
     * 违规信息
     */
    private Map<String, String> failSummary;
    /**
     * 合规信息
     */
    private Map<String, String> succSummary;
    /**
     * 请求时间
     */
    private String accessDate;
    /**
     * 运行时间
     */
    private String startDate;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getReadAmount() {
        return readAmount;
    }

    public void setReadAmount(String readAmount) {
        this.readAmount = readAmount;
    }

    public long getTimeUsed() {
        return timeUsed;
    }

    public void setTimeUsed(long timeUsed) {
        this.timeUsed = timeUsed;
    }

    public Map<String, String> getFailSummary() {
        return failSummary;
    }

    public void setFailSummary(Map<String, String> failSummary) {
        this.failSummary = failSummary;
    }

    public Map<String, String> getSuccSummary() {
        return succSummary;
    }

    public void setSuccSummary(Map<String, String> succSummary) {
        this.succSummary = succSummary;
    }

    public String getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(String accessDate) {
        this.accessDate = accessDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
}
