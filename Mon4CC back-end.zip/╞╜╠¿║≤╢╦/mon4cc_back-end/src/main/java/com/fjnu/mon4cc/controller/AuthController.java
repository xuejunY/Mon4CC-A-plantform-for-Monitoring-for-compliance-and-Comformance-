package com.fjnu.mon4cc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.constant.Codes;
import com.fjnu.mon4cc.entity.User;
import com.fjnu.mon4cc.vo.Json;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.UUID;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    /**
     * shiro.loginUrl映射到这里，我在这里直接抛出异常交给GlobalExceptionHandler来统一返回json信息
     * @return
     */
    @RequestMapping("/page/401")
    public Json page401() {
        throw new UnauthenticatedException();
    }

    /**
     * shiro.unauthorizedUrl映射到这里。由于约定了url方式只做鉴权控制，不做权限访问控制，
     * 也就是说在ShiroConfig中如果没有做roles[js],perms[mvn:install]这样的权限访问控制配置的话，是不会跳转到这里的。
     * @return
     */
    @RequestMapping("/page/403")
    public Json page403() {
        throw new UnauthorizedException();
    }

    /**
     * 登录成功跳转到这里，直接返回json。但是实际情况是在login方法中登录成功后返回json了。
     * @return
     */
    @RequestMapping("/page/index")
    public Json pageIndex() {
        return new Json("index",true,1,"index page",null);
    }

    /**
     * 登录接口，由于UserService中是模拟返回用户信息的，
     * 所以用户名随意，密码123456
     *
     * @param body
     * @return
     */
    @PostMapping("/login")
    public Json login(@RequestBody String body){

        String oper = "user login";
        log.info("{}, body: {}",oper,body);

        JSONObject json = JSON.parseObject(body);
        String uname = json.getString("uname");
        String pwd = json.getString("pwd");

        if (StringUtils.isEmpty(uname)){
            return Json.fail(oper,"The user name cannot be empty!");
        }
        if (StringUtils.isEmpty(pwd)){
            return Json.fail(oper,"The password cannot be empty!");
        }

        Subject currentUser = SecurityUtils.getSubject();

        try {
            //登录
            currentUser.login( new UsernamePasswordToken(uname, pwd) );
            //从session取出用户信息
            User user = (User) currentUser.getPrincipal();
            if (user==null) throw new AuthenticationException();
            log.info("user login: {}, sessionId: {}",user.getUname(),currentUser.getSession().getId());
            //返回登录用户的信息给前台，含用户的所有角色和权限
            return Json.succ(oper)
                    .data("token", UUID.randomUUID().toString())
                    .data("uid",user.getUid())
                    .data("nick",user.getNick())
                    .data("roles",user.getRoles())
                    .data("perms",user.getPerms());
        } catch ( UnknownAccountException uae ) {
            log.warn("Incorrect user account!");
            return Json.fail(oper,"Incorrect user account or password!");

        } catch ( IncorrectCredentialsException ice ) {
            log.warn("Incorrect user password!");
            return Json.fail(oper,"Incorrect user account or password!");

        } catch ( LockedAccountException lae ) {
            log.warn("User account locked!");
            return Json.fail(oper,"The user account is locked and unavailable!");

        } catch ( AuthenticationException ae ) {
            log.warn("Login error!");
            return Json.fail(oper,"Login failed："+ae.getMessage());
        }
    }

    @PostMapping("/logout")
    public Json logout(){
        String oper = "user logout";
        log.info("{}",oper);
        SecurityUtils.getSubject().logout();
        return new Json(oper);
    }

    @GetMapping("/info")
    public Json info(){
        String oper = "get user info";

        Subject subject = SecurityUtils.getSubject();

        Serializable sessionId = subject.getSession().getId();
        log.info("{}, sessionId: {}",oper,sessionId);
        //从session取出用户信息
        User user = (User) subject.getPrincipal();
        if (user==null){
            //告知前台，登录失效
            return new Json(oper,false, Codes.SESSION_TIMEOUT,"Login disabled",null);
        }else{
            //返回登录用户的信息给前台，含用户的所有角色和权限
            return Json.succ(oper)
                    .data("name",user.getUname())
                    .data("nick",user.getNick())
                    .data("avator","")
                    .data("roles",user.getRoles())
                    .data("perms",user.getPerms());
        }


    }

}
