package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.entity.ResultDetails;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ResultDetailsMapper extends BaseMapper<ResultDetails> {
    boolean insertResultDetails(ResultDetails resultDetails);

    List<ResultDetails> selectResultsBytaskId(@Param("taskId") int taskId);

    void deleteBytaskId(@Param("taskId") int taskId);

    List selectResultsByTaskId(Page page, @Param("taskId") int taskId,@Param("sId") String sId);
}
