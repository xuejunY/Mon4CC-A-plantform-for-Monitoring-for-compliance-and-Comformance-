package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Kafkaspout;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IKafkaspoutService extends IService<Kafkaspout> {

    Kafkaspout select_batch(String id, String topologyId);

    boolean updateCode(String id, String topologyId, String kafkaSpoutCode, String kafkaSpoutCodeSimple);

    boolean insertCode(String id, String topologyId, String kafkaSpoutCode, String kafkaSpoutCodeSimple);

    List<Kafkaspout> selectCompleteCode(String topologyId);
}
