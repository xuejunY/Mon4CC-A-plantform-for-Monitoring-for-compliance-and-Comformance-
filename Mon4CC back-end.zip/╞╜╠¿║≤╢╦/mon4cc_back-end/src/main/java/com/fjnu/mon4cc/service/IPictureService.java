package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Picture;

import java.util.List;

public interface IPictureService extends IService<Picture> {

    boolean insert_bance(Picture picture);

    List<Picture> selectPictures(int taskId);

    boolean deletePictures(int taskId);
}
