package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Role_perm;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */

public interface IRole_permService extends IService<Role_perm> {

    boolean insert_batch(List<Role_perm> list);

}
