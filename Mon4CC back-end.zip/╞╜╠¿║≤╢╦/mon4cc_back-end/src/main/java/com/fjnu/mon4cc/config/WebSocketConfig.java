package com.fjnu.mon4cc.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.server.HandshakeInterceptor;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {
    @Autowired
    private WebSocketHandler webSocketHandler;

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry webSocketHandlerRegistry) {
        //往WebSocket注册表中添加映射处理类
        //所有连接到"/websocket"的事件都有MyWebSocketHandler处理
        //其中withSockJS是为了支持SockJS客户端连接
        webSocketHandlerRegistry.addHandler(webSocketHandler, "/websocket").setAllowedOrigins("*").withSockJS();
    }

}
