package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Bolt;
import com.fjnu.mon4cc.entity.Flow;
import com.fjnu.mon4cc.service.IBoltService;
import com.fjnu.mon4cc.service.IFlowService;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/flow")
public class FlowController {
    private static final Logger log = LoggerFactory.getLogger(BoltController.class);
    @Autowired
    private IFlowService iFlowService;
    @PostMapping("/getFlow")
    public Json getFlow(@RequestBody String body){
        String oper = "get a flow";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String groupingId = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Flow flow = iFlowService.select_batch(groupingId,topologyId);

        return Json.succ(oper,"groupingId",flow.getGroupingId())
                .data("GroupingType",flow.getGroupingType())
                .data("Stream",flow.getStream());
    }

}
