package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Role;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface RoleMapper extends BaseMapper<Role> {

    List<Role> getRolesByUserId(@Param("userId") String userId);

    List<String> getRoleIdsByUserId(@Param("userId") String userId);

    Boolean checkRidsContainRval(@Param("rids")List<String> rids,@Param("rval")String rval);

    Boolean checkUidContainRval(@Param("uid")String uid,@Param("rval")String rval);

}
