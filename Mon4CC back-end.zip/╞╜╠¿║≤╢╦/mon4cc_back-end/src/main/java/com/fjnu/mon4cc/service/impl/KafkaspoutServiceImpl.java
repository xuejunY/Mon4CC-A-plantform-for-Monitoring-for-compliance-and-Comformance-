package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Kafkaspout;
import com.fjnu.mon4cc.mapper.KafkaspoutMapper;
import com.fjnu.mon4cc.service.IKafkaspoutService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class KafkaspoutServiceImpl extends ServiceImpl<KafkaspoutMapper, Kafkaspout> implements IKafkaspoutService {

    @Override
    public Kafkaspout select_batch(String id, String topologyId) {
        return baseMapper.selectKafkaSpout(id,topologyId);
    }

    @Override
    public boolean updateCode(String id, String topologyId, String kafkaSpoutCode, String kafkaSpoutCodeSimple) {
        return baseMapper.updateCode(id,topologyId,kafkaSpoutCode,kafkaSpoutCodeSimple);
    }

    @Override
    public boolean insertCode(String id, String topologyId, String kafkaSpoutCode, String kafkaSpoutCodeSimple) {
        return baseMapper.insertCode(id,topologyId,kafkaSpoutCode,kafkaSpoutCodeSimple);
    }

    @Override
    public List<Kafkaspout> selectCompleteCode(String topologyId) {
        return baseMapper.selectCompleteCode(topologyId);
    }
}
