package com.fjnu.mon4cc.connector.url;

public interface RestURL {
//    String BASE = "http://192.168.148.131:8080/bpc-core-api";
    //http://localhost:8081/bpc-core-api/engine/startup
    String BASE = "http://localhost:8080/bpc-core-api/v3.0";
    String PARSE = BASE + "/task/parse";
    String SUBMIT = BASE + "/task/submit";
    String CONFIG = BASE + "/task/config";
    String FILE_CONFIG = BASE + "/task/config";
    String TASK_RUN = BASE + "/task/run/";
    String TASK_CURRENT = BASE + "/task/current/";
    String TASK_ALIVE = BASE + "/task/alive/";
    String TASK_STOP = BASE + "/task/stop/";
    String TASK_FINISHED = BASE + "/task/finished/";
    String TASK_STATE = BASE + "/task/state/";    // 详情
    String TASK_SIMPLE_STATE = BASE + "/task/simpleState/";
    String ENGINE_START = BASE + "/engine/startup";
    String ENGINE_STARTED = BASE + "/engine/started";
    String ENGINE_STATE = BASE + "/engine/state";
    String ENGINE_SHUTDOWN = BASE + "/engine/shutdown";
}
