package com.fjnu.mon4cc.entity;

import java.io.Serializable;
/**
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Deployment implements Serializable {
    private static final long serialVersionUID = 1L;

    private int deploymentId;
    private String modelId;
    private String deployName;
    private String state;
    private String submissionTime;
    private String creater;

    public int getDeploymentId() {
        return deploymentId;
    }

    public void setDeploymentId(int deploymentId) {
        this.deploymentId = deploymentId;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String topologyId) {
        this.modelId = topologyId;
    }

    public String getDeployName() {
        return deployName;
    }

    public void setDeployName(String deployName) {
        this.deployName = deployName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getSubmissionTime() {
        return submissionTime;
    }

    public void setSubmissionTime(String submissionTime) {
        this.submissionTime = submissionTime;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }
}
