package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Role;
import com.fjnu.mon4cc.vo.AuthVo;

import java.util.List;
import java.util.Set;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IRoleService extends IService<Role> {
    Set<AuthVo> getRolesByUserId(String userId);

    List<String> getRoleIdsByUserId(String userId);

    boolean checkRidsContainRval(List<String> rids, String rval);

    boolean checkUidContainRval(String uid, String rval);

}
