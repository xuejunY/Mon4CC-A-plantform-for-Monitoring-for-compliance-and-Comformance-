package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Perm;
import com.fjnu.mon4cc.vo.AuthVo;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 权限 服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IPermService extends IService<Perm> {
    Set<AuthVo> getPermsByUserId(String userId);

    List<Perm> getPermsByRoleId(String roleId);

    void saveOrUpdate(List<Perm> perms);


}
