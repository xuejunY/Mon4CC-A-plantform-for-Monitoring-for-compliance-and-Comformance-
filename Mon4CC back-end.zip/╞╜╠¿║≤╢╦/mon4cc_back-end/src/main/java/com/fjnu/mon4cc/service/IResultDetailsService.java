package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.ResultDetails;

import java.util.List;

public interface IResultDetailsService  extends IService<ResultDetails> {
    boolean insertResult(ResultDetails resultDetails);

    List<ResultDetails> selecResults(int taskId);

    void deleteBytaskId(int taskId);

    Page<ResultDetails> queryResultsByTaskId(Page pageParam, int taskId,String sId);
}
