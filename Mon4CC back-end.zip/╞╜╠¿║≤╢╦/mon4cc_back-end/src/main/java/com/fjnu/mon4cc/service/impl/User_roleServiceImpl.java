package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Role_perm;
import com.fjnu.mon4cc.entity.User_role;
import com.fjnu.mon4cc.mapper.User_roleMapper;
import com.fjnu.mon4cc.service.IUser_roleService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class User_roleServiceImpl extends ServiceImpl<User_roleMapper, User_role> implements IUser_roleService {

    @Override
    public boolean insert_batch(List<User_role> list) {
        for (User_role user_role : list) {
            baseMapper.addUserRole(user_role);
        }
        return true;
    }
}
