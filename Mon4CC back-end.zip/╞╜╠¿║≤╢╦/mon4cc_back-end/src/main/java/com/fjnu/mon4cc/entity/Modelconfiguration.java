package com.fjnu.mon4cc.entity;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Modelconfiguration implements Serializable {

    private static final long serialVersionUID = 1L;

//    @TableId(type = IdType.ID_WORKER_STR)
    private String modelId;

    private String modelName;

    private String modelXml;

    private String description;

    private String state;

    private String creater;

    private String createTime;

    private String completeConfigurationCode;

    private String modelEcl;

    private String typeName;

    private Boolean isLocal;

    public Boolean getIsLocal() {
        return isLocal;
    }

    public void setIsLocal(Boolean isLocal) {
        this.isLocal = isLocal;
    }

    public String getModelEcl() {
        return modelEcl;
    }

    public void setModelEcl(String modelEcl) {
        this.modelEcl = modelEcl;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String topologyId) {
        this.modelId = topologyId;
    }
    public String getModelName() {
        return modelName;
    }

    public void setModelName(String topologyName) {
        this.modelName = topologyName;
    }

    public String getModelXml() {
        return modelXml;
    }

    public void setModelXml(String topologyXml) {
        this.modelXml = topologyXml;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }
    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getCompleteConfigurationCode() {
        return completeConfigurationCode;
    }

    public void setCompleteConfigurationCode(String completeConfigurationCode) {
        this.completeConfigurationCode = completeConfigurationCode;
    }

}
