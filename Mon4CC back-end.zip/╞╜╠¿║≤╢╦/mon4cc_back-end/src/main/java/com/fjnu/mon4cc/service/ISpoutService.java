package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Spout;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface ISpoutService extends IService<Spout> {

    Spout select_batch(String id, String topologyId);

    boolean updateCode(String id, String topologyId, String spoutCode, String spoutCodeSimple);

    boolean insertCode(String id, String topologyId, String spoutCode, String spoutCodeSimple);

    List<Spout> selectCompleteCode(String topologyId);
}
