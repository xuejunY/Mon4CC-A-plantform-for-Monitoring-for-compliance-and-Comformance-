package com.fjnu.mon4cc.connector.exception;

public class TaskStartupException extends Exception {
}
