package com.fjnu.mon4cc.schedule;

import com.fjnu.mon4cc.common.MyWebSocketHandler;
import com.fjnu.mon4cc.connector.entity.SimpleState;
import com.fjnu.mon4cc.entity.MonitorTask;
import com.fjnu.mon4cc.entity.Picture;
import com.fjnu.mon4cc.service.IMonitorTaskService;
import com.fjnu.mon4cc.service.IPictureService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class PullDataTask {
    @Autowired
    private IMonitorTaskService iMonitorTaskService;

    @Autowired
    private MyWebSocketHandler webSocketHandler;

    @Autowired
    private IPictureService iPictureService;


    @Scheduled(fixedRate = 1000)
    public void pullData2() throws IOException {
        List<MonitorTask> tasks = iMonitorTaskService.findRunningTasks();
        String sId;

        for (MonitorTask task : tasks) {
            int violatedNum = 0;
            int succNum = 0;
            int total = 0;
            boolean finished = false;
            sId = task.getsId();
            Picture picture = new Picture();
            SimpleState simpleState  = iMonitorTaskService.taskSimpleState(sId);
            total = Integer.parseInt(simpleState.getReadAmount());
            Map<String, String> failInfo = simpleState.getFailSummary();
            if (failInfo != null) {
                for (String key : simpleState.getFailSummary().keySet()) {
                    violatedNum += Integer.valueOf(failInfo.get(key));
                }
            }
            Map<String, String> succInfo = simpleState.getSuccSummary();
            if (succInfo != null) {
                for (String key : simpleState.getSuccSummary().keySet()) {
                    succNum += Integer.valueOf(succInfo.get(key));
                }
            }

            if (simpleState.getState().equals("FINISHED")){
                finished = true;
                MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(task.getTaskId());
                monitorTask.setState("FINISHED");
                monitorTask.setFailSummary(violatedNum);
                monitorTask.setSuccSummary(succNum);
                monitorTask.setReadAmount(Integer.parseInt(simpleState.getReadAmount()));
                monitorTask.setTimeUsed((int) simpleState.getTimeUsed());
                monitorTask.setStartDate(simpleState.getStartDate());
                boolean success = iMonitorTaskService.update_bance_result(monitorTask);
            }

            double rate = violatedNum * 1.0 / (violatedNum + succNum) * 100;
            long timestamp = System.currentTimeMillis();
            picture.setFinished(finished);
            picture.setTaskId(task.getTaskId());
            picture.setSuccNum(succNum);
            picture.setTimestamp(timestamp);
            picture.setTotal(total);
            picture.setViolatedNum(violatedNum);
            iPictureService.insert_bance(picture);

            String data = "[" + timestamp + "," + total + "," + violatedNum + "," + (violatedNum == 0 ? 0.0 : String.format("%.3f", rate)) + "," + finished + "]";
            log.info("data:{}", data);
            webSocketHandler.sendMessage("" + task.getTaskId(), data);
        }

    }

}
