package com.fjnu.mon4cc.entity;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Bolt implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    private String boltComponentName;

    private Integer boltParallelism;

    private String boltStream;

    private String boltCodeSimple;

    private String boltCode;

    private String completeBoltCode;

    private String topologyId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getBoltComponentName() {
        return boltComponentName;
    }

    public void setBoltComponentName(String boltComponentName) {
        this.boltComponentName = boltComponentName;
    }
    public Integer getBoltParallelism() {
        return boltParallelism;
    }

    public void setBoltParallelism(Integer boltParallelism) {
        this.boltParallelism = boltParallelism;
    }
    public String getBoltStream() {
        return boltStream;
    }

    public void setBoltStream(String boltStream) {
        this.boltStream = boltStream;
    }
    public String getBoltCodeSimple() {
        return boltCodeSimple;
    }

    public void setBoltCodeSimple(String boltCodeSimple) {
        this.boltCodeSimple = boltCodeSimple;
    }
    public String getBoltCode() {
        return boltCode;
    }

    public void setBoltCode(String boltCode) {
        this.boltCode = boltCode;
    }
    public String getTopologyId() {
        return topologyId;
    }

    public void setTopologyId(String topologyId) {
        this.topologyId = topologyId;
    }


    public String getCompleteBoltCode() {
        return completeBoltCode;
    }

    public void setCompleteBoltCode(String completeBoltCode) {
        this.completeBoltCode = completeBoltCode;
    }
}
