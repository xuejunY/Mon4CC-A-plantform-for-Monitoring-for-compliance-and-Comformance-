package com.fjnu.mon4cc.constant;

/**
 *     管理员的特殊值
 */
public interface Root {

    /**
     * 管理员的角色值
     */
    String ROLE_VAL = "root";

    /**
     * 管理员的权限
     */
    String PERM_VAL = "*";

}
