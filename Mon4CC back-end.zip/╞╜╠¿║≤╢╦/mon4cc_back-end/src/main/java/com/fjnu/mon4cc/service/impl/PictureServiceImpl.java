package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Picture;
import com.fjnu.mon4cc.mapper.PictureMapper;
import com.fjnu.mon4cc.service.IPictureService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceImpl extends ServiceImpl<PictureMapper, Picture> implements IPictureService {
    @Override
    public boolean insert_bance(Picture picture) {
        return baseMapper.insertPicture(picture);
    }

    @Override
    public List<Picture> selectPictures(int taskId) {
        return baseMapper.selectPicturesBytaskId(taskId);
    }

    @Override
    public boolean deletePictures(int taskId) {
        return baseMapper.deleteBypictureId(taskId);
    }
}
