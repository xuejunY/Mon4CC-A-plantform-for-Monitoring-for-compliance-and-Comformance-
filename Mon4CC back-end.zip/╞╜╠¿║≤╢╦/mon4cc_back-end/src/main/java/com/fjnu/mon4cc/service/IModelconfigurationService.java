package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.entity.Modelconfiguration;

import java.security.SecureRandom;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface IModelconfigurationService extends IService<Modelconfiguration> {

    Page<Modelconfiguration> queryTopologyConfig(Page pageParam, String topologyName,String creater);

    Modelconfiguration select_bance(String topologyId);

    boolean insert_bance(Modelconfiguration modelconfiguration);

    boolean deleteByTid(String topologyId);

    boolean update_bance(Modelconfiguration modelconfiguration);

    List<Modelconfiguration> selectCompleteCode(String topologyId);

    boolean update_state(String topologyId, String state);

    List<Modelconfiguration> select_modelIds(String typeName, String creater);

}
