package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Bolt;
import com.fjnu.mon4cc.service.IBoltService;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/bolt")
public class BoltController {
    private static final Logger log = LoggerFactory.getLogger(BoltController.class);
    @Autowired
    private IBoltService iBoltService;

    @PostMapping("/getBolt")
    public Json getBolt(@RequestBody String body){
        String oper = "get a bolt";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Bolt bolt = iBoltService.select_batch(id,topologyId);

        return Json.succ(oper,"id",bolt.getId())
                .data("boltComponentName",bolt.getBoltComponentName())
                .data("boltParallelism",bolt.getBoltParallelism())
                .data("boltStream",bolt.getBoltStream());
    }

    @PostMapping("/getBoltCode")
    public Json getBoltCode(@RequestBody String body){
        String oper = "get a boltCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Bolt bolt = iBoltService.select_batch(id,topologyId);
        if (bolt==null){
            return Json.succ(oper,"boltCode",null);
        }else return Json.succ(oper,"boltCode",bolt.getBoltCode());
    }

    @PostMapping("/saveBoltCode")
    public Json saveBoltCode(@RequestBody String body){
        String oper = "save a boltCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        String boltCode = jsonObj.getString("boltCode");
        String boltCodeSimple = jsonObj.getString("boltCodeSimple");
        boolean success;
        if (iBoltService.select_batch(id,topologyId)!=null){
            success = iBoltService.updateCode(id,topologyId,boltCode,boltCodeSimple);
        }else {
            success = iBoltService.insertCode(id,topologyId,boltCode,boltCodeSimple);
        }
        return Json.result(oper,success);
    }

}
