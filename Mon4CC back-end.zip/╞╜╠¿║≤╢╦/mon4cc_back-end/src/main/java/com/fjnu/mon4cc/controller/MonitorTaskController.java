package com.fjnu.mon4cc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.connector.entity.MonitorState;
import com.fjnu.mon4cc.connector.entity.Response;
import com.fjnu.mon4cc.connector.entity.SimpleState;
import com.fjnu.mon4cc.connector.url.RestURL;
import com.fjnu.mon4cc.entity.Modelconfiguration;
import com.fjnu.mon4cc.entity.MonitorTask;
import com.fjnu.mon4cc.entity.ResultDetails;
import com.fjnu.mon4cc.service.IModelconfigurationService;
import com.fjnu.mon4cc.service.IMonitorTaskService;
import com.fjnu.mon4cc.service.IPictureService;
import com.fjnu.mon4cc.service.IResultDetailsService;
import com.fjnu.mon4cc.utils.PageUtils;
import com.fjnu.mon4cc.vo.Json;
import com.fjnu.mon4cc.vo.MonitorTaskVO;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/monitortask")
public class MonitorTaskController {
    private static final Logger log = LoggerFactory.getLogger(MonitorTaskController.class);

    @Autowired
    private IMonitorTaskService iMonitorTaskService;
    @Autowired
    private IModelconfigurationService iModelconfigurationService;
    @Autowired
    private IResultDetailsService iResultDetailsService;

    @Autowired
    private IPictureService iPictureService;



    @PostMapping("/query")
    public Json query(@RequestBody String body) {
        String oper = "query monitortasks";
        log.info("{}, body: {}", oper, body);
        JSONObject json = JSON.parseObject(body);
        String taskName = json.getString("taskName");
        String creater = json.getString("creater") ;
        Page<MonitorTask> page1 = iMonitorTaskService.queryMonitorTask(PageUtils.getPageParam(json), taskName,creater);
        Page<MonitorTaskVO> page = new Page<>();
        List<MonitorTaskVO> list = new ArrayList<>();
        for (MonitorTask monitorTask:page1.getRecords()){
            MonitorTaskVO monitorTaskVO = new MonitorTaskVO();
            BeanUtils.copyProperties(monitorTask,monitorTaskVO);
            Modelconfiguration modelconfiguration = iModelconfigurationService.select_bance(monitorTask.getModelId());
            monitorTaskVO.setCreater(modelconfiguration.getCreater());
            monitorTaskVO.setTypeName(modelconfiguration.getTypeName());
            list.add(monitorTaskVO);

        }
        BeanUtils.copyProperties(page1,page);
        page.setRecords(list);

        return Json.succ(oper).data("page", page);
    }

    @PostMapping("/insert")
    public Json add(@RequestBody String body){

        String oper = "add a monitortask";
        log.info("{}, body: {}",oper,body);

        MonitorTask monitorTask = JSON.parseObject(body, MonitorTask.class);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        monitorTask.setState("unsubmitted");
        monitorTask.setCreateTime(dateFormat.format(new Date()));

        monitorTask.setModelEcl(iModelconfigurationService.select_bance(monitorTask.getModelId()).getModelEcl());
        monitorTask.setModelXml(iModelconfigurationService.select_bance(monitorTask.getModelId()).getModelXml());
        boolean success = iMonitorTaskService.insert_bance(monitorTask);
        return Json.result(oper, success)
                .data("state",monitorTask.getState());
    }

    @PostMapping("/delete")
    public Json delete(@RequestBody String body) {

        String oper = "delete a monitortask";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getIntValue("taskId");
        boolean success = iMonitorTaskService.deleteByTId(taskId);

        return Json.result(oper, success);
    }
    @PostMapping("/update")
    public Json update(@RequestBody String body) {

        String oper = "update monitortask config";
        log.info("{}, body: {}",oper,body);

        MonitorTask monitorTask = JSON.parseObject(body, MonitorTask.class);
        boolean success = iMonitorTaskService.update_bance(monitorTask);
        return Json.succ(oper,success);
    }

    @PostMapping("/updateState")
    public Json updateState(@RequestBody String body) {

        String oper = "update monitortask state";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getIntValue("taskId");
        String state = jsonObj.getString("state");

        boolean success = iMonitorTaskService.update_state(taskId,state);
        return Json.succ(oper,success);
    }
    @PostMapping("/submitEcl")
    public Json submitEcl(@RequestBody String body) {

        String oper = "submitEcl";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getIntValue("taskId");
        String modelId = jsonObj.getString("modelId");
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.ENGINE_START,Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            boolean success = iMonitorTaskService.commit(taskId,modelId);
            return Json.result(oper,success);
        }else return Json.fail(oper,false);
    }


    @PostMapping("/submitSTEcl")
    public Response submitSTEcl(@RequestParam("file") MultipartFile file, int taskId) {

        String oper = "submitSTEcl";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Response> responseEntity = restTemplate.getForEntity(RestURL.ENGINE_START,Response.class);
        Response response = responseEntity.getBody();
        if(response.getCode().equals("200")) {
            try {
                boolean flag = iMonitorTaskService.commit_ST(file, taskId);
                response.setCode("200");
                response.setMsg("success");
                return response;
            } catch (Exception e) {
                response.setCode("500");
                response.setMsg("fail");
                return response;
            }
        }else {
            response.setCode("500");
            response.setMsg("fail");
            return response;
        }
    }

    @PostMapping("/file-config")
    public Response fileConfig(@RequestParam("file") MultipartFile file, String sId, int taskId) {
        Response response = new Response();

        String oper = "config log";
        try {
            boolean flag = iMonitorTaskService.fileConfigTask(file, sId, taskId);
            response.setCode("200");
            response.setMsg("success");
            return response;
        } catch (Exception e) {
            log.error("配置失败!", e);
            response.setCode("500");
            response.setMsg("fail");
            return response;
        }

    }

    @PostMapping("/start")
    public Json start(@RequestBody String body) {
        String oper = "start";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        String sId = jsonObj.getString("sId");
        int taskId = jsonObj.getIntValue("taskId");
        boolean flag = iMonitorTaskService.startTask(sId);
        if (iPictureService.selectPictures(taskId)!=null){
            iPictureService.deletePictures(taskId);
        }
        return Json.succ(oper,flag);
    }

    @PostMapping("/stop")
    public Json stop(@RequestBody String body) {
        String oper = "stop";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        String sId = jsonObj.getString("sId");
        boolean flag = iMonitorTaskService.stopTask(sId);
        return Json.result(oper,flag);
    }

//    @PostMapping("/fetch_Results")
//    public Json fetch_Results(@RequestBody String body) {
//        String oper = "fetch_Results";
//        log.info("{}, body: {}",oper,body);
//        JSONObject jsonObj = JSON.parseObject(body);
//        int taskId = jsonObj.getIntValue("taskId");
//        String sId = jsonObj.getString("sId");
////        SimpleState simpleState = iMonitorTaskService.taskSimpleState(sId);
//        MonitorState monitorState = iMonitorTaskService.taskState(sId);
////        int violatedNum = 0;
////        int succNum = 0;
////        int total = Integer.parseInt(simpleState.getReadAmount());
////
////        Map<String, String> failInfo = simpleState.getFailSummary();
////        if(failInfo != null) {
////            for(String key : simpleState.getFailSummary().keySet()) {
////                violatedNum += Integer.valueOf(failInfo.get(key));
////            }
////        }
////        Map<String, String> succInfo = simpleState.getSuccSummary();
////        if(succInfo != null) {
////            for(String key : simpleState.getSuccSummary().keySet()) {
////                succNum += Integer.valueOf(succInfo.get(key));
////            }
////        }
//
//
//
//        Map<String, List<MonitorState.PolicyVerifyResult>> failInfos = monitorState.getFailurePyMap();
//        Map<String, List<MonitorState.PolicyVerifyResult>> succInfos = monitorState.getSuccessPyMap();
//        Page<ResultDetails> page = new Page<>();
//        List<ResultDetails> list = new ArrayList<>();
//        Page<ResultDetails> page1 = iResultDetailsService.queryResultsByTaskId(PageUtils.getPageParam(jsonObj), taskId);
//        BeanUtils.copyProperties(page1,page);
////        page.setCondition((Map<String, Object>) PageUtils.getPageParam(jsonObj));
//        if(failInfos != null) {
//            for (String key : monitorState.getFailurePyMap().keySet()) {
//                for (MonitorState.PolicyVerifyResult policyVerifyResult : failInfos.get(key)) {
//                    ResultDetails resultDetails = new ResultDetails();
////                    resultDetails.setTaskId(taskId);
//                    resultDetails.setType(policyVerifyResult.getType());
////                    resultDetails.setRuleName(key);
////                    resultDetails.setResultType("failure");
//                    resultDetails.setCause(policyVerifyResult.getCause());
//                    resultDetails.setPyId(policyVerifyResult.getPyId());
//                    list.add(resultDetails);
//
//                }
//            }
//        }
//        if(succInfos != null) {
//            for (String key : monitorState.getSuccessPyMap().keySet()) {
//                for (MonitorState.PolicyVerifyResult policyVerifyResult : succInfos.get(key)) {
//                    ResultDetails resultDetails = new ResultDetails();
////                    resultDetails.setTaskId(taskId);
//                    resultDetails.setType(policyVerifyResult.getType());
////                    resultDetails.setRuleName(key);
////                    resultDetails.setResultType("success");
//                    resultDetails.setCause(policyVerifyResult.getCause());
//                    resultDetails.setPyId(policyVerifyResult.getPyId());
//                    list.add(resultDetails);
//                }
//            }
//        }
//        page.setRecords(list);
//
//
////        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
////        monitorTask.setState(simpleState.getState());
////        monitorTask.setFailSummary(violatedNum);
////        monitorTask.setSuccSummary(succNum);
////        monitorTask.setReadAmount(Integer.parseInt(simpleState.getReadAmount()));
////        monitorTask.setTimeUsed((int) simpleState.getTimeUsed());
////        monitorTask.setStartDate(simpleState.getStartDate());
////        boolean success = iMonitorTaskService.update_bance_result(monitorTask);
//        return Json.succ(oper).data("page", page);
//    }


    @PostMapping("/pullData")
    public Json pullData(@RequestBody String body) throws IOException, SQLException, ClassNotFoundException {
        String oper = "pullData";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getIntValue("taskId");
        String sId = jsonObj.getString("sId");
        SimpleState simpleState = iMonitorTaskService.taskSimpleState(sId);

        MonitorState monitorState = iMonitorTaskService.taskState(sId);
        int violatedNum = 0;
        int succNum = 0;
        int total = Integer.parseInt(simpleState.getReadAmount());

        Map<String, String> failInfo = simpleState.getFailSummary();
        if(failInfo != null) {
            for(String key : simpleState.getFailSummary().keySet()) {
                violatedNum += Integer.valueOf(failInfo.get(key));
            }
        }
        Map<String, String> succInfo = simpleState.getSuccSummary();
        if(succInfo != null) {
            for(String key : simpleState.getSuccSummary().keySet()) {
                succNum += Integer.valueOf(succInfo.get(key));
            }
        }
        Map<String, List<MonitorState.PolicyVerifyResult>> failInfos = monitorState.getFailurePyMap();
        Map<String, List<MonitorState.PolicyVerifyResult>> succInfos = monitorState.getSuccessPyMap();
        Connection conn;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/mon4cc?characterEncoding=utf8&useSSL=false";
        String user = "root";
        String password = "1234";
        String sql = "INSERT INTO resultdetails (taskId,ruleName,resultType,type,cause,pyId,sId) VALUES (?,?,?,?,?,?,?)";
        Class.forName(driver);
        conn = (Connection) DriverManager.getConnection(url, user, password);

        try {
            // 保存sql后缀
            StringBuffer suffix = new StringBuffer();
            // 设置事务为非自动提交
            conn.setAutoCommit(false);
            PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
            int a = 0;
            int b = 0;
            if(failInfos != null) {
                for (String key : monitorState.getFailurePyMap().keySet()) {
                    for (MonitorState.PolicyVerifyResult policyVerifyResult : failInfos.get(key)) {
                        if (a <= 10000) {
                            a++;
                            pst.setInt(1, taskId);
                            pst.setString(2,key);
                            pst.setString(3,"failure" );
                            pst.setString(4, policyVerifyResult.getType());
                            pst.setString(5, policyVerifyResult.getCause());
                            pst.setString(6, policyVerifyResult.getPyId());
                            pst.setString(7,sId);
                            pst.addBatch();
                        } else {
                            a = 0;
                            // 执行操作
                            pst.executeBatch();
                            // 提交事务
                            conn.commit();
                        }
                    }
                }
                if (a>0){
                    // 执行操作
                    pst.executeBatch();
                    // 提交事务
                    conn.commit();
                }

            }
            if(succInfos != null) {
                for(String key : monitorState.getSuccessPyMap().keySet()) {
                    for(MonitorState.PolicyVerifyResult policyVerifyResult : succInfos.get(key)) {
                        if (b <= 10000) {
                            b++;
                            pst.setInt(1, taskId);
                            pst.setString(2,key);
                            pst.setString(3,"success" );
                            pst.setString(4, policyVerifyResult.getType());
                            pst.setString(5, policyVerifyResult.getCause());
                            pst.setString(6, policyVerifyResult.getPyId());
                            pst.setString(7,sId);
                            pst.addBatch();
                        } else {
                            b= 0;
                            // 执行操作
                            pst.executeBatch();
                            // 提交事务
                            conn.commit();
                        }
                    }
                }
                if (b>0){
                    // 执行操作
                    pst.executeBatch();
                    // 提交事务
                    conn.commit();
                }
            }
            pst.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
//        if (monitorState.getState().equals("FINISHED")){
            MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
            monitorTask.setState(simpleState.getState());
            monitorTask.setFailSummary(violatedNum);
            monitorTask.setSuccSummary(succNum);
            monitorTask.setReadAmount(Integer.parseInt(simpleState.getReadAmount()));
            monitorTask.setTimeUsed((int) simpleState.getTimeUsed());
            monitorTask.setStartDate(simpleState.getStartDate());
            boolean success = iMonitorTaskService.update_bance_result(monitorTask);
//        }
        return Json.result(oper,success);
    }




    @PostMapping("/test")
    public Json test(@RequestBody String body) {
        String oper = "test";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getInteger("taskId");
        JSONArray nodeId = jsonObj.getJSONArray("nodeId");
        String ecl = jsonObj.getString("ecl");
        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        String modelXml = monitorTask.getModelXml();
//        String modelXml1 = modelXml;
        String[] modelXml2 = modelXml.split("\n");
        for (int i =0;i<nodeId.size();i++){
            if (nodeId.getString(i).equals("startevent")){
                // String a = "<startEvent id=\""+nodeId.getString(i)+"\"" +" name=\""+nodeId.getString(i)+"\">";
                String a = "<startEvent id=\""+nodeId.getString(i)+"\"" +" name=";
//                System.out.println(modelXml2[3]);
//                System.out.println(a.equals(modelXml2[3].trim()));
                int index=getIndex(modelXml2,a);
                if (index!=-1){
                    modelXml2[index] = "    <intermediateThrowEvent id=\""+nodeId.getString(i) +"\"" +" name=\""+nodeId.getString(i)+"\">";
                    if (modelXml2[index+2].trim().equals("</startEvent>")){
                        modelXml2[index+2] = "    </intermediateThrowEvent>";
                    }else {
                        modelXml2[index+3] = "    </intermediateThrowEvent>";
                    }
                }
            }else if (nodeId.getString(i).equals("endevent")){
                int index=getIndex(modelXml2,"<endEvent id=\""+nodeId.getString(i) +"\"" +" name=>");
                if (index!=-1){
                    modelXml2[index] = "    <intermediateThrowEvent id=\""+nodeId.getString(i) +"\"" +" name=\""+nodeId.getString(i) +"\">";
                    if (modelXml2[index+2].trim().equals("</endEvent>")){
                        modelXml2[index+2] = "    </intermediateThrowEvent>";
                    }else {
                        modelXml2[index+3] = "    </intermediateThrowEvent>";
                    }
                }
            }else {
                int index=getIndex(modelXml2,"<task id=\""+nodeId.getString(i) +"\"" +" name=");
                System.out.println("<task id=\""+nodeId.getString(i) +"\"" +" name=");
                if (index!=-1){
                    modelXml2[index] = "    <userTask id=\""+nodeId.getString(i) +"\"" +" name=\""+nodeId.getString(i) +"\">";
                    if (modelXml2[index+2].trim().equals("</task>")){
                        modelXml2[index+2] = "    </userTask>";
                    }else {
                        modelXml2[index+3] = "    </userTask>";
                    }
                }
            }
        }
        monitorTask.setModelXml(StringUtils.join(modelXml2,"\n"));
        monitorTask.setModelEcl(ecl);
        boolean flag = iMonitorTaskService.update_bance(monitorTask);
        return Json.result(oper,flag);
    }
    public static int getIndex(String[] arr,String value) {
        //遍历数组
        for(int x=0;x<arr.length;x++) {
            if(arr[x].trim().indexOf(value)!=-1) {
                return x;
            }
        }
        //没找到返回-1
        return -1;
    }

    @PostMapping("/getXml")
    public Json getXml(@RequestBody String body){

        String oper = "get a xml";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getInteger("taskId");

        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);

        return Json.succ(oper,"modelXml", monitorTask.getModelXml());
    }

    @PostMapping("/saveXml")
    public Json saveXml(@RequestBody String body){

        String oper = "save a xml";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getInteger("taskId");
        String modelXml = jsonObj.getString("modelXml1");

        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        monitorTask.setModelXml(modelXml);

        boolean flag = iMonitorTaskService.update_bance(monitorTask);
        return Json.result(oper,flag);
    }

    @PostMapping("/saveXml_ecl")
    public Json saveXml_ecl(@RequestBody String body){

        String oper = "saveXml_ecl";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int taskId = jsonObj.getInteger("taskId");
        String modelId = jsonObj.getString("modelId");
        Modelconfiguration modelconfiguration = iModelconfigurationService.select_bance(modelId);


        MonitorTask monitorTask = iMonitorTaskService.selectMonitorTask(taskId);
        monitorTask.setModelXml(modelconfiguration.getModelXml());
        monitorTask.setModelEcl(modelconfiguration.getModelEcl());

        boolean flag = iMonitorTaskService.update_bance(monitorTask);
        return Json.result(oper,flag);
    }



}
