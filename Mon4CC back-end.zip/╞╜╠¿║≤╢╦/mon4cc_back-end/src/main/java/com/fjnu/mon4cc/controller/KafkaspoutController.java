package com.fjnu.mon4cc.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Flow;
import com.fjnu.mon4cc.entity.Kafkaspout;
import com.fjnu.mon4cc.service.IFlowService;
import com.fjnu.mon4cc.service.IKafkaspoutService;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/kafkaspout")
public class KafkaspoutController {
    private static final Logger log = LoggerFactory.getLogger(BoltController.class);
    @Autowired
    private IKafkaspoutService iKafkaspoutService;
    @PostMapping("/getKafkaSpout")
    public Json getKafkaSpout(@RequestBody String body){
        String oper = "get a KafkaSpout";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Kafkaspout kafkaspout = iKafkaspoutService.select_batch(id,topologyId);

        return Json.succ(oper,true).data("id",kafkaspout.getId())
                .data("spoutComponentName",kafkaspout.getSpoutComponentName())
                .data("spoutParallelism",kafkaspout.getSpoutParallelism())
                .data("kafkaSpoutStream",kafkaspout.getKafkaSpoutStream())
                .data("boostrapServer",kafkaspout.getBoostrapServer())
                .data("maxPollRecord",kafkaspout.getMaxPollRecord())
                .data("autoCommit",kafkaspout.getAutoCommit())
                .data("groupId",kafkaspout.getGroupId())
                .data("offsetReset",kafkaspout.getOffsetReset())
                .data("topic",kafkaspout.getTopic());
    }

    @PostMapping("/getKafkaSpoutCode")
    public Json getKafkaSpoutCode(@RequestBody String body){
        String oper = "get a kafkaSpoutCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        Kafkaspout kafkaspout = iKafkaspoutService.select_batch(id,topologyId);
        if (kafkaspout==null){
            return Json.succ(oper,"kafkaSpoutCode",null);
        }else return Json.succ(oper,"kafkaSpoutCode",kafkaspout.getKafkaSpoutCode());
    }

    @PostMapping("/saveKafkaSpoutCode")
    public Json saveKafkaSpoutCode(@RequestBody String body){
        String oper = "save a kafkaSpoutCode";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        String id = jsonObj.getString("id");
        String topologyId = jsonObj.getString("topologyId");
        String kafkaSpoutCode = jsonObj.getString("kafkaSpoutCode");
        String kafkaSpoutCodeSimple = jsonObj.getString("kafkaSpoutCodeSimple");
        boolean success;
        if (iKafkaspoutService.select_batch(id,topologyId)!=null){
            success = iKafkaspoutService.updateCode(id,topologyId,kafkaSpoutCode,kafkaSpoutCodeSimple);
        }else {
            success = iKafkaspoutService.insertCode(id,topologyId,kafkaSpoutCode,kafkaSpoutCodeSimple);
        }
        return Json.result(oper,success);
    }



}
