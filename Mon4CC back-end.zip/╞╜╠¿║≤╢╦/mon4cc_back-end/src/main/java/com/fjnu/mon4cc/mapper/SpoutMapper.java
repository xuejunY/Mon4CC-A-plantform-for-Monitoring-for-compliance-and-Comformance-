package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Bolt;
import com.fjnu.mon4cc.entity.Kafkaspout;
import com.fjnu.mon4cc.entity.Spout;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface SpoutMapper extends BaseMapper<Spout> {
    Spout selectSpout(@Param("id") String id, @Param("topologyId") String topologyId);
    boolean updateCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("spoutCode") String spoutCode,@Param("spoutCodeSimple") String spoutCodeSimple);
    boolean insertCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("spoutCode") String spoutCode,@Param("spoutCodeSimple") String spoutCodeSimple);
    List<Spout> selectCompleteCode(@Param("topologyId")String topologyId);

}
