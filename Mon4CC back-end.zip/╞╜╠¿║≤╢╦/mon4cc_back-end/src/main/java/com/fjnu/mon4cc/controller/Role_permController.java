package com.fjnu.mon4cc.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Controller
@RequestMapping("/role_perm")
public class Role_permController {

}
