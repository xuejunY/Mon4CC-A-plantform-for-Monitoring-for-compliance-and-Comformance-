package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.fjnu.mon4cc.entity.Deployment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface DeploymentMapper extends BaseMapper<Deployment> {

    List selectDeploymentConfig(Page page, @Param("deployName") String deployName,@Param("creater") String creater);

    boolean insertDeployment(Deployment deployment);

    boolean deleteDeployment(@Param("deploymentId") int deploymentId);

    boolean updateDeployment(Deployment deployment);

    boolean updateState(@Param("deploymentId") int deploymentId,@Param("state") String state);

    boolean submit_bance(Deployment deployment);
}
