package com.fjnu.mon4cc.connector.entity;

import org.springframework.core.io.AbstractResource;

import java.io.IOException;
import java.io.InputStream;

/**
 * 把字符串伪装成文本文件资源
 */
//该类与FileSystemResouce同父类
public class TextFeignFileResource extends AbstractResource {
    //文本的字节信息
    private byte[] bytes;
    //当前读到的位置
    private int index = 0;
    //文件名
    private String filename;

    //构造函数需要两个参数，一个是文件名，随便取
    //另一个就是文本内容，String类型足够存文本的
    public TextFeignFileResource(String filename, String content) {
        this.filename = filename;
        this.bytes = content.getBytes();
    }

    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return new InputStream() {
            //注意这里的返回值int是一个八位的字节的数值表示
            //并不是读取到的字节个数
            @Override
            public int read() throws IOException {
                if (index >= bytes.length)
                    return -1; //返回-1是标准，表示读取结束
                return bytes[index++];
            }
        };
    }

    @Override
    public boolean exists() {
        return true;
    }

    @Override
    public boolean isFile() {
        return true;
    }

    @Override
    public boolean isReadable() {
        return true;
    }

    @Override
    public long contentLength() throws IOException {
        return bytes.length;
    }

    @Override
    public String getFilename() {
        return filename;
    }

}