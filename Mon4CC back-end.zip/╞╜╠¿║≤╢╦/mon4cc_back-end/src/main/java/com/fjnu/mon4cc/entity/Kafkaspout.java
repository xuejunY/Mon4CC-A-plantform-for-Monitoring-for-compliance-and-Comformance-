package com.fjnu.mon4cc.entity;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public class Kafkaspout implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    private String spoutComponentName;

    private Integer spoutParallelism;

    private String topologyId;

    private String kafkaSpoutCode;

    private String kafkaSpoutCodeSimple;

    private String completeKafkaSpoutCode;

    private String kafkaSpoutStream;

    private String boostrapServer;

    private Integer maxPollRecord;

    private Boolean autoCommit;

    private String groupId;

    private String offsetReset;

    private String topic;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getSpoutComponentName() {
        return spoutComponentName;
    }

    public void setSpoutComponentName(String spoutComponentName) {
        this.spoutComponentName = spoutComponentName;
    }
    public Integer getSpoutParallelism() {
        return spoutParallelism;
    }

    public void setSpoutParallelism(Integer spoutParallelism) {
        this.spoutParallelism = spoutParallelism;
    }
    public String getTopologyId() {
        return topologyId;
    }

    public void setTopologyId(String topologyId) {
        this.topologyId = topologyId;
    }
    public String getKafkaSpoutCode() {
        return kafkaSpoutCode;
    }

    public void setKafkaSpoutCode(String kafkaSpoutCode) {
        this.kafkaSpoutCode = kafkaSpoutCode;
    }
    public String getKafkaSpoutCodeSimple() {
        return kafkaSpoutCodeSimple;
    }

    public void setKafkaSpoutCodeSimple(String kafkaSpoutCodeSimple) {
        this.kafkaSpoutCodeSimple = kafkaSpoutCodeSimple;
    }
    public String getKafkaSpoutStream() {
        return kafkaSpoutStream;
    }

    public void setKafkaSpoutStream(String kafkaSpoutStream) {
        this.kafkaSpoutStream = kafkaSpoutStream;
    }
    public String getBoostrapServer() {
        return boostrapServer;
    }

    public void setBoostrapServer(String boostrapServer) {
        this.boostrapServer = boostrapServer;
    }
    public Integer getMaxPollRecord() {
        return maxPollRecord;
    }

    public void setMaxPollRecord(Integer maxPollRecord) {
        this.maxPollRecord = maxPollRecord;
    }
    public Boolean getAutoCommit() {
        return autoCommit;
    }

    public void setAutoCommit(Boolean autoCommit) {
        this.autoCommit = autoCommit;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getOffsetReset() {
        return offsetReset;
    }

    public void setOffsetReset(String offsetReset) {
        this.offsetReset = offsetReset;
    }
    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getCompleteKafkaSpoutCode() {
        return completeKafkaSpoutCode;
    }

    public void setCompleteKafkaSpoutCode(String completeKafkaSpoutCode) {
        this.completeKafkaSpoutCode = completeKafkaSpoutCode;
    }

    @Override
    public String toString() {
        return "Kafkaspout{" +
            "id=" + id +
            ", spoutComponentName=" + spoutComponentName +
            ", spoutParallelism=" + spoutParallelism +
            ", topologyId=" + topologyId +
            ", kafkaSpoutCode=" + kafkaSpoutCode +
            ", kafkaSpoutCodeSimple=" + kafkaSpoutCodeSimple +
            ", kafkaSpoutStream=" + kafkaSpoutStream +
            ", boostrapServer=" + boostrapServer +
            ", maxPollRecord=" + maxPollRecord +
            ", autoCommit=" + autoCommit +
            ", groupId=" + groupId +
            ", offsetReset=" + offsetReset +
            ", topic=" + topic +
        "}";
    }
}
