package com.fjnu.mon4cc.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 权限
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@TableName("perm")
public class Perm extends Model<Perm> {

    @TableId(type = IdType.INPUT)
    private String pval;    // 权限值，shiro的权限控制表达式
    private String parent;  // 父节点权限值
    private String pname;   // 权限名称
    private Integer ptype;  // 权限类型：1.菜单；2.按钮
    private Boolean leaf;   // 是否叶子节点

    /**
     * 创建时间
     */
    private String created;

    /**
     * 修改时间
     */
    private String updated;

    @TableField(exist = false)
    private List<Perm> children = new ArrayList<>();

    @Override
    protected Serializable pkVal() {
        return pval;
    }

    public Boolean getLeaf() {
        return leaf;
    }

    public void setLeaf(Boolean leaf) {
        this.leaf = leaf;
    }

    public List<Perm> getChildren() {
        return children;
    }

    public void setChildren(List<Perm> children) {
        this.children = children;
    }

    public String getPval() {
        return pval;
    }

    public void setPval(String pval) {
        this.pval = pval;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public Integer getPtype() {
        return ptype;
    }

    public void setPtype(Integer ptype) {
        this.ptype = ptype;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }
    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return "Perm{" +
            "pval=" + pval +
            ", parent=" + parent +
            ", pname=" + pname +
            ", ptype=" + ptype +
            ", leaf=" + leaf +
            ", created=" + created +
            ", updated=" + updated +
        "}";
    }
}
