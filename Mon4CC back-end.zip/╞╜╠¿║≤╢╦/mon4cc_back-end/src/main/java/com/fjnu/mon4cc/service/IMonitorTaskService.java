package com.fjnu.mon4cc.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.fjnu.mon4cc.connector.entity.MonitorState;
import com.fjnu.mon4cc.connector.entity.SimpleState;
import com.fjnu.mon4cc.entity.MonitorTask;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface IMonitorTaskService extends IService<MonitorTask> {

    boolean insert_bance(MonitorTask monitorTask);

    Page<MonitorTask> queryMonitorTask(Page pageParam, String taskName,String creater);

    boolean deleteByTId(int taskId);

    boolean update_state(int taskId, String state);

    MonitorTask selectMonitorTask(int taskId);

    boolean update_bance(MonitorTask monitorTask);

    boolean commit(int taskId, String modelId);

    boolean fileConfigTask(MultipartFile file, String sId, int taskId) throws IOException;

    boolean startTask(String sId);

    SimpleState taskSimpleState(String sId);

    boolean update_bance_result(MonitorTask monitorTask);

    MonitorState taskState(String sId);

    List<MonitorTask> findRunningTasks();

    boolean stopTask(String sId);

    boolean commit_ST(MultipartFile file, int taskId) throws IOException;
}
