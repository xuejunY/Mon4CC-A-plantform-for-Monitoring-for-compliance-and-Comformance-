package com.fjnu.mon4cc.connector.entity;

import java.util.List;
import java.util.Map;

/**
 * 监视状态
 */
public class MonitorState {
    /**
     * 会话ID
     */
    private String sId;
    /**
     * 状态(RUNNING, STOPED, FINISHED)
     */
    private String state;
    private String accessDate;
    /**
     * 启动时间
     */
    private String startDate;
    /**
     * 处理事件数
     */
    private String readAmount;
    /**
     * 违规信息
     */
    private Map<String, List<PolicyVerifyResult>> failurePyMap;
    /**
     * 合规信息
     */
    private Map<String, List<PolicyVerifyResult>> successPyMap;
    /**
     * 用时
     */
    private long timeUsed;

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(String accessDate) {
        this.accessDate = accessDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getReadAmount() {
        return readAmount;
    }

    public void setReadAmount(String readAmount) {
        this.readAmount = readAmount;
    }

    public Map<String, List<PolicyVerifyResult>> getFailurePyMap() {
        return failurePyMap;
    }

    public void setFailurePyMap(Map<String, List<PolicyVerifyResult>> failurePyMap) {
        this.failurePyMap = failurePyMap;
    }

    public Map<String, List<PolicyVerifyResult>> getSuccessPyMap() {
        return successPyMap;
    }

    public void setSuccessPyMap(Map<String, List<PolicyVerifyResult>> successPyMap) {
        this.successPyMap = successPyMap;
    }

    public long getTimeUsed() {
        return timeUsed;
    }

    public void setTimeUsed(long timeUsed) {
        this.timeUsed = timeUsed;
    }

    public static class PolicyVerifyResult {
        private String pyId;
        private String type;
        private String cause;

        public String getPyId() {
            return pyId;
        }

        public void setPyId(String pyId) {
            this.pyId = pyId;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getCause() {
            return cause;
        }

        public void setCause(String cause) {
            this.cause = cause;
        }
    }
}



