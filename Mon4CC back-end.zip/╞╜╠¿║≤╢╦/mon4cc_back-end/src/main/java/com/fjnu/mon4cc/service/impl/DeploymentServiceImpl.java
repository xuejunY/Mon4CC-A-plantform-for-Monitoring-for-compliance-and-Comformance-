package com.fjnu.mon4cc.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fjnu.mon4cc.entity.Deployment;
import com.fjnu.mon4cc.mapper.DeploymentMapper;
import com.fjnu.mon4cc.service.IDeploymentService;
import org.springframework.stereotype.Service;

/**
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@Service
public class DeploymentServiceImpl extends ServiceImpl<DeploymentMapper, Deployment> implements IDeploymentService {

    @Override
    public Page<Deployment> queryDeploymentConfig(Page page, String deployName,String creater) {
        return page.setRecords(baseMapper.selectDeploymentConfig(page,deployName,creater));
    }

    @Override
    public boolean insert_bance(Deployment deployment) {
        return baseMapper.insertDeployment(deployment);
    }

    @Override
    public boolean deleteByDId(int deploymentId) {
        return baseMapper.deleteDeployment(deploymentId);
    }

    @Override
    public boolean update_bance(Deployment deployment) {
        return baseMapper.updateDeployment(deployment);
    }

    @Override
    public boolean update_state(int deploymentId, String state) {
        return baseMapper.updateState(deploymentId,state);
    }

    @Override
    public boolean submit_bance(Deployment deployment) {
        return baseMapper.submit_bance(deployment);
    }
}
