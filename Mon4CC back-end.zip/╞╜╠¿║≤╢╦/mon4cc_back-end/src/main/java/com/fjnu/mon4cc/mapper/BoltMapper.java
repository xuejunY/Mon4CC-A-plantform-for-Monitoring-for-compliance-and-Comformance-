package com.fjnu.mon4cc.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.fjnu.mon4cc.entity.Bolt;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
public interface BoltMapper extends BaseMapper<Bolt> {
    Bolt selectBolt(@Param("id") String id, @Param("topologyId") String topologyId);

    boolean updateCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("boltCode") String boltCode,@Param("boltCodeSimple") String boltCodeSimple);
    boolean insertCode(@Param("id") String id, @Param("topologyId") String topologyId,
                       @Param("boltCode") String boltCode,@Param("boltCodeSimple") String boltCodeSimple);
    List<Bolt> selectCompleteCode(@Param("topologyId")String topologyId);

}
