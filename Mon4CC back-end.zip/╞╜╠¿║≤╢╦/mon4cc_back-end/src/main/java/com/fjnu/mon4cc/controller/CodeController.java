package com.fjnu.mon4cc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fjnu.mon4cc.entity.Bolt;
import com.fjnu.mon4cc.entity.Kafkaspout;
import com.fjnu.mon4cc.entity.Modelconfiguration;
import com.fjnu.mon4cc.entity.Spout;
import com.fjnu.mon4cc.service.IBoltService;
import com.fjnu.mon4cc.service.IKafkaspoutService;
import com.fjnu.mon4cc.service.ISpoutService;
import com.fjnu.mon4cc.service.IModelconfigurationService;
import com.fjnu.mon4cc.utils.FileUtils;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/topologyconfiguration")
public class CodeController {
    private static final Logger log = LoggerFactory.getLogger(CodeController.class);
    @Autowired
    private IBoltService iBoltService;
    @Autowired
    private ISpoutService iSpoutService;
    @Autowired
    private IKafkaspoutService iKafkaspoutService;
    @Autowired
    private IModelconfigurationService iModelconfigurationService;
//    private String fileUploadPath = "D:\\finalwork\\upload";
//
//    private String fileSavePath = "D:\\com\\mon4cc";
    private String fileUploadPath = "C:\\Users\\Administrator\\finalwork\\upload";

    private String fileSavePath = "C:\\Users\\Administrator\\com\\mon4cc";

    @RequestMapping("/{data}/downloadCode")
    public ResponseEntity<Resource> downloadCode(@PathVariable String data, HttpServletResponse response) throws IOException {

        String oper = "download codes";
        String topologyId = data;
        List<Bolt> boltList = iBoltService.selectCompleteCode(topologyId);
        List<Kafkaspout> kafkaspoutList = iKafkaspoutService.selectCompleteCode(topologyId);
        List<Spout> spoutList = iSpoutService.selectCompleteCode(topologyId);
        List<Modelconfiguration> modelconfigurationList = iModelconfigurationService.selectCompleteCode(topologyId);

        List<File> javaFiles = new ArrayList<>(4);
        if (boltList != null) {
            for (Bolt bolt : boltList) {
                String componentName = bolt.getBoltComponentName();
                String code = bolt.getCompleteBoltCode();
                File file = FileUtils.generateJavaFile(componentName, code);
                javaFiles.add(file);
            }
        }
        if (kafkaspoutList != null) {
            for (Kafkaspout kafkaspout : kafkaspoutList) {
                String componentName = kafkaspout.getSpoutComponentName();
                String code = kafkaspout.getCompleteKafkaSpoutCode();
                File file = FileUtils.generateJavaFile(componentName, code);
                javaFiles.add(file);
            }
        }
        if (spoutList != null) {
            for (Spout spout : spoutList) {
                String componentName = spout.getSpoutComponentName();
                String code = spout.getCompleteSpoutCode();
                File file = FileUtils.generateJavaFile(componentName, code);
                javaFiles.add(file);
            }
        }
        if (modelconfigurationList != null) {
            for (Modelconfiguration modelconfiguration : modelconfigurationList) {
                String componentName = modelconfiguration.getModelName();
                String code = modelconfiguration.getCompleteConfigurationCode();
                File file = FileUtils.generateJavaFile(componentName, code);
                javaFiles.add(file);
            }
        }
        String zipName = System.currentTimeMillis() + ".zip";
        if (javaFiles.size() > 0) {
            File zipFile = FileUtils.compressionFile(javaFiles, fileUploadPath + "\\" + zipName);
            for (File javaFile : javaFiles) {
                if (javaFile.exists()) {
                    javaFile.delete();
                }
            }
            //返回前端zip文件流供下载
            System.out.println(zipFile.getAbsolutePath());
            Path path = Paths.get(zipFile.getAbsolutePath());
            ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));
            HttpHeaders header = new HttpHeaders();
            header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+zipName);
            header.add("Cache-Control", "no-cache, no-store, must-revalidate");
            header.add("Pragma", "no-cache");
            header.add("Expires", "0");
            System.out.println(ResponseEntity.ok()
                    .headers(header)
                    .contentLength(zipFile.length())
                    .contentType(MediaType.parseMediaType("application/zip"))
                    .body(resource));
            return ResponseEntity.ok()
                    .headers(header)
                    .contentLength(zipFile.length())
                    .contentType(MediaType.parseMediaType("application/octet-stream"))
                    .body(resource);
        }
        return null;
    }


    @PostMapping("/saveToLocal")
    public Json saveToLocal(@RequestBody String data) throws IOException {

        String oper = "save to Local";
        String folder = null;
        String folder2 = null;
        JSONObject jsonObj = JSON.parseObject(data);
        String topologyId = jsonObj.getString("topologyId");
        List<Bolt> boltList = iBoltService.selectCompleteCode(topologyId);
        List<Kafkaspout> kafkaspoutList = iKafkaspoutService.selectCompleteCode(topologyId);
        List<Spout> spoutList = iSpoutService.selectCompleteCode(topologyId);
        List<Modelconfiguration> modelconfigurationList = iModelconfigurationService.selectCompleteCode(topologyId);

        List<File> javaFiles = new ArrayList<>(4);
        if (boltList != null) {
            for (Bolt bolt : boltList) {
                String componentName = bolt.getBoltComponentName();
                String code = bolt.getCompleteBoltCode();
                File file = FileUtils.generateJavaFile1(componentName, code);
                javaFiles.add(file);
            }
        }
        if (kafkaspoutList != null) {
            for (Kafkaspout kafkaspout : kafkaspoutList) {
                String componentName = kafkaspout.getSpoutComponentName();
                String code = kafkaspout.getCompleteKafkaSpoutCode();
                File file = FileUtils.generateJavaFile1(componentName, code);
                javaFiles.add(file);
            }
        }
        if (spoutList != null) {
            for (Spout spout : spoutList) {
                String componentName = spout.getSpoutComponentName();
                String code = spout.getCompleteSpoutCode();
                System.out.println(code);
                File file = FileUtils.generateJavaFile1(componentName, code);
                javaFiles.add(file);
            }
        }
        if (modelconfigurationList != null) {
            for (Modelconfiguration modelconfiguration : modelconfigurationList) {
                String componentName = modelconfiguration.getModelName();
                String code = modelconfiguration.getCompleteConfigurationCode();
                File file = FileUtils.generateJavaFile1(componentName, code);
                javaFiles.add(file);
                folder = componentName+".zip";
                folder2 = componentName;
            }
        }
        if (javaFiles.size() > 0) {
            File folderFile = FileUtils.compressionFile(javaFiles, fileUploadPath + "\\" + folder);
            if (folderFile.exists()){
                folderFile.delete();
                File folderFile1 = FileUtils.compressionFile(javaFiles, fileUploadPath + "\\" + folder);
            }
            for (File javaFile : javaFiles) {
                if (javaFile.exists()) {
                    javaFile.delete();
                }
            }

        }
        File file = new File(fileSavePath+"\\"+folder2);
        if(!file.exists()){//如果文件夹不存在
            file.mkdir();//创建文件夹
        }
        FileUtils.unZipFiles(fileUploadPath + "\\" + folder,fileSavePath+"\\"+folder2+"\\");
        return Json.result(oper, true);
    }
}
