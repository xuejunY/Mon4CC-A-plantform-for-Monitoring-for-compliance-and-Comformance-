package com.fjnu.mon4cc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.plugins.Page;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fjnu.mon4cc.entity.Deployment;
import com.fjnu.mon4cc.service.IDeploymentService;
import com.fjnu.mon4cc.utils.PageUtils;
import com.fjnu.mon4cc.vo.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author yangsanhe
 * @since 2020-12-19
 */
@RestController
@RequestMapping("/deploy")
public class DeploymentController {
    private static final Logger log = LoggerFactory.getLogger(DeploymentController.class);
    @Autowired
    private IDeploymentService iDeploymentService;

    @PostMapping("/query")
    public Json query(@RequestBody String body) {
        String oper = "query deployment";
        log.info("{}, body: {}", oper, body);
        JSONObject json = JSON.parseObject(body);
        String deployName = json.getString("deployName");
        String creater = json.getString("creater") ;
        Page<Deployment> page = iDeploymentService.queryDeploymentConfig(PageUtils.getPageParam(json), deployName, creater);
        return Json.succ(oper).data("page", page);
    }

    @PostMapping("/insert")
    public Json add(@RequestBody String body){

        String oper = "add a deployment";
        log.info("{}, body: {}",oper,body);

        Deployment deployment = JSON.parseObject(body, Deployment.class);

        //保存数据
        deployment.setState("unpackaged");

        boolean success = iDeploymentService.insert_bance(deployment);
        return Json.result(oper, success)
                .data("state",deployment.getState());
    }

    @PostMapping("/delete")
    public Json delete(@RequestBody String body) {

        String oper = "delete a deployment";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int deploymentId = jsonObj.getIntValue("deploymentId");
        boolean success = iDeploymentService.deleteByDId(deploymentId);

        return Json.result(oper, success);
    }


    @PostMapping("/update")
    public Json update(@RequestBody String body) {

        String oper = "update deployment config";
        log.info("{}, body: {}",oper,body);

        Deployment deployment = JSON.parseObject(body, Deployment.class);
        boolean success = iDeploymentService.update_bance(deployment);
        return Json.succ(oper,success);
    }

    @PostMapping("/updateState")
    public Json updateState(@RequestBody String body) {

        String oper = "update deployment state";
        log.info("{}, body: {}",oper,body);
        JSONObject jsonObj = JSON.parseObject(body);
        int deploymentId = jsonObj.getIntValue("deploymentId");
        String state = jsonObj.getString("state");

        boolean success = iDeploymentService.update_state(deploymentId,state);
        return Json.succ(oper,success);
    }

    @PostMapping("/submit")
    public Json submit(@RequestBody String body) {

        String oper = "submit jar";
        log.info("{}, body: {}",oper,body);

        JSONObject jsonObj = JSON.parseObject(body);
        int deploymentId = jsonObj.getIntValue("deploymentId");
        Deployment deployment = new Deployment();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        deployment.setSubmissionTime(dateFormat.format(new Date()));
        deployment.setDeploymentId(deploymentId);
        boolean success = iDeploymentService.submit_bance(deployment);
        return Json.succ(oper,success);
    }

}
