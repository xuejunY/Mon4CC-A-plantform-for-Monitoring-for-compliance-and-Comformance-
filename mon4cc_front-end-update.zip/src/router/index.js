import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/authredirect',
    component: () => import('@/views/login/authredirect'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '',
    component: Layout,
    redirect: '/home_page',
    children: [{
      path: 'home_page',
      name: 'HomePage',
      component: () => import('@/views/home_page/index'),
      meta: { title: 'Home Page', icon: 'dashboard', affix: true }
    }]
  },
]

export default new Router({
  mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [
  {
    path: '/modeling',
    component: Layout,
    name: 'Modeling and Design',
    meta: { perm: 'm:model',title: 'Modeling and Design', icon: 'form' },
    children: [
      {
        path: 'my_models',
        name: 'my_models',
        component: () => import('@/views/_modeling/my_models/index'),
        meta: { perm: 'm:model:my_models',title: 'My Models', icon: 'form' }
      },
      {
        path: 'model_design',
        name: 'model_design',
        hidden: true,
        component: () => import('@/views/_modeling/model_design/index'),
        meta: { perm: 'm:model:model_design',title: 'ST-Model Design', icon: 'table' }
      },
      {
        path: 'model_design_type2',
        name: 'model_design_type2',
        hidden: true,
        component: () => import('@/views/_modeling/model_design_type2/index'),
        meta: { perm: 'm:model:model_design_type2',title: 'BP-Model Design', icon: 'table' }
      },
      {
        path: 'code_edit',
        name: 'code_edit',
        hidden: true,
        component: () => import('@/views/_modeling/code_edit/index'),
        meta: { perm: 'm:model:code_edit',title: 'code edit', icon: 'tree'}
      },
      {
        path: 'ecl',
        name: 'ecl',
        hidden: true,
        component: () => import('@/views/_modeling/ecl/index'),
        meta: { perm: 'm:model:ecl',title: 'ecl', icon: 'tree'}
      },
      {
        path: 'model_edit',
        name: 'model_edit',
        hidden: true,
        component: () => import('@/views/_modeling/model_edit/index'),
        meta: { perm: 'm:model:model_edit',title: 'model edit', icon: 'tree'}
      },
      {
        path: 'model_edit_type2',
        name: 'model_edit_type2',
        hidden: true,
        component: () => import('@/views/_modeling/model_edit_type2/index'),
        meta: { perm: 'm:model:model_edit_type2',title: 'model edit type2', icon: 'tree'}
      },
      {
        path: 'choose_node',
        name: 'choose_node',
        hidden: true,
        component: () => import('@/views/_modeling/choose_nodes/index'),
        meta: { perm: 'm:model:choose_node',title: 'choose nodes', icon: 'tree'}
      }
    ]
  },
  {
    path: '/deploying',
    component: Layout,
    redirect: '/deploying',
    name: 'Monitoring Deploy',
    meta: { perm: 'm:deploying:model_deploying',title: 'Monitoring Deploy', icon: 'tree' },
    children: [
      // {
      //   path: 'model_configuration',
      //   name: 'Model Configuration',
      //   component: () => import('@/views/_deploying/model_configuration/index'),
      //   meta: { perm: 'm:deploying:model_configuration',title: 'Model Configuration', icon: 'table' }
      // },
      {
        path: 'model_deploying',
        name: 'Model Deploying',
        component: () => import('@/views/_deploying/model_deploying/index'),
        meta: { perm: 'm:deploying:model_deploying',title: 'Model Deploying', icon: 'tree' }
      }
    ]
  },
  {
    path: '/monitoring',
    component: Layout,
    name: 'Monitoring',
    meta: { perm: 'm:monitoring:monitoring_operation',title: 'Monitoring', icon: 'eye-open' },
    children: [
      {
        path: 'monitoring_operation',
        name: 'monitoring_operation',
        component: () => import('@/views/_monitor/monitoring/index'),
        meta: { perm: 'm:monitoring:monitoring_operation',title: 'Monitoring Operation', icon: 'eye-open' }
      },
      // {
      //   path: 'runningHistory_query',
      //   name: 'runningHistory_query',
      //   component: () => import('@/views/_monitor/runningHistory_query/index'),
      //   meta: { perm: 'm:monitoring:runningHistory_query',title: 'History Query', icon: 'tree' }
      // }
    ]
  },
  // {
  //   path: '/monitoringStates',
  //   component: Layout,
  //   // redirect: '/monitoringStates',
  //   // name: 'Monitoring View',
  //   // meta: { perm: 'm:monitoringStates',title: 'Monitoring View', icon: 'form' },
  //   children: [
  //     {
  //       path: 'state_query',
  //       name: 'state_query',
  //       component: () => import('@/views/_monitoringStates/state_query/index'),
  //       meta: { perm: 'm:monitoringStates:state_query',title: 'State Query', icon: 'table' }
  //     },
  //
  //   ]
  // },
  // {
  //   path: '/statistics',
  //   component: Layout,
  //   children: [
  //     {
  //       path: 'index',
  //       component: () => import('@/views/statistics/index'),
  //       name: 'Statistics Management',
  //       meta: {
  //         perm: 'm:monitoringStates:runningHistory_query',
  //         icon: 'tree',
  //         title: 'Statistics Management',
  //       }
  //     }
  //   ]
  // },
  {
    path: '/system',
    component: Layout,
    meta: { perm:'m:sys', title: 'System', icon: 'table' },
    children: [
      {
        path: 'user_manage',
        name: 'user_manage',
        component:() => import('@/views/_system/user/index'),
        meta: { perm: 'm:sys:user', title: 'User Manage', icon: 'user', noCache: true }
      },
      {
        path: 'role_manage',
        name: 'role_manage',
        component:() => import('@/views/_system/role/index'),
        meta: { perm: 'm:sys:role', title: 'Role Manage', icon: 'eye', noCache: true },
      },
      {
        hidden: true,
        path: 'role_manage/:roleId/assign_perm',
        name: 'role_manage_assign_perm',
        component:() => import('@/views/_system/role/assign_perm'),
        meta: { hiddenTag: true , title: 'Assign Permission',icon: 'tree'},
      },
      {
        path: 'perm_manage',
        name: 'perm_manage',
        component:() => import('@/views/_system/perm/index'),
        meta: { perm: 'm:sys:perm', title: 'Permission Manage', icon: 'example', noCache: true }

      },
    ]
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]


