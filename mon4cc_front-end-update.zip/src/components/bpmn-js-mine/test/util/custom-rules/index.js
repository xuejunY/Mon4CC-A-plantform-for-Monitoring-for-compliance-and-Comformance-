import CustomRules from './CustomRules';

export default {
  __init__: [ 'customRules' ],
  customRules: [ 'type', CustomRules ]
};
