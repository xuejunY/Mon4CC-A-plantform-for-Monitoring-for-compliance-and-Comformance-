<template xmlns:placeholder="http://www.w3.org/1999/xhtml">
  <div class="custom-properties-panel">
    <div v-if="selectedElements.length <= 0">
      <div class="element-item" style="width: 100%;margin-left: -230px">
        <div style="width: 400px;display: inline-block">
          <div style="display: inline-block;;margin-left: -250px">mid:</div>
          <input readonly="readonly" :value="Topology.tid" @change="event => changeField_Topology(event, 'tid')" size="33" >
        </div>
        <div style="width: 200px;display: inline-block;">
          <div style="display: inline-block;margin-left: -220px">modelName:</div>
          <input readonly="readonly" :value="Topology.topologyName" @change="event => changeField_Topology(event, 'topologyName')" size="20" >
        </div>
      </div>
    </div>
    <div v-else>
      <div v-if="isNotFlow" class="element-item">
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -620px">id:</div>
          <input :value="element.id" @change="event => changeField(event, 'id')" size="25" style="height: 25px">
        </div>
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -600px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="25" style="height: 25px">
        </div>
      </div>

      <div v-if="isFlow" class="element-item" style="width: 100%;margin-left: -85px">
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -100px">id:</div>
          <input :value="element.id" @change="event => changeField(event, 'id')" size="25" style="height: 25px">
        </div>
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -150px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="25" style="height: 25px">
        </div>
        <!--      线元素-->
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;;margin-left: -100px">conditionExpression:</div>
          <input :value="element.conditionexpression" @change="event => changeField(event, 'conditionexpression')" size="25" style="height: 25px">
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import modelsApi from "@/api/models";

var Topology1=[];
export default {
  name: 'propertiesView_edit_Type2',
  Topology1,
  props: {
    modeler: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      items:[],
      bpmnModeler: null,
      streams: [],
      selectedElements: [],
      Topology: [{ tid: '' }],
      element: null,
      id: ''
    }
  },
  computed: {
    isFlow() {
      const { element } = this
      return this.verifyIsFlow(element.type)
    },
    isNotFlow() {
      const { element } = this
      return this.verifyIsNotFlow(element.type)
    }

  },
  created() {
    this.init()
  },
  methods: {
    init() {
      // console.log(modeler)
      // console.log(START_EVENT)
      const { modeler } = this
      this.Topology['tid'] = this.$route.params.modelId
      this.Topology['topologyName'] =this.$route.params.modelName
      Topology1['tid'] =this.$route.params.modelId
      Topology1['topologyName'] =this.$route.params.modelName

      modeler.on('selection.changed', e => {
        this.selectedElements = e.newSelection
        this.element = e.newSelection[0]
        this.setDefaultProperties()
      })
      modeler.on('element.changed', e => {
        const { element } = e
        const { element: currentElement } = this
        if (!currentElement) {
          return
        }
        if (element.id === currentElement.id) {
          this.element = element
        }
      })

    },
    setDefaultProperties() {
      const { element } = this
      if (element) {
        const { type, businessObject } = element
        const { name } = businessObject
        this.id = element.id
        if (name!=null){
          let n = name.split("_")
          if (n.length>1){
            element['name'] = n[0]
            element.conditionexpression = n[1]
          }else {
            element['name'] = n[0]
          }
        }else element['name'] = name

      }
    },

    /**
     * 改变控件触发的事件
     * @param { Object } input的Event
     * @param { String } 要修改的属性的名称
     */
    verifyIsFlow(type) {
      return type.includes('SequenceFlow')
    },

    verifyIsNotFlow(type) {
      return !type.includes('SequenceFlow')
      // return type.includes('EndEvent')||type.includes('Task')||type.includes('StartEvent')||type.includes('IntermediateThrowEvent')
    },


    changeField(event, type) {
      const value = event.target.value
      let properties = {}
      if (type==='id'){
        properties['id'] = value
        this.updateProperties(properties)
      }
      if(type === 'name'){
        this.element[type] = value
        const properties = {}
        if (this.element.conditionexpression){
          properties[type] = value+"_"+this.element.conditionexpression
        }else {
          properties[type] = value
        }
        this.updateProperties(properties)
      }
      if (type === 'conditionexpression'){
        this.element[type] = value
        if (!this.element['conditionexpression']){
          properties['name'] = this.element['name']
        }else if (this.element['conditionexpression']){
          properties['name'] = this.element['name']+'_'+this.element['conditionexpression']
        }
        this.updateProperties(properties)
      }
    },
    changeField_Topology(event, type) {
      const value = event.target.value
      this.Topology[type] = value

      Topology1[type] = value
      const properties = {}
      properties[type] = value
      // this.updateProperties(properties)
    },
    /**
     * 更新元素属性
     * @param { Object } 要更新的属性, 例如 { name: '' }
     */
    updateProperties(properties) {
      // eslint-disable-next-line prefer-const
      let { modeler, element } = this
      // if (!element) {
      //   element = this.modeler.get('elementRegistry').get('Process_1')
      // }
      const modeling = modeler.get('modeling')
      modeling.updateProperties(element, properties)
    }
  }
}
</script>

<style scoped>
  .custom-properties-panel {
    position: relative;
    width: 100%;
    background-color: #f8f8f8;
    border-color: rgba(0, 0, 0, 0.09);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);
    padding: 20px;
    height: 100%;
  }
  .Ib{
    text-align: right;
    float:left;
    width:120px;
    display:block;
    /*margin-left: -200px;*/
    font-weight:normal;
  }

  .empty {
    text-align: center;
    height: 200px;
    line-height: 200px;
    font-weight: 700;
  }
  .element-item {
    text-align: center;
    padding: 10px;
    margin-bottom: 5px;
    border: 1px;
    /*border-color: #0e88eb;*/
    border-radius: 8px;
  }
  .element-item:first-child {
    margin-top: 0;
  }
  .custom-properties-panel input,
  .custom-properties-panel textarea {
    padding: 4px 11px;
    color: rgba(0, 0, 0, 0.65);
    font-size: 14px;
    background-color: #fff;
    background-image: none;
    border: 1px solid #d9d9d9;
    border-radius: 4px;
    transition: all 0.3s;
    outline: none;
  }
  .custom-properties-panel input:focus,
  .custom-properties-panel button:focus,
  .custom-properties-panel textarea:focus,
  .custom-properties-panel [contenteditable]:focus {
    border-color: rgb(239, 112, 96);
    box-shadow: 0 0 1px 2px rgb(239, 112, 96, 0.2);
  }
  .custom-properties-panel label {
    font-weight: bold;
  }

  .custom-properties-panel label:after {
    content: ': ';
  }

  .custom-properties-panel button + button {
    margin-left: 10px;
  }
</style>

