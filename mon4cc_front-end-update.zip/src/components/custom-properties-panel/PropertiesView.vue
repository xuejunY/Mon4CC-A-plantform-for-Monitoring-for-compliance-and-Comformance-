<template xmlns:placeholder="http://www.w3.org/1999/xhtml">
  <div class="custom-properties-panel">
    <!--    点击空白处显示process-->
    <div v-if="selectedElements.length <= 0">
      <div class="element-item" style="width: 100%;margin-left: -130px">
        <div style="width: 400px;display: inline-block">
          <div style="display: inline-block;;margin-left: -250px">tid:</div>
          <input readonly="readonly" :value="Topology.tid" @change="event => changeField_Topology(event, 'tid')" size="33" >
        </div>
        <div style="width: 200px;display: inline-block;">
          <div style="display: inline-block;margin-left: -220px">Topology Name:</div>
          <input readonly="readonly" :value="Topology.topologyName" @change="event => changeField_Topology(event, 'topologyName')" size="20" >
        </div>
        <div style="width: 200px;display: inline-block">
          <div style="display: inline-block;margin-left: -60px">Local:</div>
          <input readonly="readonly" :value="Topology.isLocal" @change="event => changeField_Topology(event, 'isLocal')" size="20" >
        </div>
      </div>
    </div>
    <div v-else>
<!--      <div class="element-item" v-if="isNot_intermediateThrowevent">-->
<!--        <div style="width: 350px">-->
<!--        <div class="Ib">id:</div>-->
<!--        <span style="width: 100px">{{ element.id }}</span>-->
<!--        </div>-->
<!--      </div>-->
<!--      非线元素-->
      <div v-if="isNotFlow" class="element-item" style="width: 100%;margin-left: -580px">
        <div style="width: 50px;display: inline-block">
          <el-button size="small" type="primary" @click="codeEdit" style="width: 100px">code edit</el-button>
        </div>

      </div>
<!--      线元素-->
      <div v-if="isFlow" class="element-item" style="width: 100%;margin-left: -280px">
<!--        <div style="width: 350px" hidden>-->
<!--        <div class="Ib">sourceRef:</div>-->
<!--        <span>{{ element.businessObject.sourceRef.id }}</span>-->
<!--        </div>-->
        <div style="width: 350px;display: inline-block">
        <div style="display: inline-block;;margin-left: -250px">edit flow type:</div>
        <select :value="flowType" @change="event => changeField(event, 'flow_type')">
          <option v-for="option in flowTypes" :key="option.value" :value="option.value">{{ option.label }}</option>
        </select>
        </div>
        <div style="width: 150px;display: inline-block;">
        <div style="display: inline-block;margin-left: -300px">Output Stream:</div>
        <select :value="Output_Stream" @change="event => changeField(event, 'stream')">
          <option v-for="option in Output_Streams" :key="option.value" :value="option.value">{{ option.label }}</option>
        </select>
        </div>
      </div>
<!--      SP-->
      <div v-if="isNotFlow_startevent" class="element-item" style="width: 100%;margin-left: -100px">
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -100px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -150px">Parallelism:</div>
          <input :value="element.Parallelism" placeholder='At least 1' @change="event => changeField(event, 'Parallelism')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -100px">Output Stream:</div>
          <input :value="element.OutputStream" placeholder="separate them with ,"  @change="event => changeField(event, 'OutputStream')" size="20">
        </div>
      </div>
      <!--      kafkaSP-->
      <div v-if="isNotFlow_intermediateThrowevent" class="element-item" style="width: 100%;margin-left: -100px">
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: 62px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -2px">Parallelism:</div>
          <input :value="element.Parallelism" placeholder='At least 1' @change="event => changeField(event, 'Parallelism')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: 12px">Output Stream:</div>
          <input :value="element.OutputStream" placeholder="separate them with ,"  @change="event => changeField(event, 'OutputStream')" size="20">
        </div>
        <br>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -20px">bootstrapServers:</div>
          <input :value="element.bootstrapServers" @change="event => changeField(event, 'bootstrapServers')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -40px">maxPollRecords:</div>
          <input :value="element.maxPollRecords" @change="event => changeField(event, 'maxPollRecords')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -20px">enableAutoCommit:</div>
          <input :value="element.enableAutoCommit" @change="event => changeField(event, 'enableAutoCommit')" size="20">
        </div>
        <br>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: 48px">groupId:</div>
          <input :value="element.groupId" @change="event => changeField(event, 'groupId')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -40px">autoOffsetReset:</div>
          <input :value="element.autoOffsetReset" @change="event => changeField(event, 'autoOffsetReset')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: 83px">topic:</div>
          <input :value="element.topic" @change="event => changeField(event, 'topic')" size="20">
        </div>
      </div>

<!--      结束BT-->
      <div v-if="isNotFlow_endevent" class="element-item" style="width: 100%;margin-left: -275px">
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -100px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="20">
        </div>
        <div style="width: 350px;display: inline-block;">
        <div style="display: inline-block;margin-left: -150px">Bolt Parallelism:</div>
        <input :value="element.Parallelism" placeholder='At least 1' @change="event => changeField(event, 'Parallelism')" size="20">
        </div>
      </div>
<!--      BT-->
      <div v-if="isNotFlow_task" class="element-item" style="width: 100%;margin-left: -100px">
        <div style="width: 350px;display: inline-block;">
          <div style="display: inline-block;margin-left: -100px">name:</div>
          <input :value="element.name" @change="event => changeField(event, 'name')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -150px">Parallelism:</div>
          <input :value="element.Parallelism" placeholder='At least 1' @change="event => changeField(event, 'Parallelism')" size="20">
        </div>
        <div style="width: 350px;display: inline-block">
          <div style="display: inline-block;margin-left: -100px">Output Stream:</div>
          <input :value="element.OutputStream" placeholder="separate them with ," @change="event => changeField(event, 'OutputStream')" size="20">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
var Topology1=[];
var OS= {};
var j='1', k='1';
export default {
  name: 'PropertiesView',
  Topology1,
  OS,
  j,
  k,
  props: {
    modeler: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      items:[],
      bpmnModeler: null,
      streams: [],
      selectedElements: [],
      Topology: [{ tid: '' }],
      element: null,
      flowTypes: [
        // { label: '默认', value: '' },
        { label: 'shuffleGrouping', value: 'shuffleGrouping' },
        { label: 'fieldsGrouping', value: 'fieldsGrouping' },
        { label: 'allGrouping', value: 'allGrouping' },
        { label: 'globalGrouping', value: 'globalGrouping' },
        { label: 'noneGrouping', value: 'noneGrouping' },
        { label: 'directGrouping', value: 'directGrouping' }
      ],
      flowType: '',
      localTypes:[
        { label: 'true', value: 'true' },
        { label: 'false', value: 'false' },
      ],
      localType:'',
      Output_Streams: [],
      Output_Stream: '',
      id: ''
    }
  },
  computed: {
    isNot_intermediateThrowevent(){
      const { element } = this
      return !this.verifyIsNotFlow_intermediateThrowevent(element.type)
    },

    isNotFlow_startevent() {
      const { element } = this
      return this.verifyIsNotFlow_startevent(element.type)
    },
    isNotFlow_intermediateThrowevent() {
      const { element } = this
      return this.verifyIsNotFlow_intermediateThrowevent(element.type)
    },
    isNotFlow_endevent() {
      const { element } = this
      return this.verifyIsNotFlow_endevent(element.type)
    },
    isNotFlow_task() {
      const { element } = this
      return this.verifyIsNotFlow_task(element.type)
    },
    isFlow() {
      const { element } = this
      return this.verifyIsFlow(element.type)
    },
    isNotFlow() {
      const { element } = this
      return this.verifyIsNotFlow(element.type)
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      // console.log(modeler)
      // console.log(START_EVENT)
      const { modeler } = this
      this.Topology['tid'] = this.$route.params.tid
      this.Topology['topologyName'] =this.$route.params.topologyName
      if (this.$route.params.isLocal==='1'){
        this.Topology['isLocal'] ='true'
        Topology1['isLocal'] ='true'
      }else {
        this.Topology['isLocal'] ='false'
        Topology1['isLocal'] ='false'
      }
      Topology1['tid'] =this.$route.params.tid
      Topology1['topologyName'] =this.$route.params.topologyName

      modeler.on('selection.changed', e => {
        this.selectedElements = e.newSelection
        this.element = e.newSelection[0]
        this.setDefaultProperties()
      })
      modeler.on('element.changed', e => {
        const { element } = e
        const { element: currentElement } = this
        if (!currentElement) {
          return
        }
        if (element.id === currentElement.id) {
          this.element = element
        }
      })

    },
    setDefaultProperties() {
      this.localType = this.Topology['isLocal']
      const { element } = this
      if (element) {
        const { type, businessObject } = element
        const { name } = businessObject
        this.id = element.id
        if (this.verifyIsFlow(type)) {
          if(element.id==="SequenceFlow_0h21x7r" && !element.flow_type){
            element.flow_type = 'shuffleGrouping'
          }
          this.flowType = element.flow_type
          this.Output_Streams = []
          if(OS[element.businessObject.sourceRef.id.split('_')[0]+'_'+element.businessObject.sourceRef.id.split('_')[1]]){
            var a = OS[element.businessObject.sourceRef.id.split('_')[0]+'_'+element.businessObject.sourceRef.id.split('_')[1]]
            this.Output_Streams = []
            for (let i = 0;i<a.length;i++){
              this.Output_Streams = this.Output_Streams.concat({label: a[i], value: a[i]})
            }
          }
          this.Output_Stream = element.stream
        }
        if(element['isLocal']){
          this.localType = element['isLocal']
        }

        element['name'] = name
      }
    },
    codeEdit() {
      this.$router.push({
        name: 'code_edit',
        params: {
          element: this.element,
          topologyId: Topology1['tid']
        }
      });
    },
    // modelParser(){
    //   console.log(this.items.length)
    //   console.log(this.streams.length)
    // },

    verifyIsNotFlow_intermediateThrowevent(type){
      return type.includes('IntermediateThrowEvent')
    },

    verifyIsNotFlow_startevent(type) {
      return type.includes('StartEvent')
    },
    verifyIsNotFlow_endevent(type) {
      return type.includes('EndEvent')
    },

    verifyIsNotFlow_task(type) {
      return type.includes('Task')
    },

    verifyIsFlow(type) {
      return type.includes('SequenceFlow')
    },
    verifyIsNotFlow(type) {
      // return !type.includes('SequenceFlow')
      return type.includes('EndEvent')||type.includes('Task')||type.includes('StartEvent')||type.includes('IntermediateThrowEvent')
    },
    /**
     * 改变控件触发的事件
     * @param { Object } input的Event
     * @param { String } 要修改的属性的名称
     */

    isRepeat(arr){
      var hash = {};
      for(var i in arr) {
        if(hash[arr[i]])
          return true;
        hash[arr[i]] = true;
      }
      return false;
    },

    changeField(event, type) {
      let value = event.target.value
      // if (type === 'bootstrapServers'){
      //   var v = value.split(":")
      //   value = v[0]+'-'+v[1]
      // }
      this.element[type] = value
      if (type === 'Parallelism') {
        const numReg = /^[0-9]*$/
        const numRe = new RegExp(numReg)
        if (!numRe.test(value) || value < 1) {
          this.$message({
            type: 'error',
            message: 'Please enter a number greater than or equal to 1!',
            duration: 3000,
            showClose: true
          })
          return false
        }
      }
      if(type == 'OutputStream'){
        var os = value.split(",")
        if(this.isRepeat(os)){
          this.$message({
            type:'error',
            message:'Duplicate values are not allowed!',
            duration:3000,
            showClose:true
          })
          return false
        }
        this.$set(OS, this.element.id.split('_')[0]+'_'+this.element.id.split('_')[1], os)
      }
      if(type == 'name'){
        const properties = {}
        properties[type] = value
        this.updateProperties(properties)
      }

      if (type === 'Parallelism' || type==='OutputStream' ||type === 'bootstrapServers'||
        type === 'maxPollRecords' || type === 'enableAutoCommit' || type === 'groupId' ||
        type === 'autoOffsetReset' || type === 'topic') {
        const properties = {}
        if(this.element['id'] && !this.element['Parallelism'] && !this.element['OutputStream'] && !this.element['bootstrapServers'] && !this.element['maxPollRecords']
          && !this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id
        }else if(this.element['id'] && this.element['Parallelism'] && !this.element['OutputStream'] && !this.element['bootstrapServers'] && !this.element['maxPollRecords']
          && !this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']
        }else if(this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && !this.element['bootstrapServers'] && !this.element['maxPollRecords']
          && !this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')
        } else if(this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && !this.element['maxPollRecords']
          && !this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')
        }else if (this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && this.element['maxPollRecords']
          && !this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')+'_'+this.element['maxPollRecords']
        }else if(this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && this.element['maxPollRecords']
          && this.element['enableAutoCommit'] && !this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')+'_'+this.element['maxPollRecords']+'_'+
            this.element['enableAutoCommit']
        }else if (this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && this.element['maxPollRecords']
          && this.element['enableAutoCommit'] && this.element['groupId'] && !this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')+'_'+this.element['maxPollRecords']+'_'+
            this.element['enableAutoCommit']+'_'+this.element['groupId']
        }else if (this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && this.element['maxPollRecords']
          && this.element['enableAutoCommit'] && this.element['groupId'] && this.element['autoOffsetReset'] && !this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')+'_'+this.element['maxPollRecords']+'_'+
            this.element['enableAutoCommit']+'_'+this.element['groupId']+'_'+this.element['autoOffsetReset']
        }else if (this.element['id'] && this.element['Parallelism'] && this.element['OutputStream'] && this.element['bootstrapServers'] && this.element['maxPollRecords']
          && this.element['enableAutoCommit'] && this.element['groupId'] && this.element['autoOffsetReset'] && this.element['topic']){
          properties['id'] = this.id+'_'+this.element['Parallelism']+'_'+this.element['OutputStream'].replace(new RegExp(',','g'),'-')+'_'+this.element['bootstrapServers'].replace(new RegExp(':','g'),'-')+'_'+this.element['maxPollRecords']+'_'+
            this.element['enableAutoCommit']+'_'+this.element['groupId']+'_'+this.element['autoOffsetReset']+'_'+this.element['topic']
        } else {
          properties['id'] = this.id.split("_")[0]+'_'+this.id.split("_")[1]
        }
        this.updateProperties(properties)
      }

      if (type === 'flow_type') {
        const properties = {}
        if(this.element['flow_type'] && !this.element['stream']){
          properties['name'] = this.element['flow_type']
        }else if(this.element['flow_type'] && this.element['stream']){
          properties['name'] = this.element['flow_type']+'_'+this.element['stream']
        }
        this.updateProperties(properties)
      }
      if (type === 'stream') {
        const properties = {}
        if(this.element['flow_type'] && !this.element['stream']){
          properties['name'] = this.element['flow_type']
        }else if(this.element['flow_type'] && this.element['stream']){
          properties['name'] = this.element['flow_type']+'_'+this.element['stream']
        }
        this.updateProperties(properties)
      }

    },
    changeField_Topology(event, type) {
      const value = event.target.value
      this.Topology[type] = value

      Topology1[type] = value
      const properties = {}
      properties[type] = value
      // this.updateProperties(properties)
    },
    /**
     * 更新元素属性
     * @param { Object } 要更新的属性, 例如 { name: '' }
     */
    updateProperties(properties) {
      // eslint-disable-next-line prefer-const
      let { modeler, element } = this
      if (!element) {
        element = this.modeler.get('elementRegistry').get('Process_1')
      }
      const modeling = modeler.get('modeling')
      modeling.updateProperties(element, properties)
    }
  }
}
</script>

<style scoped>
.custom-properties-panel {
  position: relative;
  width: 100%;
  background-color: #f8f8f8;
  border-color: rgba(0, 0, 0, 0.09);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);
  padding: 20px;
  height: 100%;
}
.Ib{
  text-align: right;
  float:left;
  width:120px;
  display:block;
  /*margin-left: -200px;*/
  font-weight:normal;
}

.empty {
  text-align: center;
  height: 200px;
  line-height: 200px;
  font-weight: 700;
}
.element-item {
  text-align: center;
  padding: 10px;
  margin-bottom: 5px;
  border: 1px;
  /*border-color: #0e88eb;*/
  border-radius: 8px;
}
.element-item:first-child {
  margin-top: 0;
}
.custom-properties-panel input,
.custom-properties-panel textarea {
  padding: 4px 11px;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  transition: all 0.3s;
  outline: none;
}
.custom-properties-panel input:focus,
.custom-properties-panel button:focus,
.custom-properties-panel textarea:focus,
.custom-properties-panel [contenteditable]:focus {
  border-color: rgb(239, 112, 96);
  box-shadow: 0 0 1px 2px rgb(239, 112, 96, 0.2);
}
.custom-properties-panel label {
  font-weight: bold;
}

.custom-properties-panel label:after {
  content: ': ';
}

.custom-properties-panel button + button {
  margin-left: 10px;
}
</style>
