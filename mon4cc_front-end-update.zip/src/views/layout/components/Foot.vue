<template>
  <div class="foot">
    ©2021 Ping Gong, XueJun Yu, Bei Xiao, Sanhe Yang. All rights reserved.
  </div>
</template>

<script>
    export default {
        name: "Foot"
    }
</script>

<style>
  .foot{
    /*background: darkgrey;*/
    height: 50px;
    line-height: 50px;
    text-align: right;
    word-wrap: break-word;
    word-break: normal;

    z-index:99999999;
    position:fixed;
    bottom:0;
    left:0;
    width:100%;
    _position:absolute;
    overflow:visible;
  }


</style>
