<template>
  <div class="app-container">
    <!--查询  -->
    <el-row>
      <el-input style="width:200px;" v-model="tableQuery.modelName" placeholder="modelName"></el-input>
      <span style="margin-right: 15px;"></span>
      <el-tooltip class="item" content="search" placement="top" >
        <el-button icon="el-icon-search" circle @click="fetchData(1)"></el-button>
      </el-tooltip>
    </el-row>
    <div style="margin-bottom: 30px;"></div>
<!--    <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleCreate" v-perm="'b:user:add'">{{textMap.create}}</el-button>-->
      <el-button icon="el-icon-plus" size="mini" type="primary" @click="chooseModelType.show = true">add model</el-button>

    <div style="margin-bottom: 30px;"></div>

    <el-table
      ref="multipleTable"
      v-loading="listLoading"
      :data="tableData"
      element-loading-text="拼命加载中"
      border
      fit
      highlight-current-row
      @selection-change="handleSelectionChange"
    >
<!--      <el-table-column type="selection" align="center" />-->
      <el-table-column align="center" label="modelId" width="100px">
        <template slot-scope="scope">
          {{ scope.row.modelId }}
        </template>
      </el-table-column>
      <el-table-column label="modelName" align="center" width="100px" >
        <template slot-scope="scope">
          {{ scope.row.modelName }}
        </template>
      </el-table-column>
      <el-table-column label="local" align="center">
        <template slot-scope="scope">
          {{ scope.row.isLocal===null?"NA":scope.row.isLocal }}
        </template>
      </el-table-column>
      <el-table-column label="type" align="center" width="100px">
        <template slot-scope="scope">
          {{ scope.row.typeName }}
        </template>
      </el-table-column>
      <el-table-column label="des" align="center">
        <template slot-scope="scope">
          {{ scope.row.description }}
        </template>
      </el-table-column>
      <el-table-column label="state" align="center">
        <template slot-scope="scope">
          {{ scope.row.state }}
        </template>
      </el-table-column>
      <el-table-column label="creater" align="center">
        <template slot-scope="scope">
          {{ scope.row.creater }}
        </template>
      </el-table-column>
      <el-table-column label="createTime" align="center" width="152px">
        <template slot-scope="scope">
          {{ scope.row.createTime }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="code operation" width="122px">
        <template slot-scope="scope">
          <div v-if="scope.row.typeName==='ST-Model'">
            <el-tooltip content="generateCode" placement="top">
              <el-button :disabled="scope.row.state=='unparsed'" @click="generateCode(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-s-promotion" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="downloadCode" placement="top">
              <el-button :disabled="scope.row.state=='unparsed'" @click="downloadCode(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-download" circle plain></el-button>
            </el-tooltip>
          </div>
          <div v-else>
            <el-tooltip content="generateEcl" placement="top">
              <el-button  @click="generateEcl(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-s-promotion" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="viewEcl" placement="top">
              <el-button :disabled="scope.row.state!='generated'" @click="viewEcl(scope.$index, tableData)" size="medium" type="info" icon="el-icon-view" circle plain></el-button>
            </el-tooltip>
          </div>

        </template>
      </el-table-column>


      <el-table-column align="center" label="model operation" width="290px">
        <template slot-scope="scope">
          <div v-if="scope.row.typeName==='ST-Model'">
            <el-tooltip content="editConfig" placement="top">
              <el-button @click="editConfig(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-setting" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="editModel" placement="top">
              <el-button @click="editModel(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-edit" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="compile" placement="top">
              <el-button :disabled="scope.row.state!='generated'"  @click="compile(scope.$index, tableData)" size="medium" type="info" icon="el-icon-caret-right" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="deploy" placement="top">
              <el-button :disabled="scope.row.state!='compiled'" @click="deploy(scope.$index, tableData)" size="medium" type="info" icon="el-icon-s-platform" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="monitoring" placement="top">
              <el-button @click="monitor(scope.$index, tableData)" size="medium" type="info" icon="el-icon-monitor" circle plain></el-button>
            </el-tooltip>

            <el-tooltip content="delete" placement="top" >
              <el-button @click="del(scope.$index, tableData)" size="medium" type="danger" icon="el-icon-delete" circle plain></el-button>
            </el-tooltip>
          </div>
          <div v-else>
            <el-tooltip content="editConfig" placement="top">
              <el-button @click="editConfig2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-setting" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="editModel" placement="top">
              <el-button @click="editModel2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-edit" circle plain></el-button>
            </el-tooltip>
<!--            <el-tooltip content="deploy" placement="top">-->
<!--              <el-button :disabled="scope.row.state!='generated'" @click="deploy2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-s-platform" circle plain></el-button>-->
<!--            </el-tooltip>-->
            <el-tooltip content="monitoring" placement="top">
              <el-button @click="monitor(scope.$index, tableData)" size="medium" type="info" icon="el-icon-monitor" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="delete" placement="top" >
              <el-button @click="del(scope.$index, tableData)" size="medium" type="danger" icon="el-icon-delete" circle plain></el-button>
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <div style="margin-bottom: 30px;"></div>
    <!--分页-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="tablePage.current"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="tablePage.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="tablePage.total">
    </el-pagination>

    <el-dialog
      title="Choose Model Type"
      width="400px"
      :visible.sync="chooseModelType.show">
      <el-form size="small" label-width="80px">
        <el-form-item>
          <el-radio-group v-model="chooseModelType.data.type">
            <el-radio :label="0">ST-Model</el-radio>
            <el-radio :label="1">BP-Model</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <el-button>cancel</el-button>
          <el-button type="primary" @click="nextStep">nextStep</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="add storm model"
      width="580px"
      :visible.sync="importModel_1.show">
      <el-form size="small" label-width="120px" :model="importModel_1">
        <el-form-item label="tid" prop="tid">
          <el-input style="width: 300px" v-model="importModel_1.data.modelId"></el-input>
          <el-button style="width: 100px" type="primary" @click="produce_tid">produce tid</el-button>
        </el-form-item>
        <el-form-item label="modelName" prop="modelName">
          <el-input style="width: 300px" v-model="importModel_1.data.modelName"></el-input>
        </el-form-item>
        <el-form-item label="Local" prop="Local">
            <el-radio v-model="importModel_1.data.isLocal" label="1">true</el-radio>
            <el-radio v-model="importModel_1.data.isLocal" label="0">false</el-radio>
        </el-form-item>
        <el-form-item label="typeName" prop="typeName">
          <el-input style="width: 300px" v-model="importModel_1.data.typeName"></el-input>
        </el-form-item>
        <el-form-item label="description" prop="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="importModel_1.data.description"></el-input>
        </el-form-item>
        <el-form-item label="creater" prop="creater">
          <el-input style="width: 300px" v-model="importModel_1.data.creater"></el-input>
        </el-form-item>
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="addModel">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>


    <el-dialog
      title="add business process model"
      width="580px"
      :visible.sync="importModel_2.show">
      <el-form size="small" label-width="120px" :model="importModel_2">
        <el-form-item label="mid" prop="mid">
          <el-input style="width: 300px" v-model="importModel_2.data.modelId"></el-input>
          <el-button style="width: 100px" type="primary" @click="produce_mid">produce mid</el-button>
        </el-form-item>
        <el-form-item label="modelName" prop="modelName">
          <el-input style="width: 300px" v-model="importModel_2.data.modelName"></el-input>
        </el-form-item>

        <el-form-item label="typeName" prop="typeName">
          <el-input style="width: 300px" v-model="importModel_2.data.typeName"></el-input>
        </el-form-item>
        <el-form-item label="description" prop="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="importModel_2.data.description"></el-input>
        </el-form-item>
        <el-form-item label="creater" prop="creater">
          <el-input style="width: 300px" v-model="importModel_2.data.creater"></el-input>
        </el-form-item>
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="addModel2">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="edit model one configuration"
      width="580px"
      :visible.sync="configuration.show">
      <el-form size="small" label-width="120px" :model="configuration.data">
        <el-form-item label="tid">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.modelId"></el-input>
        </el-form-item>
        <el-form-item label="topologyName" prop="modelName">
          <el-input style="width: 300px" v-model="configuration.data.modelName"></el-input>
        </el-form-item>
        <el-form-item label="Local" prop="isLocal">
          <el-radio v-model="configuration.data.isLocal" label="1">true</el-radio>
          <el-radio v-model="configuration.data.isLocal" label="0">false</el-radio>
        </el-form-item>
        <el-form-item label="typeName" prop="typeName">
          <el-input readonly style="width: 300px" v-model="configuration.data.typeName"></el-input>
        </el-form-item>
        <el-form-item label="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="configuration.data.description"></el-input>
        </el-form-item>
        <el-form-item label="state">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.state"></el-input>
        </el-form-item>
        <el-form-item label="creater">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.creater"></el-input>
        </el-form-item>
        <el-form-item label="createTime">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.createTime"></el-input>
        </el-form-item>
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="editConfig_submit">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="edit model two configuration"
      width="580px"
      :visible.sync="configuration2.show">
      <el-form size="small" label-width="120px" :model="configuration2.data">
        <el-form-item label="mid">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration2.data.modelId"></el-input>
        </el-form-item>
        <el-form-item label="modelName" prop="modelName">
          <el-input style="width: 300px" v-model="configuration2.data.modelName"></el-input>
        </el-form-item>

        <el-form-item label="typeName" prop="typeName">
          <el-input readonly style="width: 300px" v-model="configuration2.data.typeName"></el-input>
        </el-form-item>
        <el-form-item label="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="configuration2.data.description"></el-input>
        </el-form-item>
        <el-form-item label="state">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration2.data.state"></el-input>
        </el-form-item>
        <el-form-item label="creater">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration2.data.creater"></el-input>
        </el-form-item>
        <el-form-item label="createTime">
          <el-input readonly="readonly" style="width: 300px" v-model="configuration2.data.createTime"></el-input>
        </el-form-item>
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="editConfig_submit2">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="add deployment"
      width="580px"
      :visible.sync="deployment.show">
      <el-form size="small" label-width="120px" :model="deployment">
        <el-form-item label="tid" prop="modelId">
          <el-input readonly style="width: 300px" v-model="deployment.data.modelId"></el-input>
        </el-form-item>
        <el-form-item label="deployName" prop="deployName">
          <el-input readonly style="width: 300px" v-model="deployment.data.deployName"></el-input>
        </el-form-item>
        <el-form-item label="creater" prop="creater">
          <el-input readonly style="width: 300px" v-model="deployment.data.creater"></el-input>
        </el-form-item>
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="addDeployment">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>


  </div>
</template>

<script>
import login from '@/views/login/index'
import configApi from '@/api/config'
import { pageParamNames } from '@/utils/constants'
import { getToken } from '@/utils/auth'
import { mapGetters } from 'vuex'
import debounce from 'lodash/debounce'
import userApi from '@/api/user'
import deployApi from '@/api/deploy'
const uuid = require('uuid')
import store from '../../../store'
import { xmlStr } from '../../../../mock/xmlStr'
export default {
  // name: 'my_models',
  data() {
    return {
      tableData: null,
      listLoading: true,
      multipleSelection: [],
      tableQuery: {
        modelName: null,
        creater:null
      },
      tablePage: {
        current: null,
        pages: null,
        size: null,
        total: null
      },
      options:[{id:'0',name:'false'},{id:'1',name:'true'}],
      chooseModelType: {
        show:false,
        data: {
          //0 实时 1离线
          type:0,
        }
      },
      importModel_1: {
        show:false,
        data:{
          modelId:"",
          modelName:"",
          isLocal:"",
          typeName:"",
          creater:"",
          description:"",
          modelXml:xmlStr
        }
      },
      importModel_2: {
        show:false,
        data:{
          modelId:"",
          modelName:"",
          typeName:"",
          creater:"",
          description:"",
          modelXml:xmlStr
        }
      },
      configuration:{
        show:false,
        data:{
          modelId:"",
          modelName:"",
          isLocal:"",
          typeName:"",
          description:"",
          state:"",
          creater:"",
          createTime:""
        }
      },
      configuration2:{
        show:false,
        data:{
          modelId:"",
          modelName:"",
          typeName:"",
          description:"",
          state:"",
          creater:"",
          createTime:""
        }
      },
      deployment:{
        show:false,
        data:{
          modelId:"",
          deployName:"",
          creater:""
        }
      }
    }
  },
  mounted() {
    this.fetchData()
  },
  created() {
    this.fetchData()
  },

  watch: {
    //延时查询
    'tableQuery.modelName': debounce(function () {
      this.fetchData()
    }, 500)
  },//watch
  methods: {
    //查询
    async fetchData(current) {
      if(current){
        this.tablePage.current = current
      }
      this.listLoading = true
      this.tableQuery.creater = store.getters.name
      configApi.queryTopologyConfig(this.tableQuery, this.tablePage).then(res => {
        this.tableData = res.data.page.records
        this.listLoading = false
        pageParamNames.forEach(name => this.$set(this.tablePage, name, res.data.page[name]))
      })
    },


    nextStep() {
      this.chooseModelType.show = false;
      if(this.chooseModelType.data.type === 0){
        this.importModel_1.data.creater = store.getters.name
        this.importModel_1.data.typeName = 'ST-Model'
        this.importModel_1.show = true;
      }else {
        this.importModel_2.data.creater = store.getters.name
        this.importModel_2.data.typeName = 'BP-Model'
        this.importModel_2.show = true;
      }

    },

    //分页
    handleSizeChange(val) {
      this.tablePage.size = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.tablePage.current = val;
      this.fetchData();
    },
    produce_tid(){
      // let tid = uuid.v4().replace(new RegExp('-','g'),'')
      let a = Date.now();
      let b = parseInt(Math.random()*89 + 10)
      this.importModel_1.data.modelId = "st"+a+b
    },
    produce_mid(){
      // let mid = uuid.v4().replace(new RegExp('-','g'),'')
      let a = Date.now();
      let b = parseInt(Math.random()*89 + 10)
      this.importModel_2.data.modelId = "bp"+a+b
    },
    addModel(){
      this.importModel_1.show = false;

      configApi.addTopology(this.importModel_1.data).then((res) => {
        this.tableData.unshift(Object.assign({},this.temp))
        ++this.tablePage.total
        this.$message.success("add successfully")
        this.fetchData();
      })

      this.$router.push({
        name: 'model_design',
        params: {
          tid: this.importModel_1.data.modelId,
          topologyName:this.importModel_1.data.modelName,
          isLocal:this.importModel_1.data.isLocal,
          typeName:this.importModel_1.data.typeName,
          description:this.importModel_1.data.description
        }
      });

    },

    addModel2(){
      this.importModel_2.show = false;

      configApi.addTopology(this.importModel_2.data).then((res) => {
        this.tableData.unshift(Object.assign({},this.temp))
        ++this.tablePage.total
        this.$message.success("add successfully")
        this.fetchData();
      })
      this.$router.push({
        name: 'model_design_type2',
        params: {
          modelId: this.importModel_2.data.modelId,
          modelName:this.importModel_2.data.modelName,
          typeName:this.importModel_2.data.typeName,
          description:this.importModel_2.data.description
        }
      });
    },

    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    generateCode(index, rows){
      configApi.generateCode({topologyId: rows[index].modelId}).then(res => {
        this.$message.success("generate successfully")
        configApi.updateState({tid: rows[index].modelId,state:'generated'}).then(res => {
          this.fetchData()
        })


      })

    },

    downloadCode(index, rows){
      let myDate = new Date()
      let a,b,c,d,e=null
      if (myDate.getMonth()+1<10){
        a = '0'+(myDate.getMonth()+1)
      }else a = myDate.getMonth()+1
      if (myDate.getDate()<10){
        b = '0'+myDate.getDate()
      }else b = myDate.getDate()
      if (myDate.getHours()<10){
        c = '0'+ myDate.getHours()
      }else c = myDate.getHours()
      if (myDate.getMinutes()<10){
        d = '0'+ myDate.getMinutes()
      }else d = myDate.getMinutes()
      if (myDate.getSeconds()<10){
        e = '0'+ myDate.getSeconds()
      }else e = myDate.getSeconds()
      let zipName = myDate.getFullYear()+''+a+''+b+''+c+''+d+''+e
      // console.log(zipName)
      this.axios({
        method:'get',
        url:'http://localhost:8888/api/v1/topologyconfiguration/'+rows[index].modelId+'/downloadCode',
        responseType:'blob',
      }).then(res => {
        if (!res) {
          return
        }
        let url = window.URL.createObjectURL(res.data)
        let link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        link.setAttribute('download', rows[index].modelName+zipName+'.zip')
        document.body.appendChild(link)
        link.click()

      })
    },
    del(index, rows){
      this.$confirm('This operation will permanently delete the record. Do you want to continue?', 'Tips', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        // configApi.deleteTopology({topologyId: rows[index].modelId}).then(res => {
        //   this.tableData.splice(index, 1)
        //   --this.tablePage.total
        //   this.$message.success("delete successfully")
        // })
        configApi.updateState({tid: rows[index].modelId,state:"deleted"}).then(res => {
          this.tableData.splice(index, 1)
          --this.tablePage.total
          this.$message.success("delete successfully")
        })

      }).catch(() => {
        this.$message.info("Deletion cancelled")
      });
    },
    // 修改配置
    editConfig(index, rows){
      this.configuration.show = true;
      this.configuration.data.modelId = rows[index].modelId
      this.configuration.data.modelName = rows[index].modelName
      this.configuration.data.isLocal = rows[index].isLocal
      this.configuration.data.typeName = rows[index].typeName
      if (rows[index].isLocal===true){
        this.configuration.data.isLocal = '1'
      }else if (rows[index].isLocal===false){
        this.configuration.data.isLocal = '0'
      }
      this.configuration.data.description = rows[index].description
      this.configuration.data.state = rows[index].state
      this.configuration.data.creater = rows[index].creater
      this.configuration.data.createTime = rows[index].createTime
    },

    editConfig_submit(){
      this.configuration.show = false;
      const tempData = Object.assign({}, this.configuration.data)
      configApi.updateTopology(tempData).then(res => {
        this.fetchData();
        this.$message.success("update successfully")
      })

    },

    // 修改配置2
    editConfig2(index, rows){
      this.configuration2.show = true;
      this.configuration2.data.modelId = rows[index].modelId
      this.configuration2.data.modelName = rows[index].modelName
      this.configuration2.data.typeName = rows[index].typeName
      this.configuration2.data.description = rows[index].description
      this.configuration2.data.state = rows[index].state
      this.configuration2.data.creater = rows[index].creater
      this.configuration2.data.createTime = rows[index].createTime
    },

    editConfig_submit2(){
      this.configuration2.show = false;
      const tempData = Object.assign({}, this.configuration2.data)
      configApi.updateTopology(tempData).then(res => {
        this.fetchData();
        this.$message.success("update successfully")
      })

    },

    editModel(index, rows){
      // console.log(rows[index].tid)
      this.$router.push({
        name: 'model_edit',
        params: {
          tid: rows[index].modelId,
          topologyName : rows[index].modelName,
          isLocal : rows[index].isLocal
        }
      });

    },

    editModel2(index, rows){
      this.$router.push({
        name: 'model_edit_type2',
        params: {
          modelId: rows[index].modelId,
          modelName : rows[index].modelName
        }
      });

    },

    compile(index, rows){
      // 先存本地
      configApi.saveToLocal({topologyId: rows[index].modelId}).then(res => {
        configApi.compile({topologyName: rows[index].modelName}).then(res => {
          configApi.updateState({tid: rows[index].modelId,state:'compiled'}).then(res => {
            this.$message.success("compiled successfully!")
            this.fetchData()
          })
        })
      })
    },

    deploy(index, rows){
      this.deployment.show = true;
      this.deployment.data.modelId = rows[index].modelId
      this.deployment.data.deployName = rows[index].modelName
      this.deployment.data.creater = store.getters.name
    },
    addDeployment(){
      this.deployment.show = false;
      deployApi.addDeployment(this.deployment.data).then((res) => {
        this.tableData.unshift(Object.assign({},this.temp))
        ++this.tablePage.total
        this.$message.success("add successfully")
        this.fetchData();
      })

      this.$router.push({
        path: '/deploying/model_deploying',
      });
    },
    deploy2(index, rows){
      // this.deployment.show = true;
      // this.deployment.data.modelId = rows[index].modelId
      // this.deployment.data.deployName = rows[index].modelName
    },

    generateEcl(index, rows){
      configApi.generateEcl({modelId: rows[index].modelId}).then(res => {
        configApi.updateState({tid: rows[index].modelId,state:'generated'}).then(res => {
          this.$message.success("generated successfully!")
          this.fetchData()
        })
      })

    },
    viewEcl(index, rows){
      this.$router.push({
        name: 'ecl',
        params: {
          modelId: rows[index].modelId,
        }
      });
    },

    monitor(index, rows){
      this.$router.push({
        path: '/monitoring/monitoring_operation',
      });

    },


  }
}
</script>
<style>
.oy-btn{
  display: inline-block;
  height: 28px;
  line-height: 28px;
  /*padding: 0 18px;*/
  background-color: #17bd88;
  color: #fff;
  white-space: nowrap;
  text-align: center;
  font-size: 14px;
  border: none;
  border-radius: 2px;
  cursor: pointer;
}
/*.oy-btn-green{background-color: green;}*/
.oy-btn-sm {
  height: 30px;
  line-height: 30px;
  padding: 0 10px;
  font-size: 12px;
}

</style>
