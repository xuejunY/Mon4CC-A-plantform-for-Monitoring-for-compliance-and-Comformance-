import store from '../../../store'
import {
  isAny
} from 'bpmn-js/lib/features/modeling/util/ModelingUtil'
import { batchCreateCustom, customShapeAction,customShapeAction2} from '././util'
export default function ContextPadProvider(contextPad, config, injector, translate, bpmnFactory, elementFactory, create, modeling, connect) {
  this.create = create
  this.elementFactory = elementFactory
  this.translate = translate
  this.bpmnFactory = bpmnFactory
  this.modeling = modeling
  this.connect = connect
  config = config || {}
  if (config.autoPlace !== false) {
    this.autoPlace = injector.get('autoPlace', false);
  }
  contextPad.registerProvider(this)
}

ContextPadProvider.$inject = [
  'contextPad',
  'config',
  'injector',
  'translate',
  'bpmnFactory',
  'elementFactory',
  'create',
  'modeling',
  'connect'
]

ContextPadProvider.prototype.getContextPadEntries = function(element) {
  const {
    autoPlace,
    create,
    elementFactory,
    translate,
    modeling,
    bpmnFactory,
    connect
  } = this;

  var actions = {}
  var businessObject = element.businessObject

  // 删除功能
  function removeElement(e) {
    modeling.removeElements([element])
  }

  function clickElement(e) {
    console.log(element)
    store.commit('SETNODEINFO', element)
    store.commit('TOGGLENODEVISIBLE', true)
  }

  function createAction(type, group, className, title, options) {
    function appendCustomElements(type) {
      return function(event, element) {
        if (autoPlace) {
          const businessObject = bpmnFactory.create(type)
          const shape = elementFactory.createShape(Object.assign({
            type,
            businessObject
          }, options))
          autoPlace.append(element, shape)
        } else {
          appendCustomElementsStart(event, element)
        }
      }
    }

    function appendCustomElementsStart(type) {
      return function(event) {
        const businessObject = bpmnFactory.create(type)
        const shape = elementFactory.createShape(Object.assign({
          type,
          businessObject
        }, options))
        create.start(event, shape, element)
      }
    }
    return {
      group,
      className,
      title: translate(title),
      action: {
        click: appendCustomElements(type),
        dragstart: appendCustomElementsStart(type)
      }
    }
  }

  function deleteElement() {
    return {
      group: 'edit',
      className: 'icon-custom icon-custom-delete',
      title: translate('delete'),
      action: {
        click: removeElement
      }
    }
  }
  // 结束节点和线只有删除和编辑
  if (isAny(businessObject, ['bpmn:EndEvent', 'bpmn:SequenceFlow'])) {
    Object.assign(actions, {
      'delete': deleteElement()
    })
  }else if (isAny(businessObject, ['bpmn:StartEvent', 'bpmn:Task',
    'bpmn:IntermediateEvent'])) {
    Object.assign(actions, {
      ...batchCreateCustom(customShapeAction, createAction),
      'delete': deleteElement()
    })
  }else{
    Object.assign(actions, {
      ...batchCreateCustom(customShapeAction2, createAction),
      'delete': deleteElement()
    })
  }
  return actions
}

// export default class CustomContextPad {
//     constructor(config, contextPad, create, elementFactory, injector, translate, modeling, bpmnFactory) {
//         this.create = create;
//         this.elementFactory = elementFactory;
//         this.translate = translate;
//         this.modeling = modeling;
//         this.bpmnFactory = bpmnFactory;
//
//         if (config.autoPlace !== false) {
//             this.autoPlace = injector.get('autoPlace', false);
//         }
//
//         contextPad.registerProvider(this); // // 定义这是一个contextPad
//     }
//
//     getContextPadEntries(element) {
//         const {
//             autoPlace,
//             create,
//             elementFactory,
//             translate,
//             modeling,
//             bpmnFactory
//         } = this;
//         // 删除功能
//         function removeElement(e) {
//             modeling.removeElements([element])
//         }
//
//         function clickElement(e) {
//             console.log(element)
//         }
//
//         function appendTask(event, element) {
//             console.log(autoPlace)
//             if (autoPlace) {
//                 const shape = elementFactory.createShape({ type: 'bpmn:Task' });
//                 autoPlace.append(element, shape);
//             } else {
//                 appendTaskStart(event, element);
//             }
//         }
//
//         function appendTaskStart(event) {
//             console.log(event)
//             const shape = elementFactory.createShape({ type: 'bpmn:Task' });
//             create.start(event, shape, element);
//         }
//
//
//         function deleteElement() {
//             return {
//                 group: 'edit',
//                 className: 'icon-custom icon-custom-delete',
//                 title: translate('删除'),
//                 action: {
//                     click: removeElement
//                 }
//             }
//         }
//
//         return {
//             'append.task': {
//                 group: 'model',
//                 className: 'icon-custom task',
//                 title: translate('创建一个类型为task的任务节点'),
//                 action: {
//                     click: appendTask,
//                     dragstart: appendTaskStart
//                 }
//             },
//             'delete': deleteElement(),
//         }
//     }
// }
//
// CustomContextPad.$inject = [
//     'config',
//     'contextPad',
//     'create',
//     'elementFactory',
//     'injector',
//     'translate',
//     'modeling',
//     'bpmnFactory'
// ];
