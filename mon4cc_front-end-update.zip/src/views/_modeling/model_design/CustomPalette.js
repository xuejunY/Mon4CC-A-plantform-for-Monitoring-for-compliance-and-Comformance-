/**
 * A palette that allows you to create BPMN _and_ custom elements.
 */

import { customShapeAction, batchCreateCustom } from '././util'
export default function PaletteProvider(palette, create, elementFactory, globalConnect) {
  this.create = create
  this.elementFactory = elementFactory
  this.globalConnect = globalConnect

  palette.registerProvider(this)
}

PaletteProvider.$inject = [
  'palette',
  'create',
  'elementFactory',
  'globalConnect'
]

PaletteProvider.prototype.getPaletteEntries = function(element) {
  var actions = {}
  const {
    create,
    elementFactory,
  } = this;


  function createAction(type, group, className, title, options) {
    function createListener(event) {
      var shape = elementFactory.createShape(Object.assign({ type }, options))
      create.start(event, shape)
    }

    return {
      group,
      className,
      title: 'add' + title,
      action: {
        dragstart: createListener,
        click: createListener
      }
    }
  }
  Object.assign(actions, {
    ...batchCreateCustom(customShapeAction, createAction)
  })
  return actions
}
// export default class CustomPalette {
//     constructor(bpmnFactory, create, elementFactory, palette, translate) {
//         this.bpmnFactory = bpmnFactory;
//         this.create = create;
//         this.elementFactory = elementFactory;
//         this.translate = translate;
//
//         palette.registerProvider(this);
//     }
//
//     getPaletteEntries(element) {
//         const {
//             bpmnFactory,
//             create,
//             elementFactory,
//             translate
//         } = this;
//
//         function createTask() {
//             return function(event) {
//                 const businessObject = bpmnFactory.create('bpmn:Task');
//                 businessObject['custom'] = 1
//                 const shape = elementFactory.createShape({
//                     type: 'bpmn:Task',
//                     businessObject
//                 });
//                 console.log(shape) // 只在拖动或者点击时触发
//                 create.start(event, shape);
//             }
//         }
//
//         function createStartEvent() {
//           return function(event) {
//             const shape = elementFactory.createShape({
//               type: 'bpmn:StartEvent'
//             });
//             create.start(event, shape);
//           }
//         }
//
// PaletteProvider.prototype.getPaletteEntries = function(element) {
//   const {
//     create,
//     elementFactory
//   } = this;
//   function createEndEvent() {
//     return function (event) {
//       const shape = elementFactory.createShape({
//         type: 'bpmn:EndEvent'
//       });
//       create.start(event, shape);
//     }
//   }
//   return {
//     'create.end-event': {
//       group: 'event',
//       className: 'icon-custom icon-custom-end',
//       title: 'Create EndBolt',
//       action: {
//         dragstart: createEndEvent(),
//         click: createEndEvent()
//       }
//     },
//   }
// }
//
//         return {
//             'create.start-event': {
//               group: 'event',
//               className: 'icon-custom icon-custom-start',
//               title: '创建开始节点',
//               action: {
//                 dragstart: createStartEvent(),
//                 click: createStartEvent()
//               }
//             },
//           'create.end-event': {
//             group: 'event',
//             className: 'icon-custom icon-custom-end',
//             title: 'Create EndBolt',
//             action: {
//               dragstart: createEndEvent(),
//               click: createEndEvent()
//             }
//           },
//
//             'create.task': {
//                 group: 'model',
//                 className: 'icon-custom task',
//                 // className: 'bpmn-icon-user-task',
//                 title: translate('Create Bolt'),
//                 action: {
//                     dragstart: createTask(),
//                     click: createTask()
//                 }
//             }
//         }
//     }
// }
//
// CustomPalette.$inject = [
//     'bpmnFactory',
//     'create',
//     'elementFactory',
//     'palette',
//     'translate'
// ]
