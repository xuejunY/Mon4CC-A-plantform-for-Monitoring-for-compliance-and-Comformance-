<template>
  <div class="components-container">
    <split-pane split="horizontal" @resize="resize" style="margin-right: -50px;margin-left:-45px;min-width:1272px;">
      <template slot="paneL">
        <div class="top-container">
          <div class="containers" ref="content">
            <el-button size="small" type="primary" @click="modelSave">model save</el-button>
            <div class="canvas" ref="canvas"></div>
            <div id="js-properties-panel" class="panel"></div>
          </div>
        </div>
      </template>
      <template slot="paneR">
        <properties-view_edit v-if="bpmnModeler" :modeler="bpmnModeler"></properties-view_edit>
      </template>
    </split-pane>
  </div>
</template>

<script>
// 引入相关的依赖
import BpmnModeler from '../../../components/bpmn-js-mine/lib/Modeler'
import propertiesView_edit from '../../../components/custom-properties-panel/propertiesView_edit'
import propertiesProviderModule from '../../../components/bpmn-js-properties-panel/lib/provider/camunda'

import { mapGetters } from 'vuex'
import { xmlStr2 } from '../../../../mock/xmlStr2'
import customModule from '././onlyContextPad'

import modelApi from '@/api/models'
import configApi from '@/api/config'
import splitPane from 'vue-splitpane'
let modelXml = ''
let tId = ''
export default {
  name: 'model_edit',
  modelXml:'',
  tId:'',
  components: {
    splitPane,
    propertiesView_edit
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  // created() {},
  // 生命周期 - 载入后, Vue 实例挂载到实际的 DOM 操作完成，一般在该过程进行 Ajax 交互
  mounted() {
    this.init()
  },
  created() {
  },
  data() {
    return {
      // bpmn建模器
      bpmnModeler: null,
      container: null,
      canvas: null,
      loading: true,
      defaultXmlStr: '',
    }
  },
  methods: {
    resize() {
      console.log('resize')
    },
    async init() {
      this.loading = true
      this.loading = false
      this.$nextTick(() => {
        this.initBpmn()
      })
    },
    initBpmn() {
      // 获取到属性ref为“content”的dom节点
      this.container = this.$refs.content
      // 获取到属性ref为“canvas”的dom节点
      const canvas = this.$refs.canvas
      // 建模
      this.bpmnModeler = new BpmnModeler({
        container: canvas,
        // 添加控制板
        propertiesPanel: {
          parent: '#js-properties-panel'
        },
        additionalModules: [
          customModule,
          // // // 右边的工具栏(固定引入)
          // propertiesPanelModule,
          // 左边工具栏以及节点
          propertiesProviderModule
        ]
      })
      this.createNewDiagram()
    },
    async createNewDiagram() {
      const that = this
      const tid = this.$route.params.tid
      this.tId = tid

      let bpmnXmlStr = ''
      // 发送请求
      configApi.getModel({ tid:tid }).then(response => {
        bpmnXmlStr = response.data.topologyXml
        this.transformCanvas(bpmnXmlStr)
      })

    },

    // 将字符串转换成图并渲染
    transformCanvas(bpmnXmlStr) {
      this.bpmnModeler.importXML(bpmnXmlStr, (err) => {
        if (err) {
          console.error(err)
        } else {
          this.success()
        }
        // 让图能自适应屏幕
        var canvas = this.bpmnModeler.get('canvas')
        canvas.zoom('fit-viewport')
      })
    },
    success() {
      console.log('Loading successfully!')
      this.addBpmnListener()

    },
    modelSave(){
      let topology = propertiesView_edit.Topology1
      let tid = topology.tid
      let topologyName = topology.topologyName
      let modelXml1 = modelXml
      if (modelXml1){
        let data = {
          tid:tid,
          modelXml:modelXml1
        }
        modelApi.putModel(data).then(response => {
          this.$message.success("save successfully")
          configApi.parseModel({tid: tid}).then(res => {
            // this.$message.success("parse successfully")
            configApi.updateState({tid: tid,state:'parsed'}).then(res => {
            })

          })
        })
      }else return
      // //
      // console.log(tid,topologyName,local)
    },


    // 添加绑定事件
    addBpmnListener () {
      const that = this
      // 给图绑定事件，当图有发生改变就会触发这个事件
      this.bpmnModeler.on('commandStack.changed', function () {
        that.saveDiagram(function(err, xml) {
          modelXml = xml

        })
      })
    },
    // 下载为bpmn格式,done是个函数，调用的时候传入的
    saveDiagram(done) {
      // 把传入的done再传给bpmn原型的saveXML函数调用
      this.bpmnModeler.saveXML({ format: true }, function(err, xml) {
        done(err, xml)
      })
    },
  },
  // 计算属性
  computed: {
    ...mapGetters([
    ])
  }
}
</script>

<style scoped>
.loading {
  font-size: 26px;
}
.containers {
  position: relative;
  background-color: #ffffff;
  /*width: 100%;*/
  height: calc(100vh - 52px);
}
.canvas {
  /*width: 100%;*/
  height: 100%;
}
.panel {
  position: relative;
  right: 0;
  top: 0;
  text-align: center;
  width: 300px;
  /*width: 100%;*/
  /*background-color: #95E1D3;*/
}
.components-container {
  position: relative;
  height: 100vh;
}

.top-container {
  background-color: #FCE38A;
  /*width: 100%;*/
  height: 100%;
}

.bottom-container {
  width: 100%;
  background-color: #f8f8f8;
  height: 100%;
}


</style>
