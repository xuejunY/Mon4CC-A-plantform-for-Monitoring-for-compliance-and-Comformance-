import request from '@/utils/request'
import request3 from "@/utils/request_mine2";
export default {

  queryMonitorTask(queryParam, pageParam) {
    return request({
      url: '/monitortask/query',
      method: 'post',
      data: {
        ...queryParam,
        current: pageParam.current,
        size: pageParam.size
      }
    })
  },
  queryResults(queryParam, pageParam){
    return request({
      url: '/results/queryResults',
      method: 'post',
      data: {
        ...queryParam,
        current: pageParam.current,
        size: pageParam.size
      }
    })
  },
  fetch_Results(queryParam, pageParam) {
    return request({
      url: '/monitortask/fetch_Results',
      method: 'post',
      data: {
        ...queryParam,
        current: pageParam.current,
        size: pageParam.size
      }
    })
  },
  saveXml(data){
    return request({
      url: '/monitortask/saveXml',
      method: 'post',
      data
    })
  },


  addMonitorTask(data){
    return request({
      url: '/monitortask/insert',
      method: 'post',
      data
    })
  },
  deleteMonitorTask(data){
    return request({
      url: '/monitortask/delete',
      method: 'post',
      data
    })
  },
  updateState(data){
    return request({
      url: '/monitortask/updateState',
      method: 'post',
      data
    })
  },
  submitEcl(data){
    return request({
      url: '/monitortask/submitEcl',
      method: 'post',
      data
    })
  },
  start(data){
    return request({
      url: '/monitortask/start',
      method: 'post',
      data
    })
  },

  stop(data){
    return request({
      url: '/monitortask/stop',
      method: 'post',
      data
    })
  },

  pullData(data){
    return request({
      url: '/monitortask/pullData',
      method: 'post',
      data
    })
  },
  getModel(data) {
    return request({
      url: '/monitortask/getXml',
      method: 'post',
      data
    })
  },
  test(data){
    return request({
      url: '/monitortask/test',
      method: 'post',
      data
    })
  },
  mscope(data){
    return request3({
      url: '/model/mscope',
      method: 'post',
      data
    })
  },
  getMessage(data){
    return request({
      url: '/picture/getMessage',
      method: 'post',
      data
    })
  },

  saveXml_ecl(data){
    return request({
      url: '/monitortask/saveXml_ecl',
      method: 'post',
      data
    })
  }


}
