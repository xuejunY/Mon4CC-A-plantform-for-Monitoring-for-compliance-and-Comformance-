import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locale from 'element-ui/lib/locale/lang/en' // lang i18n

import '@/styles/index.scss' // global css

import App from './App'
import store from './store'
import router from './router'
import axios from 'axios'

import '@/icons' // icon
import '@/permission' // permission control
import './errorLog'// error log
import * as filters from './filters' // global filters
import './css/app.css'

// 权限指令
import hasPerm from '@/directive/permission/hasPerm'
import perm from '@/directive/permission/perm'
// 注册全局的权限判断方法和指令
Vue.prototype.$hasPerm = hasPerm
Vue.directive('perm', perm)

Vue.use(ElementUI, {
  size: 'medium', // set element-ui default size
})

// register global utility filters.
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})


// 以下为bpmn工作流绘图工具的样式
import './components/bpmn-js/dist/assets/diagram-js.css' // 左边工具栏以及编辑节点的样式
import './components/bpmn-js/dist/assets/bpmn-font/css/bpmn.css'
import './components/bpmn-js/dist/assets/bpmn-font/css/bpmn-codes.css'
import './components/bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css'

// // 以下为bpmn工作流绘图工具的样式
// import 'bpmn-js-mine/dist/assets/diagram-js-mine.css' // 左边工具栏以及编辑节点的样式
// import 'bpmn-js-mine/dist/assets/bpmn-font/css/bpmn-mine.css'
// import 'bpmn-js-mine/dist/assets/bpmn-font/css/bpmn-codes-mine.css'
// import 'bpmn-js-mine/dist/assets/bpmn-font/css/bpmn-embedded-mine.css'

import './components/bpmn-js-properties-panel/dist/assets/bpmn-js-properties-panel.css' // 右边工具栏样式


Vue.config.productionTip = false
Vue.prototype.axios = axios


/* eslint-disable no-new */
new Vue({
  // el: '#app',
  store,
  router,
  render: h => h(App)
}).$mount('#app')
