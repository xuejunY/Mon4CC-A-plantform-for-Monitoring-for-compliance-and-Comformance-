package com.xb.EclService.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Model2 {
	@Id
	private String tid;
	
	public String getTid() {
		return this.tid;
	}
	
	public void setTid(String tid) {
		this.tid = tid;
	}
	
}
