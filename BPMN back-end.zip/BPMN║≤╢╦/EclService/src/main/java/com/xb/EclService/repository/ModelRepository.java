package com.xb.EclService.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.xb.EclService.entity.Model;

public interface ModelRepository extends PagingAndSortingRepository<Model, String> {

}
