package com.xb.EclService.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="modelconfiguration")
public class Model {
	@Id
	@Column(name="modelId")
	private String id;

	@Column(name="modelXml")
	private String xml;

	@Column(name="modelEcl")
	private String ecl;
	
	public String getId() {
		return this.id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getXml() {
		return this.xml;
	}
	
	public void setXml(String xml) {
		this.xml = xml;
	}
	
	public String getEcl() {
		return this.ecl;
	}
	
	public void setEcl(String ecl) {
		this.ecl = ecl;
	}
	
}
