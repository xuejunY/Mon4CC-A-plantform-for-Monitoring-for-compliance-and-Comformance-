package com.xb.EclService.controller;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xb.EclService.Json;
import com.xb.EclService.entity.Model;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.xb.EclService.repository.ModelRepository;
import com.xb.project.ecl.MscopeECL;
import com.xb.project.utils.*;

@RestController
@RequestMapping(value="/model")
public class Model2Controller {
	@Autowired
	private ModelRepository modelRepository;
	
	@PostMapping("/ecl")
	public Json updateModelEcl(@RequestBody String body) {
		String oper = "update model ecl";

		JSONObject json = JSON.parseObject(body);
		String modelId = json.getString("modelId");

		Optional<Model> optionalModel = modelRepository.findById(modelId);
		if (!optionalModel.isPresent()) {
			return Json.result(oper,  false);
		}
		
		Model model = optionalModel.get();

		String eclContent;
		try {
			eclContent = Util.bpmnxml2Ecl(model.getXml());
		} catch (Exception e) {
			e.printStackTrace();
			return Json.result(oper,  false);
		}
		
		model.setEcl(eclContent);
		modelRepository.save(model);

		return Json.result(oper, true);
	}
	

	@PostMapping("/mscope")
	public Json getMscopeAndEcl(@RequestBody String body) {
		String oper = "get mscope and ecl";

		JSONObject json = JSON.parseObject(body);
		String modelId = json.getString("modelId");
		Set<String> candidates = new HashSet<String>();
		String nodeIds_str = JSONObject.toJSONString(json.getJSONArray("nodeIds"));
		candidates.addAll(JSONObject.parseArray(nodeIds_str, String.class));

		Optional<Model> optionalModel = modelRepository.findById(modelId);
		if (!optionalModel.isPresent()) {
			return Json.result(oper,  false, "no such model id");
		}
		
		Model model = optionalModel.get();

		MscopeECL mscopeEcl = null;
		try {
			mscopeEcl = Util.bpmnxml2MscopeEcl(model.getXml(), candidates);
			
		} catch (Exception e) {
			e.printStackTrace();
			return Json.result(oper,  false, "parse mscope failed");
		}
		
		assert(mscopeEcl != null);
		
		JSONObject jsonObject = new JSONObject();
		JSONArray nodeIds = new JSONArray();
		nodeIds.addAll(mscopeEcl.mscope().nodeIds());

		return Json.result(oper, true).data("nodeIds",nodeIds)
				.data("ecl",mscopeEcl.toString());
	}
}