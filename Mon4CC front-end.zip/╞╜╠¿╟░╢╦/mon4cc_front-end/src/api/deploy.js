import request from '@/utils/request'
import request2 from '@/utils/request_mine'
export default {

  queryDeploymentConfig(queryParam, pageParam) {
    return request({
      url: '/deploy/query',
      method: 'post',
      data: {
        ...queryParam,
        current: pageParam.current,
        size: pageParam.size
      }
    })
  },

  addDeployment(data){
    return request({
      url: '/deploy/insert',
      method: 'post',
      data
    })
  },
  deleteDeployment(data){
    return request({
      url: '/deploy/delete',
      method: 'post',
      data
    })
  },
  // updateDeployment(data){
  //   return request({
  //     url: '/deploy/update',
  //     method: 'post',
  //     data
  //   })
  // },
  updateState(data){
    return request({
      url: '/deploy/updateState',
      method: 'post',
      data
    })
  },

  package(data){
    return request2({
      url: '/mon4cc/model/deploy',
      method: 'post',
      data
    })
  },
  submit(data){
    return request({
      url: '/deploy/submit',
      method: 'post',
      data
    })
  }

}
