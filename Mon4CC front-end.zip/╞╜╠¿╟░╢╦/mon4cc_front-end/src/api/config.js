import request from '@/utils/request'
import request2 from '@/utils/request_mine'
import request3 from "@/utils/request_mine2";
export default {

  queryTopologyConfig(queryParam, pageParam) {
    return request({
      url: '/topologyconfiguration/query',
      method: 'post',
      data: {
        ...queryParam,
        current: pageParam.current,
        size: pageParam.size
      }
    })
  },

  addTopology(data){
    return request({
      url: '/topologyconfiguration/insert',
      method: 'post',
      data
    })
  },
  deleteTopology(data){
    return request({
      url: '/topologyconfiguration/delete',
      method: 'post',
      data
    })
  },
  updateTopology(data){
    return request({
      url: '/topologyconfiguration/update',
      method: 'post',
      data
    })
  },

  parseModel(data){
    return request2({
      url: '/mon4cc/model/parse',
      method: 'post',
      data
    })
  },
  updateState(data){
    return request({
      url: '/topologyconfiguration/updateState',
      method: 'post',
      data
    })
  },


  getModel(data) {
    return request({
      url: '/topologyconfiguration/getXml',
      method: 'post',
      data
    })
  },
  generateCode(data){
    return request2({
      url: '/mon4cc/model/generateCode',
      method: 'post',
      data
    })
  },

  saveToLocal(data) {
    return request({
      url: '/topologyconfiguration/saveToLocal',
      method: 'post',
      data
    })
  },

  compile(data){
    return request2({
      url: '/mon4cc/model/compile',
      method: 'post',
      data
    })
  },

  generateEcl(data){
    return request3({
      url: '/model/ecl',
      method: 'post',
      data
    })
  },
  getModelEcl(data){
    return request({
      url: '/topologyconfiguration/getModelEcl',
      method: 'post',
      data
    })
  },
  selectModelId(data){
    return request({
      url: '/topologyconfiguration/selectModelId',
      method: 'post',
      data
    })
  }

}
