import request from '@/utils/request'
import request2 from '@/utils/request_mine'
import request3 from '@/utils/request_mine2'
export default {
  putModel(data) {
    return request2({
      url: '/mon4cc/model/save',
      method: 'post',
      data
    })
  },

  selectBolt(data){
    return request({
      url: '/bolt/getBolt',
      method: 'post',
      data
    })
  },
  selectSpout(data){
    return request({
      url: '/spout/getSpout',
      method: 'post',
      data
    })
  },
  selectFlow(data) {
    return request({
      url: '/flow/getFlow',
      method: 'post',
      data
    })
  },
  selectKafkaSpout(data){
    return request({
      url: '/kafkaspout/getKafkaSpout',
      method: 'post',
      data
    })
  },

  getBoltCode(data){
    return request({
      url: '/bolt/getBoltCode',
      method: 'post',
      data
    })
  },
  getSpoutCode(data){
    return request({
      url: '/spout/getSpoutCode',
      method: 'post',
      data
    })
  },
  getKafkaSpoutCode(data){
    return request({
      url: '/kafkaspout/getKafkaSpoutCode',
      method: 'post',
      data
    })
  },

  saveBoltCode(data){
    return request({
      url: '/bolt/saveBoltCode',
      method: 'post',
      data
    })
  },
  saveSpoutCode(data){
    return request({
      url: '/spout/saveSpoutCode',
      method: 'post',
      data
    })
  },
  saveKafkaSpoutCode(data){
    return request({
      url: '/kafkaspout/saveKafkaSpoutCode',
      method: 'post',
      data
    })
  },


}
