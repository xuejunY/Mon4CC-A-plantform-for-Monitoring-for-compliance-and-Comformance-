/** 分页查询时，后台返回的数据中分页参数的命名，返回示例：
 *
 * {
 *
 * "msg":"ok",
 * "code":1,
 * "succ":true,
 * "oper":"default",
 * "page":{
 *          "current":1,
 *          "pages":2,
 *          "records":[],
 *          "size":3,
 *          "total":5
 *        }
 * }
 * */
export const pageParamNames = ["current","pages","size","total"]
export const pageParamNames2 = ["current","pages","size","total"]
export const permType = {
  MENU: 1,
  BUTTON: 2,
  API: 3,
}


/**
 * 权限类型
 * @type {Map<any, any>}
 */
export const permTypeMap = new Map([
  [permType.MENU,'menu'],
  [permType.BUTTON,'button'],
  [permType.API,'api']
])

export const confirm = { confirmButtonText: 'confirm', cancelButtonText: 'cancel', type: 'warning'}

export const root = {
  rval: 'root',
  pval: '*'
}
