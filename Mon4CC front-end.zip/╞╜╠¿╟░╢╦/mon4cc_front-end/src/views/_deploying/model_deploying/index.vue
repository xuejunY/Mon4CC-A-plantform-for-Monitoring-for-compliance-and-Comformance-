<template>
  <div class="app-container">
    <!--查询  -->
    <el-row>
      <el-input style="width:200px;" v-model="tableQuery.deployName" placeholder="deployName"></el-input>
      <span style="margin-right: 15px;"></span>
      <el-tooltip class="item" content="search" placement="top" >
        <el-button icon="el-icon-search" circle @click="fetchDeploymentData(1)"></el-button>
      </el-tooltip>
    </el-row>
    <div style="margin-bottom: 30px;"></div>
    <div style="margin-bottom: 30px;"></div>
    <el-table
      ref="multipleTable"
      v-loading="listLoading"
      :data="tableData"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
      @selection-change="handleSelectionChange"
    >
      <!--      <el-table-column type="selection" align="center" />-->
      <el-table-column align="center" label="deploymentId">
        <template slot-scope="scope">
          {{ scope.row.deploymentId }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="modelId">
        <template slot-scope="scope">
          {{ scope.row.modelId }}
        </template>
      </el-table-column>
      <el-table-column label="deployName" align="center">
        <template slot-scope="scope">
          {{ scope.row.deployName }}
        </template>
      </el-table-column>
      <el-table-column label="state" align="center">
        <template slot-scope="scope">
          {{ scope.row.state }}
        </template>
      </el-table-column>
      <el-table-column label="submissionTime" align="center" width="152px">
        <template slot-scope="scope">
          {{ scope.row.submissionTime===null?"NA":scope.row.submissionTime }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="operation" width="200px">
        <template slot-scope="scope">
<!--          <el-tooltip content="editConfig" placement="top">-->
<!--            <el-button @click="editConfig(scope.$index, tableData)" size="medium" type="info" icon="el-icon-edit-outline" circle plain></el-button>-->
<!--          </el-tooltip>-->
          <el-tooltip content="package" placement="top">
            <el-button @click="package(scope.$index, tableData)" size="medium" type="info" icon="el-icon-folder-checked" circle plain></el-button>
          </el-tooltip>

          <el-tooltip content="submit" placement="top">
            <el-button @click="submit(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-upload" circle plain></el-button>
          </el-tooltip>

          <el-tooltip content="monitoring" placement="top">
            <el-button @click="monitor(scope.$index, tableData)" size="medium" type="info" icon="el-icon-monitor" circle plain></el-button>
          </el-tooltip>

          <el-tooltip content="delete" placement="top" >
            <el-button @click="del(scope.$index, tableData)" size="medium" type="danger" icon="el-icon-delete" circle plain></el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <div style="margin-bottom: 30px;"></div>
    <!--分页-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="tablePage.current"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="tablePage.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="tablePage.total">
    </el-pagination>

    <el-dialog
      title="add MonitorTask"
      width="580px"
      :visible.sync="importModel_1.show">
      <el-form size="small" label-width="120px" :model="importModel_1">
        <el-form-item label="taskName" prop="taskName">
          <el-input style="width: 300px" v-model="importModel_1.data.taskName"></el-input>
        </el-form-item>
        <el-form-item label="mid" prop="tid">
          <el-input readonly style="width: 300px" v-model="importModel_1.data.modelId"></el-input>
        </el-form-item>
        <el-form-item label="creater" prop="creater">
          <el-input readonly style="width: 300px" v-model="importModel_1.data.creater"></el-input>
        </el-form-item>
        <el-form-item label="description" prop="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="importModel_1.data.description"></el-input>
        </el-form-item>

        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="addTask">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

<!--    <el-dialog-->
<!--      title="edit deployment configuration"-->
<!--      width="580px"-->
<!--      :visible.sync="configuration.show">-->
<!--      <el-form size="small" label-width="130px" :model="configuration.data">-->
<!--        <el-form-item label="deploymentId">-->
<!--          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.deploymentId"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item label="topologyId">-->
<!--          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.topologyId"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item label="deployName" prop="deployName">-->
<!--          <el-input style="width: 300px" v-model="configuration.data.deployName"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item label="state">-->
<!--          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.state"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item label="submissionTime">-->
<!--          <el-input readonly="readonly" style="width: 300px" v-model="configuration.data.submissionTime"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item style="margin-left: 100px">-->
<!--          <el-button type="primary" @click="editConfig_submit">confirm</el-button>-->
<!--        </el-form-item>-->
<!--      </el-form>-->
<!--    </el-dialog>-->
  </div>
</template>

<script>

import deployApi from '@/api/deploy'
import { pageParamNames } from '@/utils/constants'
import debounce from 'lodash/debounce'
import monitorApi from "@/api/monitor";
import store from "@/store";

export default {
  name: 'model_deploying',
  data() {
    return {
      tableData: null,
      listLoading: true,
      multipleSelection: [],
      tableQuery: {
        deployName: null,
        creater:null
      },
      tablePage: {
        current: null,
        pages: null,
        size: null,
        total: null
      },
      configuration:{
        show:false,
        data:{
          deploymentId:"",
          modelId:"",
          deployName:"",
          state:"",
          submissionTime:"",
        }
      },
      importModel_1: {
        show:false,
        data:{
          taskName:"",
          modelId:"",
          description:"",
          creater:""
        }
      },
    }
  },
  created() {
    this.fetchDeploymentData()
  },
  watch: {
    //延时查询
    'tableQuery.deployName': debounce(function () {
      this.fetchDeploymentData()
    }, 500)
  },
  methods: {
    //查询
    async fetchDeploymentData(current) {
      if(current){
        this.tablePage.current = current
      }
      this.listLoading = true
      this.tableQuery.creater = store.getters.name
      deployApi.queryDeploymentConfig(this.tableQuery, this.tablePage).then(res => {
        this.tableData = res.data.page.records
        this.listLoading = false
        pageParamNames.forEach(name => this.$set(this.tablePage, name, res.data.page[name]))
      })
    },

    addTask(){
      this.importModel_1.show = false;
      monitorApi.addMonitorTask(this.importModel_1.data).then(res => {
        this.$message.success("add successfully")
        this.$router.push({
          path: '/monitoring/monitoring_operation',
        });
        monitoring_operation.fetchData()
      })

    },
    //分页
    handleSizeChange(val) {
      this.tablePage.size = val;
      this.fetchDeploymentData();
    },
    handleCurrentChange(val) {
      this.tablePage.current = val;
      this.fetchDeploymentData();
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    // // 修改配置
    // editConfig(index, rows){
    //   this.configuration.show = true;
    //   this.configuration.data.deploymentId = rows[index].deploymentId
    //   this.configuration.data.topologyId = rows[index].topologyId
    //   this.configuration.data.deployName = rows[index].deployName
    //   this.configuration.data.state = rows[index].state
    //   this.configuration.data.submissionTime = rows[index].submissionTime
    // },

    // editConfig_submit(){
    //   this.configuration.show = false;
    //   const tempData = Object.assign({}, this.configuration.data)
    //   deployApi.updateDeployment(tempData).then(res => {
    //     this.fetchDeploymentData();
    //     this.$message.success("update successfully")
    //   })
    // },
    del(index, rows){
      this.$confirm('This operation will permanently delete the record. Do you want to continue?', 'Tips', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        deployApi.deleteDeployment({deploymentId: rows[index].deploymentId}).then(res => {
          this.tableData.splice(index, 1)
          --this.tablePage.total
          this.$message.success("delete successfully")
        })
      }).catch(() => {
        this.$message.info("Deletion cancelled")
      });
    },


    package(index, rows){
      deployApi.package({topologyName: rows[index].deployName}).then(res => {
        deployApi.updateState({deploymentId:rows[index].deploymentId ,state:"packaged"}).then(res =>{
          this.$message.success("package successfully")
          this.fetchDeploymentData();
        })

      })


    },
    submit(index, rows){
      deployApi.submit({deploymentId:rows[index].deploymentId}).then(res => {
        deployApi.updateState({deploymentId:rows[index].deploymentId ,state:"submitted"}).then(res =>{
          this.$message.success("submitted successfully")
          this.fetchDeploymentData();
        })
      })

    },

    monitor(index, rows){
      this.importModel_1.show = true;
      this.importModel_1.data.modelId = rows[index].modelId
      this.importModel_1.data.creater = store.getters.name
    },

  }
}
</script>
