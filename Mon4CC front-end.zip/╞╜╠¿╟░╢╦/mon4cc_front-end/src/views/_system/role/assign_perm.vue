<template>
  <div class="app-container">

    <el-row>
      <!--角色信息-->
      <span class="page-title">Edit permissions for a role：<el-tag type="info">{{role.rname}}</el-tag></span>
      <router-link to="/system/role_manage" style="float:right">
        <el-button type="text" icon="el-icon-back" >Return to role management page</el-button>
      </router-link>
    </el-row>

    <div style="margin-bottom: 30px;"></div>

    <el-row style="width: 1700px">
      <!--菜单权限树-->
      <el-col :span="8">
        <el-card class="box-card">
          <div slot="header">
            <div class="title-box" style="padding-top: 10px; padding-bottom: 13px;">
              <span><el-tag type="success" >Menu</el-tag>&nbsp;Rights Metadata</span>
            </div>
            <span class="tips-text">Tip: check the permission to authorize the role</span>
          </div>
          <el-input class="mgb-15" :placeholder="filterPlaceholderText" v-model="filterMenuPermText"></el-input>
          <el-tree @check-change="handleUpdateMenuPermForRole" show-checkbox ref="menuPermTreeRef" :filter-node-method="filterNode"
                   :data="menuPermissionTree" :props="treeProps" node-key="pval" default-expand-all :expand-on-click-node="false">
            <span class="custom-tree-node" slot-scope="{ node, data }">
              <span>
                <span class="mgl-10">{{ data.pname }}</span>
                <span class="mgl-10 tips-text">{{ data.pval }}</span>
                <el-tag class="mgl-10" type="success" size="mini">menu</el-tag>
              </span>
            </span>
          </el-tree>
        </el-card>
      </el-col>
    </el-row>

  </div>
</template>

<script>

import tree from '../tree'
import {parseTime, resetTemp} from '@/utils'
import permApi from '@/api/perm'
import roleApi from '@/api/role'
import { permType, permTypeMap} from '@/utils/constants'
import {asyncRoutes} from '@/router' //路由表，定义了菜单和按钮的元数据，可以用来生成权限控制的菜单按钮树
import debounce from 'lodash/debounce'

export default {
  name: 'AssignPerm',
  data() {
    return {
      permType,

      //当前授权的角色
      roleId: null,
      role: {},

      //节点过滤
      filterPlaceholderText: 'Input permission name or permission value to filter',
      filterMenuPermText: '',

      roleMenuPermUpdateSum: 0,

      //角色的权限值
      roleMenuPvals: [],

      menuPermissionTree: [],//菜单权限树

      //挂载到按钮权限树的按钮权限数据。由于按钮权限在菜单权限下，key是菜单权限值，value是按钮权限
      btnPermMap:{},

      treeProps: {
        label: 'pname',
        children: 'children'
      },
    }
  },

  computed:{
    btnCheckboxMap(){
      let map = {}
      this.roleBtnPvals.forEach(pval=>{
        map[pval] = true
      })
      return map;
    },
  },

  watch: {
    'filterMenuPermText': debounce(function (val) {
      this.$refs.menuPermTreeRef.filter(val);
    }, 600),
  },

  created() {
    this.initData()
  },

  methods: {

    //获取后台权限数据
    initData() {
      //获取路由中的角色id
      this.roleId = this.$route.params.roleId
      //显示菜单权限树
      this.menuPermissionTree = tree.generateMenuPermissionTree()

      this.loadRolePerms()
    },

    /**
     * 加载角色的权限并回显
     */
    loadRolePerms(){
      if(!this.roleId){
        this.$message.error('Unable to display permission information for role: role id not found')
        return;
      }
      roleApi.findRolePerms(this.roleId).then(res=>{
        if(res.data.menuPvals.length>0){
          this.roleMenuPvals = res.data.menuPvals
          this.$refs.menuPermTreeRef.setCheckedKeys(res.data.menuPvals)
        }
        this.role = res.data.role
      })
    },

    /**
     * 过滤节点
     */
    filterNode(value, data) {
      if (!value) return true;
      return data.pname.indexOf(value) !== -1 || data.pval.indexOf(value) !== -1 ;
    },
    /**
     * 更新角色的菜单权限
     */
    handleUpdateMenuPermForRole: debounce(function(){
      this.roleMenuPermUpdateSum++;
      //因为初始化勾选角色的权限会触发一次，但这次的权限数据跟后台是一样的，所以不需要触发更新角色的权限
      if(this.roleMenuPvals.length>0 && this.roleMenuPermUpdateSum==1) return;
      let checkedNodes = this.$refs.menuPermTreeRef.getCheckedNodes();
      let halfCheckedNodes = this.$refs.menuPermTreeRef.getHalfCheckedNodes();
      let pvals = [...checkedNodes,...halfCheckedNodes].map(perm=>perm.pval)
      //发送请求更新角色的权限
      let data = {
        rid: this.roleId,
        ptype: permType.MENU,
        pvals: pvals
      }
      roleApi.updateRolePerms(data).then(res=>{
        this.$message.success('update successfully!')
      })
    },500),

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .text {
    font-size: 14px;
  }

  .item {
    margin-bottom: 18px;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }

  .clearfix:after {
    clear: both
  }

  .box-card {
    width: 100%;
  }

  .custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
  }

  .card-title {
    line-height: 50px;
    height: 50px;
  }

  .tips-text {
    font-size: 14px;
    color: #909399;
  }

  .title-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    span {
      font-size: 22px;
    }
  }

  .update-btn {
    margin-left: 20px;
  }

  .delete-btn {
    margin-left: 20px;
    color: #F56C6C;
  }

  .mgl-10 {
    margin-left: 10px;
  }

  .mgb-15 {
    margin-bottom: 15px;
  }

  .page-title{
    font-size: 24px;
    font-weight: bold;
    color: #303133;
  }


</style>
