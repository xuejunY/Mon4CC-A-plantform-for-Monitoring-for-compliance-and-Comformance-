<template>
  <div class="app-container">
    <el-button icon="el-icon-plus" size="mini" type="primary" @click="chooseModelType.show = true">New MonTask</el-button>

    <div style="margin-bottom: 30px;"></div>
    <el-table
      ref="multipleTable"
      v-loading="listLoading"
      :data="tableData"
      element-loading-text="loading!"
      border
      fit
      highlight-current-row
      @selection-change="handleSelectionChange"
    >
      <!--      <el-table-column type="selection" align="center" />-->

      <el-table-column align="center" label="taskId">
        <template slot-scope="scope">
          {{ scope.row.taskId }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="sId">
        <template slot-scope="scope">
          {{ scope.row.sId===null?"NA":scope.row.sId }}
        </template>
      </el-table-column>
      <el-table-column label="taskName" align="center" >
        <template slot-scope="scope">
          {{ scope.row.taskName }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="modelId">
        <template slot-scope="scope">
          {{ scope.row.modelId }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="type">
        <template slot-scope="scope">
          {{ scope.row.typeName }}
        </template>
      </el-table-column>

<!--      <el-table-column label="desc" align="center" hidden>-->
<!--        <template slot-scope="scope">-->
<!--          {{ scope.row.description }}-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="state" align="center">
        <template slot-scope="scope">
          {{ scope.row.state }}
        </template>
      </el-table-column>
<!--      <el-table-column label="creater" align="center" hidden>-->
<!--        <template slot-scope="scope">-->
<!--          {{ scope.row.creater }}-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="createTime" align="center">
        <template slot-scope="scope">
          {{ scope.row.createTime }}
        </template>
      </el-table-column>
      <el-table-column label="readAmount" align="center">
        <template slot-scope="scope">
          {{ scope.row.readAmount }}
        </template>
      </el-table-column>

      <el-table-column label="timeUsed(ms)" align="center">
        <template slot-scope="scope">
          {{ scope.row.timeUsed }}
        </template>
      </el-table-column>

      <el-table-column label="failSummary" align="center">
        <template slot-scope="scope">
          {{ scope.row.failSummary }}
        </template>
      </el-table-column>

      <el-table-column label="succSummary" align="center">
        <template slot-scope="scope">
          {{ scope.row.succSummary }}
        </template>
      </el-table-column>

      <el-table-column label="startDate" align="center">
        <template slot-scope="scope">
          {{ scope.row.startDate===null?"NA":scope.row.startDate }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="operation" width="200px">
        <template slot-scope="scope">
          <div v-if="scope.row.typeName==='ST-Model'">
            <el-tooltip content="submit" placement="top">
              <el-button @click="submit(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-upload2" circle plain></el-button>
            </el-tooltip>
          <el-tooltip content="configuration" placement="top">
            <el-button @click="setconfig(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-setting" circle plain></el-button>
          </el-tooltip>
            <el-tooltip content="startup" placement="top">
              <el-button @click="startup2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-video-play" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="stop" placement="top">
              <el-button @click="stop2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-video-pause" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="visualization" placement="top">
              <el-button @click="visualization2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-view" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="result" placement="top">
              <el-button @click="result2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-folder-add" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="details" placement="top">
              <el-button @click="details2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-tickets" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="delete" placement="top" >
              <el-button @click="del(scope.$index, tableData)" size="medium" type="danger" icon="el-icon-delete" circle plain></el-button>
            </el-tooltip>
          </div>
          <div v-else>
            <el-tooltip content="choose node" placement="top">
              <el-button @click="chooseNodes(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-add-location" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="submit" placement="top">
              <el-button @click="submit2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-upload2" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="configuration" placement="top">
              <el-button @click="setconfig2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-setting" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="startup" placement="top">
              <el-button @click="startup2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-video-play" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="stop" placement="top">
              <el-button @click="stop2(scope.$index, tableData)" size="medium" type="warning" icon="el-icon-video-pause" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="visualization" placement="top">
              <el-button @click="visualization2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-view" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="result" placement="top">
              <el-button @click="result2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-folder-add" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="details" placement="top">
              <el-button @click="details2(scope.$index, tableData)" size="medium" type="info" icon="el-icon-tickets" circle plain></el-button>
            </el-tooltip>
            <el-tooltip content="delete" placement="top" >
              <el-button @click="del(scope.$index, tableData)" size="medium" type="danger" icon="el-icon-delete" circle plain></el-button>
            </el-tooltip>

          </div>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="tablePage.current"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="tablePage.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="tablePage.total">
    </el-pagination>

    <el-dialog
      title="Choose Model Type"
      width="400px"
      :visible.sync="chooseModelType.show">
      <el-form size="small" label-width="80px">
        <el-form-item>
          <el-radio-group v-model="chooseModelType.data.type">
            <el-radio :label="0">ST-Model</el-radio>
            <el-radio :label="1">BP-Model</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <el-button>cancel</el-button>
          <el-button type="primary" @click="nextStep()">nextStep</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="add MonitorTask"
      width="580px"
      :visible.sync="importModel_1.show">
      <el-form size="small" label-width="120px" :model="importModel_1">
        <el-form-item label="taskName" prop="taskName">
          <el-input style="width: 300px" v-model="importModel_1.data.taskName"></el-input>
        </el-form-item>
        <el-form-item label="tid" prop="tid">
          <el-select v-model="importModel_1.data.modelId" placeholder="please choose">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="creater" prop="creater">
          <el-input style="width: 300px" v-model="importModel_1.data.creater"></el-input>
        </el-form-item>
        <el-form-item label="description" prop="description">
          <el-input style="width: 300px" type="textarea" :rows="5" v-model="importModel_1.data.description"></el-input>
        </el-form-item>

        <el-form-item style="margin-left: 100px">
          <el-button type="primary" @click="addTask">confirm</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-dialog
      title="upload ecl"
      :visible.sync="importSTEcl.show"
      width="400px">
      <el-upload
        ref="upload1"
        action="http://localhost:8888/api/v1/monitortask/submitSTEcl"
        :data="param"
        drag
        :limit="1"
        :file-list="fileList"
        :on-exceed="onExceed"
        :before-upload="setParam_ST"
        :on-success="onSuccess_ST"
        :auto-upload="false">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">Drag the file here, or<em>Click Select</em></div>
      </el-upload>
      <span slot="footer" class="dialog-footer">
          <el-button @click="importSTEcl.show = false" size="small">取 消</el-button>
          <el-button type="primary" @click="fileConfig1()" size="small">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="upload log"
      :visible.sync="importDialog.show"
      width="400px">
      <el-upload
        ref="upload"
        action="http://localhost:8888/api/v1/monitortask/file-config"
        :data="param"
        drag
        :limit="1"
        :file-list="fileList"
        :on-exceed="onExceed"
        :before-upload="setParam"
        :on-success="onSuccess"
        :auto-upload="false">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">Drag the file here, or<em>Click Select</em></div>
      </el-upload>
      <span slot="footer" class="dialog-footer">
          <el-button @click="importDialog.show = false" size="small">取 消</el-button>
          <el-button type="primary" @click="fileConfig()" size="small">确 定</el-button>
      </span>
    </el-dialog>
    <div style="margin-bottom: 50px;"></div>
    <el-tabs type="border-card" closable @tab-remove="removeTab" v-model="activeTab" v-show="showTabs">
      <el-tab-pane
        v-for="task in viewTasks"
        :key="task.id"
        :label="task.name"
        :name="task.name">
        <el-form :inline="true" size="small">
          <el-form-item label="monitoring object">
            {{task.name}}
          </el-form-item>
          <el-form-item label="compliance status">
            violation
          </el-form-item>
        </el-form>
        <div style="width:100%;height:90%;overflow-x:auto">
          <div :id="task.chart1.id" style="width:400px;height:400px;display:inline-block"></div>
          <div :id="task.chart2.id" style="width:400px;height:400px;display:inline-block"></div>
          <div :id="task.chart3.id" style="width:400px;height:400px;display:inline-block"></div>
        </div>
      </el-tab-pane>
    </el-tabs>


    <div style="margin-bottom: 50px;"></div>
    <div class="title">result details</div>
    <el-table
      ref="multipleTable"
      v-loading="listLoading2"
      :data="tableData2"
      element-loading-text="loading!"
      border
      fit
      highlight-current-row
      @selection-change="handleSelectionChange2"
    >
<!--      <el-table-column align="center" label="resultId" width="75px">-->
<!--        <template slot-scope="scope">-->
<!--          {{ scope.row.resultId }}-->
<!--        </template>-->
<!--      </el-table-column>-->

      <el-table-column align="center" label="taskId" width="75px">
        <template slot-scope="scope">
          {{ scope.row.taskId }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="resultType" width="95px">
        <template slot-scope="scope">
          {{ scope.row.resultType }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="ruleName" width="120px">
        <template slot-scope="scope">
          {{ scope.row.ruleName }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="cause" width="600px">
        <template slot-scope="scope">
          {{ scope.row.cause }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="pyId" width="80px">
        <template slot-scope="scope">
          {{ scope.row.pyId }}
        </template>
      </el-table-column>

      <el-table-column align="center" label="type">
        <template slot-scope="scope">
          {{ scope.row.type }}
        </template>
      </el-table-column>

    </el-table>
    <!--分页-->
    <el-pagination
      @size-change="handleSizeChange2"
      @current-change="handleCurrentChange2"
      :current-page="tablePage2.current"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="tablePage2.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="tablePage2.total">
    </el-pagination>


  </div>
</template>

<script>

import debounce from 'lodash/debounce'
import monitorApi from '@/api/monitor'
import { pageParamNames } from '@/utils/constants'
import configApi from "@/api/config";
import * as echarts from 'echarts';
import SockJS from 'sockjs-client';
import moment from 'moment';
import store from "@/store";
export default {
  name: 'monitoring_operation',
  computed: {
    showTabs() { //当选项卡无页面时，隐藏选项卡页面
      if(this.viewTasks.length > 0)
        return true;
      else
        return false;
    }
  },
  data() {
    return {
      tableData: null,
      listLoading: true,
      multipleSelection: [],
      tableQuery: {
        taskName: null,
        creater:null
      },
      tableQuery2: {
        taskId: null
      },
      tableQuery3:{
        taskId: null,
        sId: null
      },
      tablePage: {
        current: null,
        pages: null,
        size: null,
        total: null
      },
      //文件上传参数
      param:{sId:""},
      importDialog: {
        show:false,
      },
      importSTEcl:{
        show:false,
      },
      fileList:[],
      options: [],
      chooseModelType: {
        show:false,
        data: {
          type:0,
        }
      },
      chooseDialog:{
        data:{
          taskId:null,
          sId:null
      }
    },
      tableData2: null,
      listLoading2: false,
      multipleSelection2: [],
      tablePage2: {
        current: null,
        pages: null,
        size: null,
        total: null
      },
      importModel_1: {
        show:false,
        data:{
          taskName:"",
          modelId:"",
          description:"",
          creater:""
        }
      },

      data:[],
      optionTemplate1:{  //图表选项
        title: {
          text: '' //显示监控模板名称
        },
        legend: {},
        xAxis: {  //横坐标轴点集
          data: [],
        },
        tooltip: {
          show:true,
          trigger: 'axis'
        },
        yAxis: {
          axisLabel: {
            margin: 2,
          },
        },
        grid: {
          left: 80
        },
        series: [ //数据
          {
            type: "line",
            name: "Number of events",
            data: [],
            label: {
              show:true,
              color:'auto'
            },
            smooth:true,
            itemStyle:{
              color: '#419212'
            }
          }
        ]
      },
      optionTemplate2: {  //图表选项
        title: {
          text: '' //显示监控模板名称
        },
        legend: {},
        xAxis: {  //横坐标轴点集
          data: [],
        },
        tooltip: {
          show:true,
          trigger: 'axis'
        },
        yAxis: {
          axisLabel: {
            margin: 2,
          },
        },
        grid: {
          left: 80
        },
        series: [ //数据
          {
            type: "line",
            name: "Number of violations",
            data: [],
            label: {
              show:true,
              color:'auto'
            },
            smooth:true,
            itemStyle:{
              color: 'red'
            }
          }
        ]
      },
      optionTemplate4 : {
        tooltip : {
          formatter: "{a} <br/>{b} : {c}%"
        },
        series: [
          {
            name: 'Violation rate',
            type: 'gauge',
            detail: {formatter:'{value}%'},
            data: [{value: 50, name: 'Violation rate'}]
          }
        ]
      },
      activeTab:'rule0',
      viewTasks:[],


    }
  },
  created() {
    this.fetchData()
  },
  watch: {
    //延时查询
    'tableQuery.taskName': debounce(function () {
      this.fetchData()
    }, 500)
  },
  methods: {
    //查询
    async fetchData(current) {
      if(current){
        this.tablePage.current = current
      }
      this.listLoading = true
      this.tableQuery.creater = store.getters.name
      monitorApi.queryMonitorTask(this.tableQuery, this.tablePage).then(res => {
        this.tableData = res.data.page.records
        this.listLoading = false
        pageParamNames.forEach(name => this.$set(this.tablePage, name, res.data.page[name]))
      })
    },
    //文件上传相关begin
    onExceed(files, fileList) {
      this.$message({
        type: 'info',
        message: 'Only one file can be uploaded at a time!',
        duration: 3000
      });
    },
    onSuccess(response, file, fileList) {
      if(response.code == 200) {
        this.$notify({
          title: 'success',
          message: response.msg,
          type: 'success'
        });
      } else {
        this.$notify.error({
          title: 'error',
          message: response.msg
        });
      }
      this.fileList = [];
      this.importDialog.show = false;
    },
    onSuccess_ST(response, file, fileList) {
      if(response.code == 200) {
        this.$notify({
          title: 'success',
          message: response.msg,
          type: 'success'
        });
      } else {
        this.$notify.error({
          title: 'error',
          message: response.msg
        });
      }
      this.fetchData()
      this.fileList = [];
      this.importSTEcl.show = false;
    },
    fileConfig() {
      this.$refs.upload.submit();
      this.fetchData()
    },
    fileConfig1(){
      this.$refs.upload1.submit();
      this.fetchData()
    },

    setParam_ST() {
      this.param.taskId = this.chooseDialog.data.taskId;
    },

    setParam() {
      this.param.taskId = this.chooseDialog.data.taskId;
      this.param.sId = this.chooseDialog.data.sId;
    },


    nextStep() {
      this.chooseModelType.show = false;
      if(this.chooseModelType.data.type === 0){
        this.importModel_1.show = true;
        this.importModel_1.data.creater = store.getters.name
        configApi.selectModelId({typeName:"ST-Model",creater:store.getters.name}).then(res => {
          for (let i=0;i<res.data.modelId.length;i++){
            this.options = this.options.concat({label: res.data.modelId[i], value: res.data.modelId[i]})
          }
        })
      }else {
        this.importModel_1.show = true;
        this.importModel_1.data.creater = store.getters.name
        configApi.selectModelId({typeName:"BP-Model",creater:store.getters.name}).then(res => {
          for (let i=0;i<res.data.modelId.length;i++){
            this.options = this.options.concat({label: res.data.modelId[i], value: res.data.modelId[i]})
          }
        })
      }
      this.options = []
    },
    addTask(){
      this.importModel_1.show = false;
      monitorApi.addMonitorTask(this.importModel_1.data).then((res) => {
        this.tableData.unshift(Object.assign({},this.temp))
        ++this.tablePage.total
        this.$message.success("add successfully")
        this.fetchData();
      })


    },
    //分页
    handleSizeChange(val) {
      this.tablePage.size = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.tablePage.current = val;
      this.fetchData();
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },

    // //分页2
    handleSizeChange2(val) {
      this.tablePage2.size = val;
      this.fetchResults();
      monitorApi.queryResults(this.tableQuery2,this.tablePage2).then(res => {
        this.tableData2 = res.data.page.records
        this.listLoading2 = false
        pageParamNames.forEach(name => this.$set(this.tablePage2, name, res.data.page[name]))
      })
    },
    handleCurrentChange2(val) {
      this.tablePage2.current = val;
      this.fetchResults();
      monitorApi.queryResults(this.tableQuery2,this.tablePage2).then(res => {
        this.tableData2 = res.data.page.records
        this.listLoading2 = false
        pageParamNames.forEach(name => this.$set(this.tablePage2, name, res.data.page[name]))
      })
    },
    handleSelectionChange2(val) {
      this.multipleSelection2 = val
    },
    submit(index, rows){
      this.importSTEcl.show = true;
      this.chooseDialog.data.taskId = rows[index].taskId
    },


    setconfig(index, rows){
      this.importDialog.show = true;
      this.chooseDialog.data.taskId = rows[index].taskId
      this.chooseDialog.data.sId = rows[index].sId
    },

    chooseNodes(index, rows){
      configApi.getModelEcl({modelId:rows[index].modelId}).then(res => {
        this.$router.push({
          path: '/modeling/choose_node',
          query: {
            taskId:rows[index].taskId,
            modelId: rows[index].modelId,
            modelName:res.data.modelName
          }
        });
      })


    },

    submit2(index, rows){
      monitorApi.submitEcl({taskId:rows[index].taskId,modelId:rows[index].modelId}).then((res) => {
        monitorApi.updateState({taskId:rows[index].taskId,state:"submitted"}).then((res) => {
          this.$message.success("submitted successfully")
          this.fetchData();
        })
      })
    },
    setconfig2(index, rows){
      this.importDialog.show = true;
      this.chooseDialog.data.taskId = rows[index].taskId
      this.chooseDialog.data.sId = rows[index].sId

    },

    startup2(index, rows){
      monitorApi.start({taskId:rows[index].taskId,sId:rows[index].sId}).then(res => {
        monitorApi.updateState({taskId:rows[index].taskId,state:"RUNNING"}).then(res => {
          this.$message.success("started successfully")
          this.inspectTask(rows[index])
          // monitorApi.pullData({taskId:rows[index].taskId,sId:rows[index].sId}).then(res =>{
            this.fetchData();
          // })

        })
      })

    },
    stop2(index, rows){
      monitorApi.stop({sId:rows[index].sId}).then(res => {
        // monitorApi.updateState({taskId:rows[index].taskId,state:"FINISHED"}).then(res => {
          this.$message.success("stop successfully")
          this.fetchData();
        // })
      })

    },
    visualization2(index, rows){
      this.inspectTask2(rows[index])
      this.fetchData()
    },
    result2(index, rows){
      monitorApi.pullData({taskId:rows[index].taskId,sId:rows[index].sId}).then(res => {
        this.$message.success("get results successfully")
        this.fetchData()
      })
    },

    //查询
     fetchResults(current) {
      if(current){
        this.tablePage2.current = current
      }
      this.listLoading2 = true
    },

    details2(index, rows){
        this.fetchResults()
        this.tableQuery2.taskId = rows[index].taskId
        // this.tableQuery3.sId = rows[index].sId
        monitorApi.queryResults(this.tableQuery2,this.tablePage2).then(res => {
          this.tableData2 = res.data.page.records
          this.listLoading2 = false
          pageParamNames.forEach(name => this.$set(this.tablePage2, name, res.data.page[name]))
        })
    },

    del(index, rows){
      this.$confirm('This operation will permanently delete the record. Do you want to continue?', 'Tips', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        monitorApi.deleteMonitorTask({taskId: rows[index].taskId}).then(res => {
          this.tableData.splice(index, 1)
          --this.tablePage.total
          this.$message.success("delete successfully")
        })
      }).catch(() => {
        this.$message.info("Deletion cancelled")
      });
    },

    removeTab(targetName) {
      let tabs = this.viewTasks;
      let activeName = this.activeTab;
      let task = null;
      if(activeName === targetName) { //如果关闭的tab刚好是当前查看的tab，则移除后，需要展示剩下的某一个tab
        tabs.forEach((tab, index) => {
          if(tab.name === targetName) {
            task = tab;
            //决定展示的下一个tab
            let nextTab = tabs[index + 1] || tabs[index - 1];
            if(nextTab) {
              activeName =  nextTab.name;
            }
          }
        })
      }
      this.activeTab = activeName; //将当前选中项，设为activeName
      //真正的删除操作，通过filter把要删除的数据过滤掉
      this.viewTasks = tabs.filter(tab => tab.name !== targetName);
      //关闭对应的websocket
      if (task.websocketClient){
        task.websocketClient.close();
      }
    },
    addTab(target) { //添加标签页
      this.viewTasks.push(target);
      this.activeTab=target.name;
    },
    inspectTask(task) { //查看任务，同时建立websocket连接
      let item = {
        id:task.taskId, //任务id
        name:task.taskName,  //任务名称
        websocketClient:null,
        chart1:{ //此任务相关图表1
          id:task.taskId + "1",
          option:null,
          handle:null
        },
        chart2:{ //此任务相关图表2
          id:task.taskId + "2",
          option:null,
          handle:null,
        },
        chart3:{ //此任务相关图表3
          id:task.taskId + "3",
          option:null,
          handle:null,
        },
      };
      //利用模板配置图表属性
      item.chart1.option = JSON.parse(JSON.stringify(this.optionTemplate1));
      item.chart2.option = JSON.parse(JSON.stringify(this.optionTemplate2));
      item.chart3.option = JSON.parse(JSON.stringify(this.optionTemplate4));
      //建立websocket连接，并设置相应的回调函数
      //item.websocketClient = new SockJS("http://222.79.40.238:1088/api/v1/websocket");
      item.websocketClient = new SockJS("http://localhost:8888/api/v1/websocket");
      item.websocketClient.onopen = () => {
        item.websocketClient.send(item.id); //以任务id为订阅号
      };
      item.websocketClient.onmessage = (e) => {
        //接收到的数据为JSON字符串文本，需要转为JSON对象
        let data = JSON.parse(e.data);
        console.log("Data received:" + data);
        this.refreshChart(item, data);
      }
      item.websocketClient.onclose = () => {
        console.log("connection closed!");
      }
      //添加到标签页
      this.addTab(item);
      //DOM渲染好后，渲染Echart图表
      this.$nextTick(function() {
        let e1 = document.getElementById(item.chart1.id);
        let e2 = document.getElementById(item.chart2.id);
        let e3 = document.getElementById(item.chart3.id);
        item.chart1.handle = echarts.init(e1);
        item.chart2.handle = echarts.init(e2);
        item.chart3.handle = echarts.init(e3);
        item.chart1.handle.setOption(item.chart1.option);
        item.chart2.handle.setOption(item.chart2.option);
        item.chart3.handle.setOption(item.chart3.option);
      })

    },

    inspectTask2(task) { //查看任务，同时建立websocket连接
      let item = {
        id:task.taskId, //任务id
        name:task.taskName,  //任务名称
        chart1:{ //此任务相关图表1
          id:task.taskId + "1",
          option:null,
          handle:null
        },
        chart2:{ //此任务相关图表2
          id:task.taskId + "2",
          option:null,
          handle:null,
        },
        chart3:{ //此任务相关图表3
          id:task.taskId + "3",
          option:null,
          handle:null,
        },
      };
      //利用模板配置图表属性
      item.chart1.option = JSON.parse(JSON.stringify(this.optionTemplate1));
      item.chart2.option = JSON.parse(JSON.stringify(this.optionTemplate2));
      item.chart3.option = JSON.parse(JSON.stringify(this.optionTemplate4));

      monitorApi.getMessage({taskId:task.taskId}).then(res => {
        for(let i=0;i<res.data.pictures.length;i++){
          let data = JSON.parse("[" + res.data.pictures[i].timestamp + "," + res.data.pictures[i].total + "," + res.data.pictures[i].violatedNum + "," + (res.data.pictures[i].violatedNum == 0 ? 0.0 : (res.data.pictures[i].violatedNum * 1.0 / (res.data.pictures[i].violatedNum + res.data.pictures[i].succNum) * 100).toFixed(3)) + "," + res.data.pictures[i].finished + "]");
          console.log("Data received:" + data);
          this.refreshChart(item, data);
        }

      });

      //添加到标签页
      this.addTab(item);
      //DOM渲染好后，渲染Echart图表
      this.$nextTick(function() {
        let e1 = document.getElementById(item.chart1.id);
        let e2 = document.getElementById(item.chart2.id);
        let e3 = document.getElementById(item.chart3.id);
        item.chart1.handle = echarts.init(e1);
        item.chart2.handle = echarts.init(e2);
        item.chart3.handle = echarts.init(e3);
        item.chart1.handle.setOption(item.chart1.option);
        item.chart2.handle.setOption(item.chart2.option);
        item.chart3.handle.setOption(item.chart3.option);
      })

    },


    refreshChart(item, data) {
      let timestamp = data[0];
      let dateTime = moment(timestamp).format("YYYY-MM-DD hh:mm:ss");
      //刷新chart1
      let chart1 = item.chart1;
      let chart1XData = chart1.option.xAxis.data;
      chart1XData.push(dateTime);
      let chart1YData = chart1.option.series[0].data;
      chart1YData.push(data[1]);
      if(chart1YData.length > 20) { //只显示最近20条记录
        chart1YData.shift();
        chart1XData.shift();
      }
      chart1.handle.setOption(chart1.option);
      //刷新chart2
      let chart2 = item.chart2;
      let chart2XData = chart2.option.xAxis.data;
      chart2XData.push(dateTime);
      let chart2YData = chart2.option.series[0].data;
      chart2YData.push(data[2]);
      if(chart2YData.length > 20) { //只显示最近20条记录
        chart2YData.shift();
        chart2XData.shift();
      }
      chart2.handle.setOption(chart2.option);
      //刷新chart3
      let chart3 = item.chart3;
      chart3.option.series[0].data[0].value = data[3];
      chart3.handle.setOption(chart3.option);
    },
    getSelectedTask() {
      let selected = this.activeTab;
      let selectedItem = null;
      this.viewTasks.forEach((task, index) => {
        if(task.name === selected)
          selectedItem = task;
      })
      return selectedItem;
    },


  }
}
</script>

<style>
.title{
  font-family:"微软雅黑", "宋体", "黑体", Arial;
  font-size: 20px;
  font-weight: bold;
  height: 25px;
  line-height: 25px;
  margin: 18px 0 !important;
  padding: 8px 0 5px 5px;
  text-shadow: 2px 2px 3px #222222;
}

</style>
