const customElements = ['bpmn:StartEvent', 'bpmn:EndEvent', 'bpmn:Task','bpmn:IntermediateEvent'] // 自定义元素的类型
// const STATICPATH = 'https://hexo-blog-1256114407.cos.ap-shenzhen-fsi.myqcloud.com/' // 静态文件路径
// const STATICPATH = '../../../assets/'
const customConfig = { // 自定义元素的配置
  'bpmn:StartEvent': {
    'field': 'start',
    'title': '开始节点',
    'url': require('../../../assets/start.png'),
    'attr': { x: 0, y: 0, width: 40, height: 40 }
  },
  'bpmn:EndEvent': {
    'field': 'end',
    'title': '结束节点',
    'url': require('../../../assets/end.png'),
    'attr': { x: 0, y: 0, width: 40, height: 40 }
  },
  // 'bpmn:SequenceFlow': {
  //   'field': 'flow',
  //   'title': '连接线',
  // },
  'bpmn:Task': {
    'field': 'rules',
    'title': '普通任务',
    'url': require('../../../assets/rules.png'),
    'attr': { x: 0, y: 0, width: 48, height: 48 }
  }

}
const hasLabelElements = ['bpmn:StartEvent', 'bpmn:EndEvent','bpmn:IntermediateEvent'] // 一开始就有label标签的元素类型

// const flowAction = {
//   type: 'global-connect-tool',
//   action: ['bpmn:SequenceFlow', 'tools', 'icon-custom icon-custom-flow', '连接线']
// }
const customShapeAction = [{
  type: 'create.start-event',
  action: ['bpmn:StartEvent', 'event', 'icon-custom icon-custom-start', '开始节点']
},
  {
    type: 'create.end-event',
    action: ['bpmn:EndEvent', 'event', 'icon-custom icon-custom-end', '结束节点']
  },
  {
    type: 'create.task',
    action: ['bpmn:Task', 'activity', 'icon-custom icon-custom-task', '普通任务']
  },
]
const customShapeAction2 = [
  {
    type: 'create.end-event',
    action: ['bpmn:EndEvent', 'event', 'icon-custom icon-custom-end', '结束节点']
  },
  {
    type: 'create.task',
    action: ['bpmn:Task', 'activity', 'icon-custom icon-custom-task', '普通任务']
  },
]
// const customFlowAction = [
//   flowAction
// ]
/**
 * 循环创建出一系列的元素
 * @param {Array} actions 元素集合
 * @param {Object} fn 处理的函数
 */
export function batchCreateCustom(actions, fn) {
  const customs = {}
  actions.forEach(item => {
    customs[item['type']] = fn(...item['action'])
  })
  return customs
}


export { customElements, customConfig,hasLabelElements, customShapeAction,customShapeAction2 }

// const customElements = ['bpmn:Task', 'bpmn:StartEvent','bpmn:EndEvent'] // 自定义元素的类型
// const customConfig = { // 自定义元素的配置
//     'bpmn:Task': {
//         'url': require('../../../assets/rules.png'),
//         // 'url': 'https://hexo-blog-1256114407.cos.ap-shenzhen-fsi.myqcloud.com/rules.png',
//         'attr': { x: 0, y: 0, width: 48, height: 48 }
//     },
//     'bpmn:StartEvent': {
//         'url': require('../../../assets/start.png'),
//         'attr': { x: 0, y: 0, width: 40, height: 40 }
//     },
//     'bpmn:EndEvent': {
//       'url': require('../../../assets/end.png'),
//       'attr': { x: 0, y: 0, width: 40, height: 40 }
//     }
//
//
// }
// const hasLabelElements = ['bpmn:StartEvent', 'bpmn:EndEvent'] // 一开始就有label标签的元素类型
//
// export { customElements, customConfig, hasLabelElements }
