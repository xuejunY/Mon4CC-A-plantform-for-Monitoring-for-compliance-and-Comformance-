<template>
  <div class="components-container">
    <split-pane split="horizontal" @resize="resize" style="margin-left:-45px;min-width:1274px;margin-right: -50px">
      <template slot="paneL">
        <div class="top-container">
          <div class="containers" ref="content">
            <el-button size="small" type="primary" @click="submit">submit</el-button>
            <div class="canvas" ref="canvas"></div>
            <div id="js-properties-panel" class="panel"></div>
          </div>
        </div>
      </template>
      <template slot="paneR">
        <properties-view_choosenodes v-if="bpmnModeler" :modeler="bpmnModeler"></properties-view_choosenodes>
      </template>
    </split-pane>
  </div>
</template>

<script>
// 引入相关的依赖
import BpmnModeler from 'bpmn-js/lib/Modeler'
import propertiesView_choosenodes from '../../../components/custom-properties-panel/propertiesView_choosenodes'
import propertiesProviderModule from 'bpmn-js-properties-panel/lib/provider/camunda'
import customModule from '././onlyContextPad'

import { mapGetters } from 'vuex'

import modelApi from '@/api/models'
import configApi from '@/api/config'
import splitPane from 'vue-splitpane'
import monitor from "@/api/monitor";
let modelXml = ''
export default {
  name: 'choose_node',
  modelXml:'',
  tId:'',
  components: {
    splitPane,
    propertiesView_choosenodes
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  // created() {},
  // 生命周期 - 载入后, Vue 实例挂载到实际的 DOM 操作完成，一般在该过程进行 Ajax 交互
  mounted() {
    this.init()
  },
  created() {
  },
  data() {
    return {
      // bpmn建模器
      bpmnModeler: null,
      container: null,
      canvas: null,
      loading: true,
      defaultXmlStr: '',
    }
  },
  methods: {
    resize() {
      console.log('resize')
    },
    async init() {
      this.loading = true
      this.loading = false
      this.$nextTick(() => {
        this.initBpmn()
      })
    },
    initBpmn() {
      // 获取到属性ref为“content”的dom节点
      this.container = this.$refs.content
      // 获取到属性ref为“canvas”的dom节点
      const canvas = this.$refs.canvas
      // 建模
      this.bpmnModeler = new BpmnModeler({
        container: canvas,
        // 添加控制板
        propertiesPanel: {
          parent: '#js-properties-panel'
        },
        additionalModules: [
          customModule,
          // // // 右边的工具栏(固定引入)
          // propertiesPanelModule,
          // 左边工具栏以及节点
          propertiesProviderModule
        ]
      })
      this.createNewDiagram()
    },
    async createNewDiagram() {
      const that = this
      const taskId = this.$route.query.taskId
      let bpmnXmlStr = ''
      // 发送请求
      monitor.getModel({ taskId:taskId }).then(response => {
        bpmnXmlStr = response.data.modelXml
        this.transformCanvas(bpmnXmlStr)
      })

    },

    // 将字符串转换成图并渲染
    transformCanvas(bpmnXmlStr) {
      this.bpmnModeler.importXML(bpmnXmlStr, (err) => {
        if (err) {
          console.error(err)
        } else {
          this.success()
        }
        // 让图能自适应屏幕
        var canvas = this.bpmnModeler.get('canvas')
        canvas.zoom('fit-viewport')
      })
    },
    success() {
      console.log('Loading successfully!')
      this.addBpmnListener()

    },

    submit() {
      let modelId = this.$route.query.modelId
      if (propertiesView_choosenodes.data().nodeId.length != 0) {
        monitor.mscope({modelId: modelId, nodeIds: propertiesView_choosenodes.data().nodeId}).then(res => {
          // console.log(res.data.ecl)
          console.log(res.data.nodeIds)
          monitor.test({taskId:propertiesView_choosenodes.data().taskId, nodeId:res.data.nodeIds, ecl:res.data.ecl}).then(res => {
             this.$message.success("submitted successfully!")
           })

        })
      }else {
         // configApi.getModel({tid: modelId}).then(res => {
           // monitor.saveXml({taskId:propertiesView_choosenodes.data().taskId,modelXml1:res.data.topologyXml}).then(res => {
           //   this.$message.success("submitted successfully!")
           // })
        console.log(modelId)
           monitor.saveXml_ecl({taskId:propertiesView_choosenodes.data().taskId,modelId:modelId}).then(res => {
             this.$message.success("submitted successfully!")
           })

         // })
       }
    },


    // 添加绑定事件
    addBpmnListener () {
      const that = this
      // 给图绑定事件，当图有发生改变就会触发这个事件
      this.bpmnModeler.on('commandStack.changed', function () {
        that.saveDiagram(function(err, xml) {
          modelXml = xml
          // console.log(modelXml)
          // monitor.saveXml({taskId:propertiesView_choosenodes.data().taskId,modelXml1:xml}).then(res => {
          //
          // })
        })
      })
    },
    // 下载为bpmn格式,done是个函数，调用的时候传入的
    saveDiagram(done) {
      // 把传入的done再传给bpmn原型的saveXML函数调用
      this.bpmnModeler.saveXML({ format: true }, function(err, xml) {
        done(err, xml)
      })
    },
  },
  // 计算属性
  computed: {
    ...mapGetters([
    ])
  }
}
</script>

<style scoped>
.loading {
  font-size: 26px;
}
.containers {
  position: relative;
  background-color: #ffffff;
  width: 100%;
  height: calc(100vh - 52px);
}
.canvas {
  width: 100%;
  height: 100%;
  /*min-width: 1272px;*/
}
.panel {
  position: relative;
  right: 0;
  top: 0;
  text-align: center;
  width: 300px;
  /*width: 100%;*/
  /*background-color: #95E1D3;*/
}
.components-container {
  position: relative;
  height: 100vh;
}

.top-container {
  background-color: #FCE38A;
  width: 100%;
  height: 100%;
}

.bottom-container {
  width: 100%;
  background-color: #f8f8f8;
  height: 100%;
}


</style>
