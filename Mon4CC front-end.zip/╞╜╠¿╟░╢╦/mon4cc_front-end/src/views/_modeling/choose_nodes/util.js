const customElements = ['bpmn:UserTask','bpmn:IntermediateThrowEvent'] // 自定义元素的类型

const customConfig = { // 自定义元素的配置
  'bpmn:UserTask': {
    'field': 'rules',
    'title': 'Monitoring task',
    'url': require('../../../assets/task.png'),
    'attr': { x: 0, y: 0, width: 108, height: 85 }
  },
  'bpmn:IntermediateThrowEvent': {
    'field': 'start',
    'title': 'Monitoring start/end node',
    'url': require('../../../assets/event.png'),
    'attr': { x: 0, y: 0, width: 40, height: 40 }
  },


}
const hasLabelElements = ["bpmn:IntermediateThrowEvent"] // 一开始就有label标签的元素类型

// const customShapeAction = [
//   {
//     type: 'create.user-task',
//     action: ['bpmn:UserTask', 'activity', 'icon-custom icon-custom-task', '监控任务']
//   },
// ]
// const customShapeAction2 = [
//   {
//     type: 'create.user-task',
//     action: ['bpmn:UserTask', 'activity', 'icon-custom icon-custom-task', '监控任务']
//   },
// ]

/**
 * 循环创建出一系列的元素
 * @param {Array} actions 元素集合
 * @param {Object} fn 处理的函数
 */
export function batchCreateCustom(actions, fn) {
  const customs = {}
  actions.forEach(item => {
    customs[item['type']] = fn(...item['action'])
  })
  return customs
}


export { customElements, customConfig,hasLabelElements }

