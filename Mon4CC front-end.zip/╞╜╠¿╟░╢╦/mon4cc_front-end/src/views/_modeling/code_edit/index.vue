<template>
  <div class="app-container">
    <div class="operation">
      <div style="height: 160px">
        <el-button size="small" @click="$router.push('/')">close</el-button>

<!--        <el-button size="small" @click="verify">语法检查</el-button>-->

        <el-button size="small" type="primary" @click="save()">save</el-button>
      </div>
    </div>
    <div class="codePanel">
      <div class="title">{{title}}</div>
      <div class="code">
        <div id="editor"></div>
      </div>
    </div>
  </div>
</template>

<script>
import ace from 'brace';
import modelsApi from "@/api/models";
import {mapGetters} from 'vuex';
import modelApi from '@/api/models'
export default {
  name: "code_edit",
  components:{},
  data() {
    return {
      mode:0, //0表示新建，1表示保存已有
      title:'Code Edit',
      editor:null,
      showDialog: false,
      showErorDialog: false,
      checked:false, //是否已经过语法检查
      checkResult:null, //检查结果，-1未通过， 1通过
      errors:[],
    }
  },
  mounted() {
    this.init()
  },
  created() {
  },
  methods: {
    init(){
      this.editor = ace.edit("editor");
      this.editor.setFontSize(16); //设置字体大小
      require('brace/mode/java');
      require('brace/theme/eclipse');
      this.editor.getSession().setMode('ace/mode/java');
      this.editor.setTheme('ace/theme/eclipse');
      let id = this.$route.params.element.id.split('_')[0]+'_'+this.$route.params.element.id.split('_')[1]
      if (this.$route.params.element.type==="bpmn:StartEvent"){
        modelsApi.getSpoutCode({id:id,topologyId:this.$route.params.topologyId}).then(res => {
          if (res.data.spoutCode!==null){
            this.editor.setValue(res.data.spoutCode)
          }else {
            this.editor.setValue('/*\n' +
              '//There is a demo\n' +
              'public class TwitterStreamAPISpout{\n' +
              '\t\n' +
              '\t\n' +
              '\tRandom _rand ;\n' +
              '\t\n' +
              '\t//Assume you need generate random number, you can initiial here\n' +
              '\tpublic void open(SpoutOutputCollector collector){\n' +
              '\t\t\n' +
              '\t\tthis._rand = new Random() ;\n' +
              '\t}\n' +
              '\n' +
              '\t//Assume this spout work for send a random number per 100 ms ;\n' +
              '\tpublic void nextTuple(){\n' +
              '\t\tThread.sleep(100) ;\n' +
              '\t\t_collector.emit("S1", new Values(_rand.nextInt(10))) ;\n' +
              '\t\t_collector.emit("S2", new Values(_rand.nextInt(10))) ;\n' +
              '\t}\n' +
              '}\n' +
              '*/\n' +
              'public class '+this.$route.params.element.name+'Spout{\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void open(Map conf, TopologyContext context, SpoutOutputCollector collector){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void nextTuple(){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void ack(Object id){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void fail(Object id){\n' +
              '\n' +
              '\t}\n' +
              '}\n')
          }
        })

      }else if (this.$route.params.element.type==="bpmn:IntermediateThrowEvent"){
        modelsApi.getKafkaSpoutCode({id:id,topologyId:this.$route.params.topologyId}).then(res => {
          if (res.data.kafkaSpoutCode !== null) {
            this.editor.setValue(res.data.kafkaSpoutCode)
          }else {
            this.editor.setValue('/*\n' +
              '//There is a demo\n' +
              'public class TwitterStreamAPISpout{\n' +
              '\t\n' +
              '\tSpoutOutputCollector _collector ;\n' +
              '\tRandom _rand ;\n' +
              '\t\n' +
              '\t//Assume you need generate random number, you can initiial here\n' +
              '\tpublic void open(SpoutOutputCollector collector){\n' +
              '\t\tthis._collector = collector ;\n' +
              '\t\tthis._rand = new Random() ;\n' +
              '\t}\n' +
              '\n' +
              '\t//Assume this spout work for send a random number per 100 ms ;\n' +
              '\tpublic void nextTuple(){\n' +
              '\t\tThread.sleep(100) ;\n' +
              '\t\t_collector.emit("S1", new Values(_rand.nextInt(10))) ;\n' +
              '\t\t_collector.emit("S2", new Values(_rand.nextInt(10))) ;\n' +
              '\t}\n' +
              '}\n' +
              '*/\n' +
              'public class '+this.$route.params.element.name+'Spout{\n' +
              '\n' +
              '\tprivate KafkaConsumer<String,String> consumer;\n' +
              '\tprivate ConsumerRecords<String, String> msgList;\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void open(Map conf, TopologyContext context, SpoutOutputCollector collector){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void nextTuple(){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void ack(Object id){\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '\t@Override\n'+
              '\tpublic void fail(Object id){\n' +
              '\n' +
              '\t}\n' +
              '}\n')
          }
        })
      }else if(this.$route.params.element.type==="bpmn:EndEvent"|| this.$route.params.element.type==="bpmn:Task"){
        modelsApi.getBoltCode({id:id,topologyId:this.$route.params.topologyId}).then(res => {
          if (res.data.boltCode !== null) {
            this.editor.setValue(res.data.boltCode)
          } else {
            this.editor.setValue('/*\n' +
              '//There is a demo ;\n' +
              'public class ExtractEntityBolt{\n' +
              '\t\n' +
              '\t\n' +
              '\tRandom _rand ;\n' +
              '\t//Assume you need generate random number, you can initiial here\n' +
              '\tpublic void prepare(OutputCollector collector){\n' +
              '\t\t_rand = new Random() ;\n' +
              '\t}\n' +
              '\n' +
              '\t//Assume this bolt work for receive val, and multiple 2 send next bolt ;\n' +
              '\tpublic void execute(Tuple input){\n' +
              '\t\tint val = input.getInteger(0) ;\t\n' +
              '\t\t_collector.emit("S3", new Values(val*2)) ;\n' +
              '\t}\n' +
              '\n' +
              '}\n' +
              '*/\n' +
              'public class '+this.$route.params.element.name+'Bolt{\n' +
              '\n' +
              '\t/*Additional configuration*/\n' +
              '\tpublic void prepare(OutputCollector collector){\n' +
              '\t\t\n' +
              '\t}\n' +
              '\n' +
              '\t/*Primary processing logic*/\n' +
              '\tpublic void execute(Tuple input){\n' +
              '\t\t\n' +
              '\n' +
              '\t}\n' +
              '\n' +
              '}\n')
          }
        })
      }
    },
    save() {
      let content = this.editor.getValue();
      const element  = this.$route.params.element
      let id = this.$route.params.element.id.split('_')[0]+'_'+this.$route.params.element.id.split('_')[1]
      element['content'] = content
      if (this.$route.params.element.type==="bpmn:StartEvent" ||
        this.$route.params.element.type==="bpmn:IntermediateThrowEvent"){
        let content1 = content.split('\n')
        let j = 0
        let content4 = []
        for (let i =21;i<content1.length;i++){
          if (content1[i].includes('private KafkaConsumer<String,String> consumer;')||content1[i].includes('private ConsumerRecords<String, String> msgList')){
            content1[i] = ''
          } else if (content1[i].includes('emit')){
            j = i

            for (let i =0;i<=j;i++){
              content4[i] = content1[i]
            }
            content4[j+1] = '\t\t<logemit>'
            for (let m = j+1;m<content1.length;m++){
              content4[m+1] = content1[m]
            }
          }
        }
        let x,y,z,a,b = 0
        for (let i =21;i<content4.length;i++){
          if (content4[i].includes('open')){
            x = i;
          }
          if (content4[i].includes('nextTuple')){
            y = i;
          }
          if (content4[i].includes('ack')){
            a = i;
          }
          if (content4[i].includes('fail')){
            b = i;
          }
          if (content4[i].includes('}')){
            z = i
          }
        }
        let content2 = [],k=0
        for (let i =22;i<=z;i++){
          console.log(111)
          if (content4[i]!="		" && content4[i]!=''){
            if (i === x-1 || i===y-1 || i===y-3 || i===a-1 || i===a-3 || i===b-1 || i===z){
              content4[i] = ''
             } else if (i===x || i===y || i===a || i===b){
              content2[k] = '\t-'
              k++
             } else if (i===b-3){
              content2[k] = '\t\t<logack>'
              k++
             }else if(i===z-1){
              content2[k] = '\t\t<logfail>'
              k++
             }else {
              content2[k] = content4[i]
              k++
             }
          }
        }
        let content3 = content2.join('\n')
        console.log(content3)
        if (this.$route.params.element.type==="bpmn:StartEvent"){
          modelsApi.saveSpoutCode({id:id,topologyId:this.$route.params.topologyId,
            spoutCode:content,spoutCodeSimple:content3}).then(res => {
            this.$message.success("save successfully")
          })
        }else {
          modelsApi.saveKafkaSpoutCode({id:id,topologyId:this.$route.params.topologyId,
            kafkaSpoutCode:content,kafkaSpoutCodeSimple:content3}).then(res => {
            this.$message.success("save successfully")
          })
        }
        // console.log(content3)
      } else if (this.$route.params.element.type==="bpmn:EndEvent"|| this.$route.params.element.type==="bpmn:Task"){
        let content1 = content.split('\n')
        let j = 0
        for (let i =19;i<content1.length;i++){
          if (content1[i].includes('execute')){
            j = i
            let content2 = []
            for (let i =0;i<=j;i++){
              content2[i] = content1[i]
            }
            content2[j+1] = '\t\t<logstart>'
            for (let m = j+1;m<content1.length;m++){
              content2[m+1] = content1[m]
            }
            for (let m = 0;m<content2.length;m++){
              content1[m] = content2[m]
            }
          }
          if (content1[i].includes('emit') || content1[i].includes('ack')){
            j = i
            let content2 = []
            for (let i =0;i<=j;i++){
              content2[i] = content1[i]
            }
            content2[j+1] = '\t\t<logemit>'
            i = i + 1
            for (let m = j+1;m<content1.length;m++){
              content2[m+1] = content1[m]
            }
            for (let m = 0;m<content2.length;m++){
              content1[m] = content2[m]
            }
          }
        }
        for (let i =19;i<content1.length;i++){
          if (content1[i].includes('ack')){
            content1[i+1] = '\t\t<logack>'
            break
          }
        }
        let content5 = []
        let m = 0;
        for (m =19;m<content1.length;m++){
          if (!content1[m].includes('emit')){
            continue
          }else break
        }
        if (m==content1.length){
          for (let i =19;i<content1.length;i++){
            if (content1[i].includes('.ack')){
              let j = i
              for (let k=0;k<=j-1;k++){
                content5[k] = content1[k]
              }
              content5[j] = '\t\t-'
              content5[j+1] = '\t\t-'
              for (let k=j+2;k<content1.length;k++){
                content5[k] = content1[k-2]
              }
            }

          }
        }else {
          for (let i =19;i<content1.length;i++){
            if (content1[i].includes('emit')){
              j = i
              let content2 = []
              for (let i =0;i<=j-1;i++){
                content2[i] = content1[i]
              }
              content2[j] = '\t\t-'
              content2[j+1] = content1[j]
              content2[j+2] = '\t\t-'
              for (let m = j+2;m<content1.length;m++){
                content2[m+1] = content1[m-1]
              }
              content5 = content2
            }
          }
        }
        for (let m = 0;m<content5.length;m++){
          content1[m] = content5[m]
        }
        // let content2 = []
        // for (let i =0;i<=content1.length-5;i++){
        //   content2[i] = content1[i]
        // }
        // content2[content1.length-4] = '\t\t<logend>'
        // for (let m = content1.length-4;m<content1.length;m++){
        //   content2[m+1] = content1[m]
        // }
        // for (let m = 0;m<content2.length;m++){
        //   content1[m] = content2[m]
        // }

        let x,y,z = 0
        for (let i =20;i<content1.length;i++){
          if (content1[i].includes('prepare')){
            x = i;
          }
          if (content1[i].includes('execute')){
            y = i;
          }
          if (content1[i].includes('}')){
            z = i
          }
        }
        let content3 = [],k=0
        for (let i =20; i<=z; i++){
          if (content1[i]!="		" && content1[i]!=''){
            if (i === x-1){
              content1[i] = ''
            }else if(i === y-3 || i === y-1){
              content1[i] = ''
            }else if(i===x || i===y){
              content3[k] = '\t-'
              k++
            }else if(i===z || i===z-2){
              content1[i] = ''
            }else{
              content3[k] = content1[i]
              k++
            }
          }
        }

        let content4 = content3.join('\n')
        console.log(content4)
        modelsApi.saveBoltCode({id:id,topologyId:this.$route.params.topologyId,
          boltCode:content,boltCodeSimple:content4}).then(res => {
          this.$message.success("save successfully")
        })
      }
    },
  },

  computed: {
    ...mapGetters([
      // 'getRuleId'
    ])
  },
}
</script>

<style>
.code {
  width: 100%;
  height: calc(100% - 45px);
  float: left;
}
.title {
  font-size: 25px;
  font-weight:bold;
}
.code #editor {
  height: 100%;
}

.operation {
  height: 40px;
  font-size: 14px;
}

.codePanel{
  width: 100%;
  height:1000px;
}

</style>
