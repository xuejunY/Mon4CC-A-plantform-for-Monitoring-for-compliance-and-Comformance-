<template>
  <div class="app-container">
    <div class="codePanel">
      <div class="title">{{title}}</div>
      <div class="code">
        <div id="editor"></div>
      </div>
    </div>
  </div>
</template>

<script>
import ace from 'brace';
import configApi from "@/api/config";
import modelApi from '@/api/models'
export default {
  name: "ecl",
  components:{},
  data() {
    return {
      mode:0, //0表示新建，1表示保存已有
      title:'ecl',
      editor:null,
      showDialog: false,
      showErorDialog: false,
      checked:false, //是否已经过语法检查
      checkResult:null, //检查结果，-1未通过， 1通过
      errors:[],
    }
  },
  mounted() {
    this.init()
  },
  created() {
  },
  methods: {
    init(){
      this.editor = ace.edit("editor");
      this.editor.setFontSize(16); //设置字体大小
      require('brace/mode/sql');
      require('brace/theme/clouds');
      this.editor.getSession().setMode('ace/mode/sql');
      this.editor.setTheme('ace/theme/clouds');

      configApi.getModelEcl({modelId:this.$route.params.modelId}).then(res => {
        if (res.data.modelEcl!==null){
          this.editor.setValue(res.data.modelEcl)
        }
      })
    },
  },
}
</script>

<style>
.code {
  width: 100%;
  height: calc(100% - 45px);
  float: left;
}
.title {
  font-size: 25px;
  font-weight:bold;
}
.code #editor {
  height: 100%;
}

.operation {
  height: 40px;
  font-size: 14px;
}

.codePanel{
  width: 100%;
  height:1000px;
}

</style>
