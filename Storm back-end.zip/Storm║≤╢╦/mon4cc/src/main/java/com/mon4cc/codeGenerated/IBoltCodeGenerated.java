package com.mon4cc.codeGenerated;

/**
 *
 * @author xjyou_
 * @Date 2020.12.28
 */

/**
 * The interface(#IBoltCodeGenerated) is for generate bolt code based on given topology id.
 */
public interface IBoltCodeGenerated {
    @Deprecated
    boolean boltCodeGenerated(String topologyId) ;
    boolean boltCodeGeneratedUpgraded(String topologyId) ;
}
