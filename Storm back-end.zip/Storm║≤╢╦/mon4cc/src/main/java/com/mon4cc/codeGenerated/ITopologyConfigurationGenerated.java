package com.mon4cc.codeGenerated;
/**
 * @author xjyou_
 * @Date 2020.12.30
 */
/**
 * The interface(#ITopologyConfigurationGenerated) is for generate main configuration code based on given topology id.
 */
public interface ITopologyConfigurationGenerated {
    boolean topologyConfigurationGenerated(String topology) ;
}
