package com.mon4cc.codeGenerated;
/**
 * @author xjyou_
 * @Date 2020.12.29
 */
/**
 * The interface(#IKafkaSpoutCodeGenerated) is for generate spout code based on given topology id.
 */
public interface IKafkaSpoutCodeGenerated {
    boolean kafkaSpoutCodeGenerated(String topologyId) ;
}
