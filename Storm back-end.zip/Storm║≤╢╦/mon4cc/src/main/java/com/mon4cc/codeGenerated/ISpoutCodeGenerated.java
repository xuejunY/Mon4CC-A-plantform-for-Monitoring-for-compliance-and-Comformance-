package com.mon4cc.codeGenerated;

/**
 * @author xjyou_
 * @Date 2020.12.29
 */
/**
 * The interface(#ISpoutCodeGenerated) is for generate spout code based on given topology id.
 */
public interface ISpoutCodeGenerated {
    boolean spoutCodeGenerated(String topologyId) ;
}
