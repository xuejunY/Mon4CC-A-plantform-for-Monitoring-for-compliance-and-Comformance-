package com.mon4cc;

import org.apache.ibatis.session.SqlSession;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;


//import com.mon4cc.entity.User;
//import com.mon4cc.mapper.UserMapper;

@SpringBootTest
class Mon4ccApplicationTests {

	@Test
	void contextLoads() {
	}
	

}
